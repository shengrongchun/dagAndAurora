const path = require('path');
const pkg = require('./package.json');

const ENV = process.env.VUE_APP_ENV || 'dev';
const options = {
  pro: {
    assetsRoot: path.resolve(__dirname, './dist/PRO', pkg.version),
    assetsPublicPath: `https://m.hellobike.com/${pkg.name}/PRO/${pkg.version}/`,
  },
  uat: {
    assetsRoot: path.resolve(__dirname, './dist/UAT', pkg.version),
    assetsPublicPath: `https://m.hellobike.com/${pkg.name}/UAT/${pkg.version}/`,
  },
  fat: {
    assetsRoot: path.resolve(__dirname, './dist/FAT', pkg.version),
    assetsPublicPath: `https://m.hellobike.com/${pkg.name}/FAT/${pkg.version}/`,
  },
  dev: {
    assetsRoot: path.resolve(__dirname, './dist/DEV', pkg.version),
    assetsPublicPath: '/',
  }
};

const config = options[ENV] || options.dev;
if (process.env.VUE_APP_ENV !== 'dev') {
  process.env.NODE_ENV = 'production';
}
module.exports = {
  outputDir: config.assetsRoot,
  publicPath: config.assetsPublicPath,
  configureWebpack: {
    entry: {
      app: './base/main.js'
    },
    resolve: {
      alias: {
        base: path.resolve(__dirname, './base'),
        src: path.resolve(__dirname, './src')
      }
    }
  }
};
