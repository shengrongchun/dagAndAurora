<template>
  <div
    :class="{hideSidebar:!sidebarStatus}"
    class="app-wrapper">
    <div class="sidebar-wrapper">
      <div
        class="sidebar-header"
        >
        <el-select
          @focus="sidebarStatus=true"
          @visible-change="changeVal"
          v-model="searchVal"
          filterable
          :disabled="disabled"
          placeholder="搜索任务">
          <template slot="prefix">
            <i class="el-icon-search" />
          </template>
          <el-option
            v-for="(item,key) in searchOptions"
            :key="key"
            :label="item.name"
            :value="item.actionId" />
        </el-select>
      </div>
      <sidebar class="sidebar-container" />
    </div>
    <div class="main-container">
      <navbar
        :sidebar-status="sidebarStatus"
        @toggle="toggle" />
      <app-main />
    </div>
  </div>
</template>

<script>
import Cookies from 'js-cookie';
import { Navbar, Sidebar, AppMain } from 'base/views/layout';
import { mapState } from 'vuex';

export default {
  name: 'Layout',
  components: {
    Navbar,
    Sidebar,
    AppMain
  },
  data() {
    return {
      sidebarStatus: false,
      searchVal: null,
    };
  },
  computed: {
    ...mapState({
      searchOptions(state) {
        return state.dag.actionList;
      },
      disabled(state) {
        return !state.dag.jobSetDataObj[state.dag.flowActionId];
      }
    })
  },
  created() {
    this.sidebarStatus = !!+Cookies.get('sidebarStatus');
    this.$nextTick(() => {
      const svg = document.querySelector('.dagContainer');
      this.svgH = Math.floor(svg.clientHeight / 2);
      this.svgW = Math.floor(svg.clientWidth / 2);
      this.$store.commit('setSvgHW', [this.svgH, this.svgW]);
    });
  },
  methods: {
    changeVal(val) {
      if (!val && this.searchVal) { // 选择下拉框隐藏的时候
        let node = null;
        for (let i = 0, j = this.searchOptions.length; i < j; i += 1) {
          if (String(this.searchOptions[i].actionId) === String(this.searchVal)) {
            node = this.searchOptions[i];
            break;
          }
        }
        this.$store.commit('changeSvgPos', [this.svgW - node.left, this.svgH - node.top]);
      }
    },
    toggle() {
      this.sidebarStatus = !this.sidebarStatus;
      Cookies.set('sidebarStatus', this.sidebarStatus ? 1 : 0);
    }
  }
};
</script>

<style rel="stylesheet/less" lang="less" scoped>
.app-wrapper {
  &:after {
    content: "";
    display: table;
    clear: both;
  }
  position: relative;
  width: 100%;
  &.hideSidebar {
    .sidebar-wrapper {
      transform: translate(-160px, 0);
      .sidebar-container {
        transform: translate(152px, 0);
        /deep/ .longName {
          display: none;
        }
        /deep/ .shortName {
          display: inline-block;
        }
      }
      .sidebar-header {
        .el-select {
          transform: translate(165px, 0);
          /deep/ .el-input__prefix {
            left: 0;
            color: #8BADBE;
          }
        }
      }
      &:hover {
        transform: translate(0, 0);
        .sidebar-container {
          transform: translate(0, 0);
          /deep/ .longName {
            display: inline-block;
          }
          /deep/ .shortName {
            display: none;
          }
        }
        .sidebar-header {
          .el-select {
            transform: translate(0, 0);
            /deep/ .el-input__prefix {
              left: 5px;
              color: #7b7d82;
            }
          }
        }
      }
    }
    .main-container {
      margin-left: 40px;
    }
  }
  .sidebar-header {
    text-align: center;
    line-height: 50px;
    background: #2E2C34;
    .el-select {
      /deep/ .el-input__inner {
        line-height: 40px;
        height: 40px;
        background: #2E2C34;
        border: none;
      }
      ::-webkit-input-placeholder {
        color: #7b7d82;
      }
      /deep/ .el-input__prefix {
        font-size: 16px;
        color: #7b7d82;
      }
      /deep/ .el-input__suffix {
        i {
          color: #7b7d82;
        }
      }
    }
  }
  .sidebar-wrapper {
    width: 200px;
    position: fixed;
    top: 0;
    bottom: 0;
    left: 0;
    z-index: 2001;
    overflow: hidden;
    transition: all 0.28s ease-out;
  }
  .sidebar-container {
    transition: all 0.28s ease-out;
    position: absolute;
    top: 50px;
    bottom: 0;
    left: 0;
    right: -17px;
    overflow-y: scroll;
  }
  .main-container {
    transition: all 0.28s ease-out;
    margin-left: 200px;
    height: 100vh;
  }
}
</style>
