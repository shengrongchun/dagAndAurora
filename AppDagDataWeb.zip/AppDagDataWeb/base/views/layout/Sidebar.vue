<template>
  <el-menu
    :default-openeds="['1','2','3']"
    mode="vertical"
    background-color="#27252B"
    text-color="#E6EDF1">
    <sidebar-item />
  </el-menu>
</template>

<script>
import SidebarItem from './SidebarItem';

export default {
  components: { SidebarItem },
};
</script>
