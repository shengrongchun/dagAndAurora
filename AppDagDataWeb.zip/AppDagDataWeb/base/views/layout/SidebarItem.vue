<template>
  <div class="sidebarContainer">
    <el-submenu index="1">
      <template slot="title">
        <span class="shortName">类型</span>
        <span class="longName">任务类型</span>
      </template>
      <template
        v-for="(item,index) in jobTypeMenuList">
        <el-menu-item
          :key="index"
          v-if="item.actionStageId !== '35'">
          <drag-item
            :drag-data="item">
            <span class="icon">
              <i :class="'iconfont '+item.icon" />
            </span>
            <span>{{ item.name }}</span>
          </drag-item>
        </el-menu-item>
      </template>
    </el-submenu>
    <el-submenu index="2">
      <template slot="title">
        <span class="shortName">任务</span>
        <span class="longName">内置任务（ {{ actionList.length }} ）</span>
      </template>
      <el-menu-item
        @click="clickJob(item)"
        v-for="(item,index) in actionList"
        :key="index">
        <span class="icon">
          <i :class="'iconfont '+getLeftIcon(item)" />
        </span>
        <span>{{ item.name }}</span>
      </el-menu-item>
    </el-submenu>
    <el-submenu index="3">
      <template slot="title">
        <span class="shortName">流程</span>
        <span class="longName">业务流程（ {{ inflowList.length }} ）</span>
      </template>
      <el-menu-item
        @click="clickFlow(item)"
        v-for="(item,index) in inflowList"
        :key="index">
        <span class="icon">
          <i class="iconfont iconnode" />
        </span>
        <span>{{ item.name }}</span>
      </el-menu-item>
    </el-submenu>
  </div>
</template>
<script>
import dragItem from '@/components/dragItem';
import { mapState } from 'vuex';

export default {
  components: {
    dragItem
  },
  computed: {
    ...mapState({
      jobTypeMenuList(state) {
        return state.dag.jobTypeMenuList;
      },
      actionList(state) {
        return state.dag.actionList;
      },
      inflowList(state) {
        return state.dag.flowList;
      }
    })
  },
  created() {
    let hash = window.location.hash.replace('#/', '');
    hash = hash.replace('?', '');
    if (hash) {
      this.windowParams = {};
      hash = hash.split('&');
      hash.forEach((str) => {
        const params = str.split('=');
        [, this.windowParams[params[0]]] = params;
      });
    }
    if (this.windowParams && this.windowParams.actionId) {
      const str = `actionId=${this.windowParams.actionId}`;
      window.location.href = window.location.href.replace(str, '');
      this.$store.commit('initflowData', this.windowParams.actionId);
    }
  },
  methods: {
    getLeftIcon(item) {
      let iconFont = null;
      for (let i = 0, j = this.jobTypeMenuList.length; i < j; i += 1) {
        if (this.jobTypeMenuList[i].actionStageId === item.actionStageId) {
          iconFont = this.jobTypeMenuList[i].icon;
          break;
        }
      }
      return iconFont;
    },
    clickJob(job) {
      const { svgW, svgH } = this.$store.state.dag;
      this.$store.commit('changeSvgPos', [svgW - job.left, svgH - job.top]);
    },
    clickFlow(job) {
      const { flowActionId } = this.$store.state.dag;
      if (String(job.actionId) === String(flowActionId)) { return; }
      this.$alert(`确定展示业务流程 ${job.name} 吗?`, job.name, {
        confirmButtonText: '确定',
        callback: (action) => {
          if (action === 'confirm') {
            this.$store.commit('initflowData', job.actionId);
          }
        }
      });
    }
  }
};
</script>

<style scoped lang="less">
  .sidebarContainer {
    .el-submenu {
      .shortName {
        color: #8BADBE;
        display: none;
        transform: translate(-3px, 0px);
      }
      user-select: none;
      /deep/ .el-submenu__title {
        background: #2F2D35 !important;
        padding-left: 16px !important;
        font-size: 16px;
        border-top: 1px solid #27252B;
      }
      .el-menu-item {
        padding-left: 20px !important;
        .icon {
          margin-right: 15px;
          display: inline-block;
          vertical-align: baseline;
          line-height: 1;
          width: 16px;
          height: 16px;
          .iconfont {
            color: #8BADBE;
            font-size: 16px;
          }
        }
      }
    }
  }
</style>
