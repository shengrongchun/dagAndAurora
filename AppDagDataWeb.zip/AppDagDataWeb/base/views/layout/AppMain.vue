<template>
  <section
    class="app-main"
    style="paddingTop: 50px">
    <transition
      name="fade"
      mode="out-in">
      <router-view :key="key" />
    </transition>
  </section>
</template>

<script>

export default {
  name: 'AppMain',
  computed: {
    key() {
      return this.$route.name ? this.$route.name + +new Date() : this.$route + +new Date();
    }
  }
};
</script>
