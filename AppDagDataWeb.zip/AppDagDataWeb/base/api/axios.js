import axios from 'axios';
import ssoAuth from '@hb/sso-auth';
import { filterParams } from 'base/utils/index';
// import { startLoading, closeLoading } from './globalLoading';
import Catcher from './errCatcher';

window.cancelTokenList = [];

const service = axios.create({
  timeout: 5 * 60 * 1000
});

service.interceptors.request.use((config) => {
  config.headers.token = ssoAuth.token;
  config.headers['Content-Type'] = 'application/x-www-form-urlencoded';
  // startLoading(config);
  const data = config.data || config.params || {};
  filterParams(data);
  const formData = new FormData();
  Object.keys(data).forEach((key) => {
    formData.append(key, data[key]);
  });
  config.data = formData;
  // 全局CancelToken
  const source = axios.CancelToken.source();
  window.cancelTokenList.push(source);
  config.cancelToken = source.token;
  return config;
}, (error) => {
  Promise.reject(error);
});

service.interceptors.response.use(
  (response) => {
    // closeLoading();
    // 处理全局CancelToken List
    window.cancelTokenList = window.cancelTokenList
      .filter(x => x.token !== response.config.cancelToken);
    // 各种返回状况处理
    const res = response && response.data;
    if (res.errorCode === 0) { res.status = 1; }
    if (res.status !== 1) Catcher(response);
    return res;
  },
  (error) => {
    // closeLoading();
    Catcher(error.response, true);
  }
);

export default service;
