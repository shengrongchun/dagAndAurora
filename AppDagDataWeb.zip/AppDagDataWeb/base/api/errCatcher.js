import ssoAuth from '@hb/sso-auth';
import { Notification } from 'element-ui';

const DURATION = 4000;
const HttpErrorList = {
  404: '请求地址错误或后端接口未部署',
  403: '没有相关权限',
  401: '登录状态过期, 需要重新登录',
  500: '后端服务有未处理的错误',
  502: '后端接口无响应',
  504: '请求超时, 可能是网络问题, 请稍后重试'
};

class HttpBizError extends Error {
  constructor(message, request, response) {
    super(message);
    this.name = 'HttpBizError';
    this.request = request;
    this.response = response;
  }
}

class HttpNetworkError extends Error {
  constructor(message) {
    super(message);
    this.name = 'HttpNetworkError';
  }
}

function Catcher(response, isHttpError) {
  if (isHttpError) {
    const { status } = response;
    const baseMessage = '网络请求错误';
    Notification.error({
      title: baseMessage,
      message: HttpErrorList[status],
      duration: DURATION
    });
    if (status === 401) ssoAuth.signOut();
    throw new HttpNetworkError(baseMessage);
  } else {
    const { config, data = {}, request } = response;
    const baseMessage = '后端接口报错';
    if (!config.noGlobalMessage) {
      Notification.error({
        title: baseMessage,
        message: data.info || data.msg || data.message || '后端没有返回错误信息',
        duration: DURATION
      });
    }
    throw new HttpBizError(baseMessage, request, data);
  }
}
export default Catcher;
