<template>
  <div
    id="app"
    @mousemove="mouseAction($event,true)"
    @mouseup="mouseAction($event,false)">
    <router-view />
  </div>
</template>

<script>
export default {
  name: 'App',
  methods: {
    mouseAction(e, mask) {
      const {
        node, actionList, svgX, svgY, publish
      } = this.$store.state.dag;
      if (!node.show) { // 移动节点没有显示
        return;
      }
      if (!mask) { // 鼠标松开
        if (e.toElement.id === 'dagContainer' && publish !== 1) { // 并且在svg区域
          let { actionId } = node;
          let job = null;
          if (!actionId) { // 新增
            actionId = `actionId${Date.now()}`;
            job = Object.assign({}, node, { actionId });
          } else { // 移动job
            for (let i = 0, j = actionList.length; i < j; i += 1) {
              if (String(actionList[i].actionId) === String(actionId)) {
                job = actionList[i];
                break;
              }
            }
          }
          this.$store.commit('pushJob', Object.assign(job, {
            left: e.offsetX - svgX,
            top: e.offsetY - svgY,
          }));
        }
        // 松开鼠标必须初始化node,目的是消失node
        this.$store.commit('initNode');
      } else { // 鼠标移动
        this.$store.commit('changeNode',
          Object.assign({}, node, {
            left: e.pageX,
            top: e.pageY
          }));
      }
    },
  }
};
</script>

<style lang="less">
  @import '~normalize.css/normalize.css';
  @import './styles/index.less';
</style>
