import Vue from 'vue';
import Router from 'vue-router';
import config from '@/router.config';
import Layout from 'base/views/layout/Layout';

Vue.use(Router);

const format = conf => ({
  path: conf.path || '/',
  name: conf.name,
  component: () => import(`@/views${conf.component || conf.path}`),
  hidden: conf.hidden,
  meta: {
    desc: conf.desc,
    actionId: conf.actionId || 'ALL',
    breadcrumb: conf.breadcrumb
  }
});

export const constantRouterMap = config.map(x => (
  x.children ? {
    path: x.path || '/',
    name: x.name,
    icon: x.icon || 'setting',
    component: Layout,
    hidden: x.hidden,
    meta: {
      desc: x.desc,
      actionId: x.actionId || 'ALL'
    },
    children: x.children.map(format),
  } : {
    path: x.path || '/',
    icon: x.icon || 'setting',
    component: Layout,
    hidden: x.hidden,
    meta: {
      desc: x.desc,
      actionId: x.actionId || 'ALL'
    },
    children: [format(x)],
    noDropdown: true
  }));

const router = new Router({
  scrollBehavior: () => ({ y: 0 }),
  routes: constantRouterMap
});

router.beforeEach(async (to, from, next) => {
  if (window.cancelTokenList) {
    window.cancelTokenList.forEach(x => x.cancel());
  }
  window.cancelTokenList = [];
  next();
});

export default router;
