import Vue from 'vue';
import ElementUI from 'element-ui';
import ssoAuth from '@hb/sso-auth';
import locale from 'element-ui/lib/locale/lang/zh-CN';
import 'nprogress/nprogress.css';
import '@/resource/iconfont/iconfont.css';
// import 'element-ui/lib/theme-chalk/index.css';
import './styles/element-theme-dark/index.css';
import action from 'base/directives/action';
import store from '@/store';
import App from './App';
import router from './router';
import Contextmenu from '@/directives/contextmenu';

Vue.use(Contextmenu);
Vue.use(ElementUI, { locale, size: 'mini' });
Vue.directive('action', action);
Vue.config.productionTip = false;
/* eslint-disable no-new */
const init = async () => {
  await ssoAuth.signIn();
  new Vue({
    el: '#app',
    router,
    store,
    render: h => h(App)
  });
};
//
init();
