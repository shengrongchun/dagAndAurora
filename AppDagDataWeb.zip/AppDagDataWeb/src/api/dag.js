import Ax from 'base/api/axios';
import config from '@/env.config';

const API = config.DAG_API;


// 保存业务流程
export function updateFlowInfo(data) {
  return Ax.post(`${API}/dag/updateAction.action`, data).then(res => res);
}
// 保存业务流程
export function saveFlowInfo(data) {
  if (data.actionId) {
    return updateFlowInfo(data);
  }
  return Ax.post(`${API}/dag/saveAction.action`, data).then(res => res);
}

// 获取业务流程列表
export function getFlowList(data) {
  return Ax.post(`${API}/dag/findActions.action`, data).then(res => res);
}

// 获取脚本下拉列表
export function getScriptList(data) {
  return Ax.get(`${API}/dag/findScriptsGrid.action`, data).then(res => res);
}

// 添加依赖关系
export function pushLink(data) {
  return Ax.post(`${API}/dag/addActionRelation.action`, data).then(res => res);
}
// 删除依赖关系
export function delLink(data) {
  return Ax.post(`${API}/dag/deleteActionRelation.action`, data).then(res => res);
}
// 删除节点
export function delJob(data) {
  return Ax.post(`${API}/dag/deleteActoin.action`, data).then(res => res);
}
// 获取数据源
export function getDataSource(data) {
  return Ax.get(`${API}/dag/findMetaDataGrid.action`, data).then(res => res);
}
// 获取hdfs数据源
export function getHdfsDataSource(data) {
  return Ax.get(`${API}/dag/getAllDatabases.action`, data).then(res => res);
}
// 获取hdfs表名
export function getHdfsTableList(data) {
  return Ax.post(`${API}/dag/getAllTablesByPattern.action`, data).then(res => res);
}
// 获取hbase表名
export function getHbaseTableList(data) {
  return Ax.post(`${API}/dag/getAllHbaseTables.action`, data).then(res => res);
}
// 获取hdfs列名
export function getHdfsDbTable(data) {
  return Ax.post(`${API}/dag/getTableInfo.action`, data).then(res => res);
}
// 获取表名
export function getTableList(data) {
  return Ax.post(`${API}/dag/findMetaTables.action`, data).then(res => res);
}
// 获取列名
export function getDbTable(data) {
  return Ax.post(`${API}/dag/findMetaTableCoulmns.action`, data).then(res => res);
}
// 改变节点 left,top
export function changeLeftTop(data) {
  return Ax.post(`${API}/dag/locationUpdate.action`, data).then(res => res);
}
// 获取缓存
export function getCacheDataById(data) {
  let name = '';
  if (data.actionStageId === '29') { // 数据交换
    name = 'fillHdfs2HdfsConfXml';
  } else if (data.actionStageId === '10') { // 数据计算
    name = 'fillRunHiveXml';
  } else if (data.actionStageId === '26') { // 自定义脚本
    name = 'fillCustShellXml';
  } else if (data.actionStageId === '32') { // 邮件推送
    name = 'fillHdfs2EsConfXml';
  }
  return Ax.post(`${API}/dag/${name}.action`, { actionId: data.actionId }).then(res => res);
}
// 根据actionId查询业务流程配置信息
export function getFlowDataById(data) {
  return Ax.post(`${API}/dag/fillAction.action`, data).then(res => res);
}
// 根据actionId查询业务流程DAG
export function getDagById(data) {
  return Ax.post(`${API}/dag/getActionRelation.action`, data).then(res => res);
}

// 根据actionId测试运行
export function flowRuning(data) {
  return Ax.post(`${API}/dag/generatorActionTask.action`, data).then(res => res);
}
// 根据actionId暂停
export function flowStoping(data) {
  return Ax.post(`${API}/dag/pause.action`, data).then(res => res);
}
// 根据actionId结束
export function flowEnding(data) {
  return Ax.post(`${API}/dag/stop.action`, data).then(res => res);
}
// 根据actionId继续运行
export function flowContinue(data) {
  return Ax.post(`${API}/dag/jobContinue.action`, data).then(res => res);
}
// 根据actionId发布
export function flowPublishing(data) {
  return Ax.post(`${API}/dag/saveActionProgress.action`, data).then(res => res);
}
// 根据actionId查询业务流程状态
export function getFlowStatus(data) {
  return Ax.post(`${API}/dag/findDagStatus.action`, data).then(res => res);
}
// 根据actionId查看日志
export function getLog(data) {
  return Ax.post(`${API}/dag/logview.action`, data).then(res => res);
}
