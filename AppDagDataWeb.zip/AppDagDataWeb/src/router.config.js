export default [
  {
    desc: '默认页面',
    name: 'index',
    path: '/',
    component: '/dagIndex/index',
  }
];
