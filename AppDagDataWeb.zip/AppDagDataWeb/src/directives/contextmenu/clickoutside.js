const mask = '@@hellobikie';
//
export default {
  name: 'clickoutside',
  bind(el, binding, vnode) {
    const handler = (e) => {
      if (!vnode.context || el.contains(e.target)) {
        return;
      }
      if (binding.expression) { // 表达式
        vnode.context[el[mask].methodName](e);
      }
    };
    el[mask] = {
      handler,
      methodName: binding.expression,
    };
    setTimeout(() => {
      document.addEventListener('click', handler);
    }, 0);
  },
  update(el, binding) {
    el[mask].methodName = binding.expression;
  },
  unbind(el) {
    if (!el[mask]) { return; }
    document.removeEventListener('click', el[mask].handler);
  }
};
