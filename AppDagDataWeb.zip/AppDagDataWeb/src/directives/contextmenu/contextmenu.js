/**
 *
 * 右击出现菜单
 */
//
export default {
  name: 'contextmenu',
  inserted: (el, binding, vnode) => {
    //
    const contextmenu = vnode.context.$refs[binding.arg];
    if (!contextmenu) { return; }
    el.oncontextmenu = (e) => {
      contextmenu.setData(e, binding.value);
      return false;
    };
  }
};
