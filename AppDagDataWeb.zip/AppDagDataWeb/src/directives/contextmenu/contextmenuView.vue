<template>
  <g
    v-if="show"
    :transform="`translate(${-svgX}, ${-svgY})`">
    <foreignObject
      width="100%"
      height="100%">
      <div
        v-clickoutside="clickoutside"
        :style="style"
        :class="addClass"
        class="context-menu"
        @mouseleave="hoverMethod"
        @click="selfClick">
        <slot>
          <ul
            :class="{'divided':divided}"
            class="menu-ul">
            <li
              v-for="(item,index) in list"
              :key="index"
              :style="(hoverIndex === index)?hover:null"
              class="menu-li"
              @mouseenter="mouseenter(index)"
              @mouseleave="mouseleave(index)"
              @click="click(item,index)">
              <i
                v-if="item.iconClass"
                :class="item.iconClass" />
              <span>{{ item[title] }}</span>
            </li>
          </ul>
        </slot>
      </div>
    </foreignObject>
  </g>
</template>

<script>
import { mapState } from 'vuex';

export default {
  name: 'ContextmenuView',
  props: {
    list: {
      type: Array,
      default() {
        return [];
      }
    },
    itemClick: {
      type: Function,
      default() {}
    },
    getData: {
      type: Function,
      default() {}
    },
    divided: {
      type: Boolean,
      default: false,
    },
    hoverStyle: {
      type: Object,
      default() {
        return {};
      }
    },
    title: {
      type: String,
      default: 'name'
    },
    addClass: {
      type: String,
      default: null
    },
    hideWay: {
      type: String,
      default: 'click'
    },
    zIndex: {
      type: Number,
      default: 100
    }
  },
  data() {
    return {
      show: false,
      style: {
        top: 0,
        left: 0,
        'z-index': this.zIndex
      },
      vdata: null,
      hoverIndex: -10,
    };
  },
  computed: {
    ...mapState({
      svgX(state) {
        return state.dag.svgX;
      },
      svgY(state) {
        return state.dag.svgY;
      },
    }),
    hover() {
      return Object.assign({
        // background: '#ebf2f8',
        color: '#fff',
      }, this.hoverStyle);
    }
  },
  methods: {
    selfClick() {
      if (this.hideWay === 'click') {
        this.show = false;
      }
    },
    clickoutside() {
      if (this.hideWay === 'outclick' || this.hideWay === 'click') {
        this.show = false;
      }
    },
    hoverMethod() {
      if (this.hideWay === 'hover') {
        this.show = false;
      }
    },
    setData(e, vdata) {
      this.show = true;
      const x = document.body.clientWidth - e.path[4].clientWidth;
      const y = document.body.clientHeight - e.path[4].clientHeight;
      this.$nextTick(() => {
        this.setPosition(
          e.clientX - x, e.clientY - y, document.body.clientWidth - e.clientX,
          document.body.clientHeight - e.clientY
        );
      });
      this.hoverIndex = -10;
      this.vdata = vdata;
      this.getData(vdata, e);
    },
    setPosition(eX, eY, X, Y) {
      if (X < this.$el.clientWidth) {
        this.style.left = `${eX - this.$el.clientWidth}px`;
      } else {
        this.style.left = `${eX}px`;
      }
      //
      if (Y < this.$el.clientHeight) {
        this.style.top = `${eY - this.$el.clientHeight}px`;
      } else {
        this.style.top = `${eY}px`;
      }
    },
    click(item, index) {
      this.itemClick(this.vdata, item, index);
    },
    mouseenter(index) {
      this.hoverIndex = index;
    },
    mouseleave() {
      this.hoverIndex = -10;
    }
  },
};
</script>

<style scoped lang="less">
  .context-menu {
    position: fixed;
    max-height: 400px;
    overflow: auto;
    ul.menu-ul {
      list-style: none;
      margin: 0;
      padding: 3px 0;
      background-color: #2E2C34;
      //border: 1px solid #000;
      border-radius: 2px;
      //box-shadow: 2px 2px 12px 5px rgb(26, 25, 29);
      &.divided {
        li.menu-li:not(:last-child) {
          border-bottom: 1px solid #414144;
        }
      }
      li.menu-li {
        line-height: 27px;
        padding: 0 15px;
        font-size: 14px;
        color: #8BADBE;
        font-weight: 400;
        cursor: pointer;
        outline: none;
        i {
          margin-right: 5px;
          font-size: 14px;
        }
      }
    }
  }
</style>
