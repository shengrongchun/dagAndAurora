
import contextmenu from './contextmenu';
import clickoutside from './clickoutside';
import ContextmenuView from './contextmenuView.vue';

const install = (Vue) => {
  Vue.directive('contextmenu', contextmenu);
  Vue.directive('clickoutside', clickoutside);
  Vue.component(ContextmenuView.name, ContextmenuView);
};
export { contextmenu, ContextmenuView, clickoutside };
//
if (typeof window !== 'undefined' && window.Vue) {
  install(window.Vue);
}
//
export default {
  install,
};
