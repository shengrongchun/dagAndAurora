<template>
  <g>
    <path
      :d="dragLinkPath()"
      class="linkConnect"
      :class="{'active':go,'error':error}"
    />
    <circle
      v-if="type==='tempLink'"
      :cx="pos.fromX"
      :cy="pos.fromY"
      r="4"
      style="stroke:#8BADBE;
            stroke-width: 2;
            fill:#fff" />
    <polyline
      :points="computedArrow()"
      style="stroke:#D8D8D8;fill:#D8D8D8;" />
  </g>
</template>
<script>

export default {
  props: {
    linkPos: {// 相对位置
      type: Object,
      default() {
        return {};
      }
    },
    linkInfo: {
      type: Object,
      default() {
        return {};
      }
    },
    type: {
      type: String,
      default: 'link'// tempLink
    }
  },
  data() {
    return {
      go: false,
      error: false
    };
  },
  computed: {
    pos() {
      let {
        fromX, fromY, toX, toY
      } = this.linkPos;
      //
      if (this.type === 'link') {
        const from = this.getJob(this.linkInfo.source);
        const to = this.getJob(this.linkInfo.target);
        //
        const top = from.top > to.top;
        fromX = from.left;
        toX = to.left;
        if (top) { // 上
          fromY = from.top - 13;
          toY = to.top + 13;
        } else {
          fromY = from.top + 13;
          toY = to.top - 13;
        }
      }
      //
      return {
        fromX, fromY, toX, toY
      };
    }
  },
  updated() {
    if (this.type === 'link') {
      const { flowStatus } = this.$store.state.dag;
      if (flowStatus === '4' || flowStatus === '5' || !flowStatus) { // 执行成功或者运行状态或者失败状态或者暂停状态
        clearInterval(this.timeintervel);
        this.timeintervel = null;
      }
      // 5 4 3 null
      const from = this.getJob(this.linkInfo.source);
      const to = this.getJob(this.linkInfo.target);
      if (from.status && from.status === '4') { // 前置节点成功
        if (flowStatus === '3') { // 运行状态
          this.error = false;
          if (to.status === '4' || to.status === '5') { // target成功或者失败
            this.go = to.status === '4';
            this.error = to.status === '5';
            clearInterval(this.timeintervel);
            this.timeintervel = null;
          } else if (!this.timeintervel) {
            this.timeintervel = setInterval(() => {
              this.go = !this.go;
            }, 800);
          }
        } else { // 5 4 null
          this.error = to.status === '5';
          this.go = to.status === '4';
        }
      } else { // 不成功
        this.go = false;// active状态
        this.error = to.status === '5';// 失败节点
      }
    }
  },
  methods: {
    dragLinkPath() {
      const {
        fromX, fromY, toX, toY
      } = this.pos;
      return `M ${fromX} ${fromY}  Q ${fromX} ${fromY + 50} ${(toX + fromX)
        / 2} ${(fromY + toY) / 2} T ${toX} ${toY - 2}`;
    },
    computedArrow() {
      // 计算箭头坐标
      const { toX, toY } = this.pos;
      return `${toX} ${toY - 2} ${toX - 4} ${toY - 8 - 2} ${toX + 4} ${toY - 8 - 2}`;
    },
    getJob(actionId) {
      let val = {};
      const { actionList } = this.$store.state.dag;
      for (let i = 0, j = actionList.length; i < j; i += 1) {
        if (String(actionList[i].actionId) === String(actionId)) {
          val = actionList[i];
          break;
        }
      }
      return val;
    },
  }
};
</script>
<style scoped lang="less">
.linkConnect {
  stroke: #979797;
  stroke-width: 2px;
  fill: none;
  &:hover {
    stroke: #8BADBE;
    stroke-width: 3px;
    cursor: pointer;
  }
  &.active {
    stroke-width: 3px;
    stroke:#137752;
  }
  &.error {
    stroke-width: 3px;
    stroke:#f24e4e;
  }
}
</style>
