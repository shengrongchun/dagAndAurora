<template>
  <g
    :transform="`translate(${svgX}, ${svgY})`">
    <g
      v-for="(item, idx) in actionList"
      :key="'node' + idx"
      :transform="`translate(${item.left-75}, ${item.top-15})`">
      <foreignObject
        :class="{'noEvent':drag}"
        @mousemove.stop="gMousemove($event, item)"
        class="nodeContainer">
        <div
          class="topContent"
          @mouseup.stop="linkTo($event, item)"
          @mousedown.stop="linkFrom($event, item,'top')"/>
        <div
          v-contextmenu:job="item"
          class="dragNode"
          @mousedown.stop="mouseSingleOrDouble($event, item)">
          <i :class="'iconfont '+getLeftIcon(item)" />
          <span
            class="nodeName">{{ item.name }}</span>
          <i :class="'iconfont '+getRightIcon(item)" />
        </div>
        <div
          class="topContent"
          @mouseup.stop="linkTo($event, item)"
          @mousedown.stop="linkFrom($event, item,'bottom')"/>
      </foreignObject>
    </g>
    <link-node
      v-contextmenu:link="link"
      v-for="(link,idx) in actionLink"
      :key="'link'+idx"
      :link-info="link"
      type="link" />
    <link-node
      v-if="linking"
      key="tempLInk"
      :link-pos="linkPos"
      type="tempLink" />
    <contextmenu-view
      ref="job"
      :list="jobMenuData"
      :item-click="itemClick"
      divided />
    <contextmenu-view
      ref="link"
      :list="linkMenuData"
      :item-click="itemClick"
      divided />
  </g>
</template>
<script>
import { mapState } from 'vuex';
import linkNode from '@/components/linkNode';

export default {
  components: {
    linkNode,
  },
  data() {
    return {
      linking: false,
      linkPos: {
        fromX: 0,
        fromY: 0,
        toX: 0,
        toY: 0
      }
    };
  },
  computed: {
    ...mapState({
      actionList(state) {
        return state.dag.actionList;
      },
      actionLink(state) {
        return state.dag.actionLink;
      },
      drag(state) {
        return state.dag.node.show;
      },
      svgX(state) {
        return state.dag.svgX;
      },
      svgY(state) {
        return state.dag.svgY;
      },
    }),
  },
  created() {
    this.jobTypeMenuList = this.$store.state.dag.jobTypeMenuList;
    this.jobMenuData = [{
      name: '配置',
      value: 'edit',
    }, {
      name: '删除',
      value: 'del',
    }, {
      name: '日志',
      value: 'log',
    }];
    this.linkMenuData = [{
      name: '删除',
      value: 'del',
    }];
  },
  methods: {
    getLeftIcon(item) {
      let iconFont = null;
      for (let i = 0, j = this.jobTypeMenuList.length; i < j; i += 1) {
        if (this.jobTypeMenuList[i].actionStageId === item.actionStageId) {
          iconFont = this.jobTypeMenuList[i].icon;
          break;
        }
      }
      return iconFont;
    },
    getRightIcon(item) {
      let icon = 'iconwarn';
      if (item.actionId > 0) {
        if (!item.status || item.status === '1') { // 未运行
          icon = 'iconstop';
        } else if (item.status === '2') { // 等待中
          icon = 'iconwait';
        } else if (item.status === '3') { // 执行中
          icon = 'iconrun';
        } else if (item.status === '4') { // 成功
          icon = 'iconsuccess';
        } else if (item.status === '5') { // 失败
          icon = 'iconfail';
        }
      }
      return icon;
    },
    linkFrom(e, job, mask) { // link触发点击
      this.linking = true;// 连线开始
      const nums = mask === 'top' ? -13 : 13;
      this.linkPos = {
        actionId: job.actionId,
        fromX: job.left,
        fromY: job.top + nums,
        toX: job.left,
        toY: job.top + nums
      };
    },
    linkmove(e) { // link移动
      if (this.linking) { // 连线状态
        this.linkPos.toX = e.offsetX - this.svgX;
        this.linkPos.toY = e.offsetY - this.svgY;
      }
    },
    hideLink() { // 隐藏link
      this.linking = false;
    },
    gMousemove(e, job) {
      if (this.linking) {
        if (e.target.className === 'dragNode') {
          this.linkPos.toX = job.left + e.offsetX - 75;
          this.linkPos.toY = job.top + e.offsetY - 15;
        } else if (e.target.className === 'topContent') {
          const toY = e.target.offsetTop > 15 ? 15 : -15;
          this.linkPos.toX = job.left + e.offsetX - 75;
          this.linkPos.toY = job.top + toY;
        }
      }
    },
    linkTo(e, job) {
      if (this.linking) { // 连线状态
        this.linking = false;
        if (job) {
          this.$store.dispatch('pushLinkInfo', [this, {
            source: this.linkPos.actionId,
            target: job.actionId
          }]);
        }
      }
    },
    itemClick(item, data) { // 右击菜单
      const { flowActionId, publish } = this.$store.state.dag;
      if (data.value === 'del') {
        if (publish === 1) { // 禁止编辑状态
          this.$message({
            type: 'warning',
            message: '发布状态禁止删除！'
          });
          return;
        }
        if (this.$parent.editDisabled) { // 禁止编辑状态
          this.$message({
            type: 'warning',
            message: '运行状态禁止删除！'
          });
          return;
        }
        if (String(item.actionId) === String(flowActionId)) {
          this.$message({
            type: 'warning',
            message: '虚拟节点不能删除！'
          });
          return;
        }
        let Name = '连线';
        let actionName = 'delLink';
        if (item.name) { // 删除节点
          Name = item.name;
          actionName = 'delJob';
        }
        this.$alert('确定删除吗?', Name, {
          confirmButtonText: '确定',
          callback: (action) => {
            if (action === 'confirm') {
              this.$store.dispatch(actionName, item);
            }
          }
        });
      } else if (data.value === 'edit') { // 配置
        // 虚拟节点调转到信息对话框
        if (this.$parent.editDisabled) { // 禁止编辑状态
          this.$message({
            type: 'warning',
            message: '运行状态禁止编辑！'
          });
          return;
        }
        this.$emit(item.actionStageId === '35' ? 'flow' : 'edit', item);
      } else if (data.value === 'log') { // 日志
        if (!(item.actionId > 0)) {
          this.$message({
            type: 'warning',
            message: '节点未配置，无日志！'
          });
          return;
        }
        if (String(item.actionId) === String(flowActionId)) {
          this.$message({
            type: 'warning',
            message: '虚拟节点无日志！'
          });
          return;
        }
        this.$emit('log', item);
      }
    },
    mouseSingleOrDouble(e, job) { // 单击或者双击
      if (e.button !== 0) { // 非左单击
        return;
      }
      if (!this.timeout) {
        this.timeout = setTimeout(() => {
          clearTimeout(this.timeout);
          this.timeout = null;
        }, 300);
        if (this.$parent.logDialogVisible) { // 日志弹框显示状态
          this.itemClick(job, { value: 'log' });// 展示点击节点的日志信息
        }
        // 准备拖动
        this.mousedown(e, job);
      } else { // 双击编辑
        clearTimeout(this.timeout);
        this.timeout = null;
        this.itemClick(job, { value: 'edit' });
      }
    },
    mousedown(e, job) {
      const { node } = this.$store.state.dag;
      this.$store.commit('changeNode', Object.assign({}, node, {
        rightIcon: this.getRightIcon(job),
        name: job.name,
        show: true,
        top: e.pageY,
        left: e.pageX,
        actionId: job.actionId,
        actionStageId: job.actionStageId
      }));
    }
  },
};
</script>
<style scoped lang="less">
.nodeContainer {
  width: 150px;
  height: 32px;
  border-radius: 2px;
  background: #44444F;
  .topContent {
    width: 150px;
    height: 5px;
    background: #3e3737;
    //margin-left: calc(50% - 15px);
    cursor: crosshair;
  }
  &.noEvent {
    pointer-events: none;
  }
  .dragNode {
      user-select: none;
      width: 100%;
      line-height: 22px;
      padding: 0 6px;
      font-size: 14px;
      display: flex;
      justify-content: space-between;
      cursor: move;
      .nodeName {
        pointer-events: none;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
        padding: 0 2px 0 4px;
      }
      .iconfont {
        pointer-events: none;
        color: #8BADBE;
        &.iconwarn {
          color: #F2984E;
        }
        &.iconsuccess {
          color: #0BB273;
        }
        &.iconstop {
          color: #D8D8D8;
        }
        &.iconfail {
          color: #F24E4E;
        }
        &.iconrun {
          color: #4ea4f2;
        }
        &.iconwait {
          color: #F2984E;
        }
      }
    }
  }
</style>
