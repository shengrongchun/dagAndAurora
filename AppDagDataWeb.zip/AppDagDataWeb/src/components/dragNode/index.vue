<template>
  <div
    v-if="node.show"
    :style="{'top': posXy[1]+'px','left': posXy[0]+'px'}"
    class="dragNode">
    <i :class="'iconfont '+getLeftIcon(node)" />
    <span>{{ node.name }}</span>
    <i
      :style="{'visibility':node.rightIcon?'':'hidden'}"
      :class="'iconfont '+(node.rightIcon || node.icon)" />
  </div>
</template>
<script>
export default {
  props: {
    node: {
      type: Object,
      default() {
        return {};
      }
    }
  },
  computed: {
    posXy() {
      const left = this.node.left - 75;
      const top = this.node.top - 15;
      return [left < 0 ? 5 : left, top < 0 ? 5 : top];
    }
  },
  created() {
    this.jobTypeMenuList = this.$store.state.dag.jobTypeMenuList;
  },
  methods: {
    getLeftIcon(item) {
      let iconFont = null;
      for (let i = 0, j = this.jobTypeMenuList.length; i < j; i += 1) {
        if (this.jobTypeMenuList[i].actionStageId === item.actionStageId) {
          iconFont = this.jobTypeMenuList[i].icon;
          break;
        }
      }
      return iconFont;
    },
  }
};
</script>
<style scoped lang="less">
  .dragNode {
    pointer-events: none;
    z-index: 10000;
    position: fixed;
    top: 0;
    left: 0;
    width: 150px;
    line-height: 30px;
    background: #44444F;
    border: 1px dashed #8BADBE;
    padding: 0 8px;
    font-size: 14px;
    display: flex;
    justify-content: space-between;
    cursor: move;
    color: #8BADBE;
  }
</style>
