<template>
  <div
    class="dragItem"
    @mousedown="mousedown">
    <slot />
  </div>
</template>
<script>
const re = /^[0-9]+.?[0-9]*/;// 判断字符串是否为数字//判断正整数/[1−9]+[0−9]∗]∗/
export default {
  props: {
    dragData: {
      type: Object,
      default() {
        return {};
      }
    }
  },
  methods: {
    mousedown(e) {
      const { node, actionList } = this.$store.state.dag;
      const { actionStageId, name } = this.dragData;
      // 防止重名
      let num = 0;
      actionList.forEach((job) => {
        if (job.name.indexOf(name) > -1) {
          const index = parseFloat(job.name.replace(name, ''));
          if (re.test(index) && index >= num) {
            num = index + 1;
          }
        }
      });
      this.$store.commit('changeNode', Object.assign({}, node, {
        name: name + num,
        actionStageId,
        show: true,
        top: e.pageY,
        left: e.pageX
      }));
    }
  }
};
</script>
<style scoped lang="less">
.dragItem {
  cursor: move;
}
</style>
