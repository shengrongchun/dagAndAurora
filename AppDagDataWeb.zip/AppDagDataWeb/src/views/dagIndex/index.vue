<template>
  <div
    :class="{'pointer':drag}"
    @contextmenu="contextmenu"
    class="dagContainer">
    <template
      v-if="showSvg">
      <span class="posTips">偏移量：{{ svgLeft }} {{ svgTop }}</span>
      <ul class="statusTips">
        <li>
          <i class="iconfont iconsuccess" />
          执行成功
        </li>
        <li>
          <i class="iconfont iconfail" />
          执行失败
        </li>
        <li>
          <i class="iconfont iconstop" />
          未运行
        </li>
        <li>
          <i class="iconfont iconwait" />
          等待中
        </li>
        <li>
          <i class="iconfont iconrun" />
          执行中
        </li>
        <li>
          <i class="iconfont iconwarn" />
          未配置
        </li>
      </ul>
      <ul
        class="configTips">
        <li
          class="info"
          @click="openFlow('info')">基础信息</li>
        <li
          class="dispatch"
          @click="openFlow('flow')">调度配置</li>
      </ul>
      <svg
        id="dagContainer"
        width="100%"
        height="100%"
        xmlns="http://www.w3.org/2000/svg"
        xmlns:xlink="http://www.w3.org/1999/xlink"
        version="1.1"
        data-spm-anchor-id="TODO.11007039.0.i6.12b64a9bcbXQmm"
        @mousedown.stop="svgdown"
        @mousemove="svgmove"
        @mouseup="svgup"
        @mouseleave="svgleave">
        <drag-node-list
          ref="nodeList"
          @flow="openFlow('flow')"
          @log="openLog"
          @edit="openEdit" />
      </svg>
      <dragNode :node="node" />
      <logDialog
        :dialog-visible="logDialogVisible"
        :item="logData"
        :change="logChange"
        @close="logDialogVisible=false"/>
      <jobDialog
        v-if="jobDialogVisible"
        :dialog-visible="jobDialogVisible"
        :item="jobData"
        @close="jobDialogVisible=false"/>
      <exChangeDialog
        v-if="exChangeDialogVisible"
        :dialog-visible="exChangeDialogVisible"
        :item="jobData"
        @close="exChangeDialogVisible=false"/>
    </template>
    <template>
      <ul
        v-loading="menuLoading"
        element-loading-spinner="el-icon-loading"
        class="menu-container">
        <li
          class="menu-li"
          @click="createFlow('info')">
          <div class="icon size20">
            <i class="el-icon-circle-plus-outline" />
          </div>
          <span>新建</span>
        </li>
        <li
          class="menu-li"
          :class="{'disabled':runing||!flowActionId||offline}"
          @click="clickStatus('testRun')">
          <div class="icon size20">
            <i class="el-icon-video-play" />
          </div>
          <span>{{ continuing ?'继续':'测试' }}运行</span>
        </li>
        <li
        class="menu-li"
        :class="{'disabled':stoping||!flowActionId}"
        @click="clickStatus('stop')">
          <div class="icon size20">
            <i class="el-icon-video-pause" />
          </div>
          <span>暂停</span>
        </li>
        <li
        class="menu-li"
        :class="{'disabled':killing||!flowActionId}"
        @click="clickStatus('kill')">
          <div class="icon size20">
            <i class="el-icon-circle-close" />
          </div>
          <span>结束</span>
        </li>
        <li
        class="menu-li"
        :class="{'disabled':!publish||!flowActionId}"
        @click="clickStatus('publish')">
          <div class="icon">
            <i class="iconfont iconpublish" />
          </div>
          <span>发布</span>
        </li>
        <li
          class="menu-li"
          :class="{'disabled':!offline||!flowActionId}"
          @click="clickStatus('offline')"
          >
          <div class="icon size20">
            <i class="el-icon-download" />
          </div>
          <span>下线</span>
        </li>
      </ul>
    </template>
    <flowDialog
      v-if="dialogVisible"
      :dialog-visible="dialogVisible"
      :type="type"
      @close="dialogVisible=false;"/>
  </div>
</template>

<script>
import {
  flowRuning, flowStoping, flowEnding, flowContinue, flowPublishing
} from '@/api/dag';
import { mapState } from 'vuex';
import dragNode from '@/components/dragNode';
import dragNodeList from '@/components/dragNodeList';
import flowDialog from './dialog/flowDialog';
import jobDialog from './dialog/jobDialog';
import logDialog from './dialog/logDialog';
import exChangeDialog from './dialog/exChangeDialog';

export default {
  components: {
    dragNode,
    dragNodeList,
    flowDialog,
    jobDialog,
    logDialog,
    exChangeDialog
  },
  data() {
    return {
      dialogVisible: false,
      jobDialogVisible: false,
      exChangeDialogVisible: false,
      jobData: {},
      type: null,
      drag: false,
      // log
      logDialogVisible: false,
      logChange: false,
      logData: null,
      //
      menuLoading: false, // 菜单loading
      // 各种状态
      runing: false, // 运行中
      stoping: true, // 暂停
      killing: true, // 结束
      continuing: false, // 继续运行
    };
  },
  computed: {
    ...mapState({
      publish(state) {
        if (state.dag.flowStatus === '4' || state.dag.flowStatus === '5') {
          this.runing = false; // 运行中
          this.stoping = true; // 暂停
          this.killing = true; // 结束
          this.continuing = false; // 继续运行
        } else if (state.dag.flowStatus === '3' && !this.runing) {
          this.continuing = true;
          this.clickStatus('testRun');// 继续运行
        }
        return state.dag.flowStatus === '4' && state.dag.publish === 0;
      },
      offline(state) {
        return state.dag.publish === 1;
      },
      flowActionId(state) {
        return state.dag.flowActionId;
      },
      editDisabled(state) {
        const status = state.dag.flowStatus;
        if (!status || status === '4' || status === '5') {
          return false;
        }
        return true;
      },
      node(state) {
        return state.dag.node;
      },
      showSvg(state) {
        return state.dag.jobSetDataObj[state.dag.flowActionId];
      },
      svgLeft(state) {
        return state.dag.svgX;
      },
      svgTop(state) {
        return state.dag.svgY;
      }
    }),
  },
  created() {
    this.$store.dispatch('getFlowList');
  },
  mounted() {
    // 刷新页面提示
    // window.onbeforeunload = () => '关闭提示';
  },
  methods: {
    contextmenu(event) { // 组织右击事件
      event.preventDefault();
    },
    // 各种状态点击
    clickStatus(mask) {
      this.menuLoading = true;
      if (mask === 'testRun') { // 运行
        const { actionList } = this.$store.state.dag;
        let ok = true;
        for (let i = 0, j = actionList.length; i < j; i += 1) {
          if (!(actionList[i].actionId > 0)) {
            this.$message({
              type: 'warning',
              message: '检测到有节点未配置'
            });
            this.menuLoading = false;
            ok = false;
            break;
          }
        }
        //
        if (!ok) return;
        if (this.continuing) { // 继续运行
          flowContinue({ actionId: this.flowActionId }).then(() => {
            this.runing = true;
            this.stoping = false;
            this.killing = false;
            this.continuing = false;
            this.$store.dispatch('updateFlowStatus');
            this.$message({
              type: 'success',
              message: '继续运行'
            });
          }).finally(() => {
            this.menuLoading = false;
          });
        } else { // 测试运行
          flowRuning({ actionId: this.flowActionId }).then(() => {
            this.runing = true;
            this.stoping = false;
            this.killing = false;
            this.$store.dispatch('updateFlowStatus');
            this.$message({
              type: 'success',
              message: '正在运行'
            });
          }).finally(() => {
            this.menuLoading = false;
          });
        }
      } else if (mask === 'kill') { // 结束
        flowEnding({ actionId: this.flowActionId }).then(() => {
          this.runing = false;
          this.stoping = true;
          this.killing = true;
          this.continuing = false;
          this.$store.commit('clearTime');
          this.$message({
            type: 'success',
            message: '结束成功'
          });
        }).finally(() => {
          this.menuLoading = false;
        });
      } else if (mask === 'stop') { // 暂停
        flowStoping({ actionId: this.flowActionId }).then(() => {
          this.stoping = true;
          this.runing = false;
          this.killing = false;
          this.continuing = true;
          this.$store.commit('clearTime');
          this.$message({
            type: 'success',
            message: '已暂停'
          });
        }).finally(() => {
          this.menuLoading = false;
        });
      } else if (mask === 'publish' || mask === 'offline') { // 发布
        const val = mask === 'publish' ? 1 : 0;
        flowPublishing({ actionId: this.flowActionId, progress: val }).then(() => {
          this.runing = false;
          this.stoping = true;
          this.killing = true;
          this.continuing = false;
          this.$store.commit('publishSuccess', val);
          this.$message({
            type: 'success',
            message: val === 1 ? '发布成功' : '下线成功'
          });
        }).finally(() => {
          this.menuLoading = false;
        });
      }
    },
    // 点击新建
    createFlow(type) {
      if (this.flowActionId) {
        this.$alert('确定离开当前页面?', '新建', {
          confirmButtonText: '确定',
          callback: (action) => {
            if (action === 'confirm') {
              this.$store.commit('initflowData');
              this.openFlow(type);
            }
          }
        });
      } else { // 新建
        this.openFlow(type);
      }
    },
    // 各种弹框
    openEdit(data) { // 节点编辑弹框
      if (data.actionStageId === '29') { // 数据交换 弹框
        this.exChangeDialogVisible = true;
      } else { // 其他节点弹框
        this.jobDialogVisible = true;
      }
      this.jobData = data;
    },
    openFlow(type) { // flow弹框，基础信息或者配置信息
      if (this.editDisabled) { // 禁止编辑状态
        this.$message({
          type: 'warning',
          message: '运行状态禁止配置！'
        });
        return;
      }
      this.dialogVisible = true;
      this.type = type;
    },
    openLog(data) { // 打开日志弹框
      this.logDialogVisible = true;
      this.logChange = !this.logChange;
      this.logData = data;
    },
    // 鼠标事件
    svgdown(e) { // svg点击开始拖动
      this.drag = true;
      this.startX = e.pageX;
      this.startY = e.pageY;
    },
    svgmove(e) {
      if (this.drag) { // svg拖动
        const { svgX, svgY } = this.$store.state.dag;
        const svgLeft = svgX + (e.pageX - this.startX);
        const svgTop = svgY + (e.pageY - this.startY);
        this.startX = e.pageX;
        this.startY = e.pageY;
        this.$store.commit('changeSvgPos', [svgLeft, svgTop]);
      } else { // link线的移动
        this.$refs.nodeList.linkmove(e);
      }
    },
    svgup(e) {
      if (this.drag) { // svg拖动
        this.drag = false;
      } else { // link线鼠标up
        this.$refs.nodeList.hideLink(e);
      }
    },
    svgleave(e) {
      this.$refs.nodeList.hideLink(e);
    }
  },
};
</script>

<style scoped lang="less">
.dagContainer {
  color: #fff;
  background: #191623;
  width: 100%;
  height: 100%;
  position: relative;
  ul {
    margin: 0;
    padding: 0;
    user-select: none;
    font-size: 12px;
    list-style: none;
  }
  .posTips {
    user-select: none;
    position: absolute;
    font-size: 12px;
    bottom: 5px;
    right: 5px;
    color: #8badbe;
  }
  .statusTips {
    position: absolute;
    top: 15px;
    right: 45px;
    background: #292632;
    padding: 15px 15px 0 15px;
    li {
      margin-bottom: 15px;
      line-height: 0.9;
      .iconfont {
        display: inline-block;
        vertical-align: text-bottom;
        margin-right: 8px;
        &.iconsuccess {
          color: #0bb273;
        }
        &.iconfail {
          color: #f24e4e;
        }
        &.iconstop {
          color: #d8d8d8;
        }
        &.iconwait, &.iconwarn {
          color: #f2984e;
        }
        &.iconrun {
          color: #4ea4f2;
        }
      }
    }
  }
  .configTips {
    position: absolute;
    top: 15px;
    right: 8px;
    .info {
      background: #4b9e96;
    }
    .node {
      background: #ff9300;
    }
    .dispatch {
      background: #4b8dc9;
    }
    li {
      cursor: pointer;
      padding: 8px 5px;
      width: 22px;
      font-weight: bolder;
      text-align: center;
    }
  }
  &.pointer {
    cursor: grab;
  }
  .menu-container {
    position: fixed;
    height: 50px;
    line-height: 1;
    right: 65px;
    top: 0;
    z-index: 1000;
    /deep/ .el-loading-mask {
      background: #312f38;
      opacity: 0.8;
      .el-loading-spinner {
        height: 100%;
        margin-top: -10px;
        i {
          color: #409eff;
          font-size: 20px;
        }
      }
    }
    .menu-li {
      display: inline-block;
      height: 50px;
      text-align: center;
      margin-right: 25px;
      cursor: pointer;
      user-select: none;
      &.disabled {
        pointer-events: none;
        .icon {
          color: #83868e;
        }
        span {
          color: #83868e;
        }
      }
      &:hover {
        .icon {
          color: #fff;
        }
        span {
          color: #fff;
        }
      }
      .icon {
        margin: 10px 0 2px 0;
        line-height: 1;
        color: #8BADBE;
        .iconfont {
          font-size: 16px;
        }
        &.size20 {
          margin-bottom: 0;
          font-size: 20px;
        }
      }
      span {
        display: inline-block;
        transform: scale(0.8);
        line-height: 1;
        color: #8BADBE;
        font-size: 12px;
        margin-top: 2px;
      }
    }
  }
}
</style>
