<template>
  <el-dialog
    title="任务配置"
    top="10px"
    v-loading="loading"
    element-loading-spinner="el-icon-loading"
    element-loading-background="rgba(255, 255, 255, 0.5)"
    :close-on-click-modal="false"
    :visible.sync="visible"
    width="65%">
    <el-form
      :class="{'noEvent':publish===1}"
      :model="form"
      :rules="rules"
      ref="form"
      label-width="110px"
      class="form">
      <el-form-item
        label="节点名字"
        prop="name">
        <el-input
          style="width:350px"
          v-model="form.name"/>
      </el-form-item>
      <el-form-item
        label="是否核心"
        prop="isCore">
        <el-radio-group v-model="form.isCore">
          <el-radio :label="1">是</el-radio>
          <el-radio :label="0">否</el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item
        label="节点类型">
        <span>数据交换</span>
      </el-form-item>
      <!--数据交换-->
      <template>
        <el-steps
          :active="active"
          align-center
          finish-status="success">
          <el-step
            :title="name"
            v-for="(name,idx) in stepNameList"
            :key="idx"/>
        </el-steps>
        <div class="setSource">
          <!--配置数据源-->
          <el-row
            v-if="active===0"
            :gutter="10">
            <!--数据源 左边-->
            <el-col :span="12">
              <el-card
                header="来源"
                body-style="{padding:10px;}"
                shadow="never">
                <el-form-item label="数据源类型">
                  <el-select
                    v-model="form.reader"
                    :disabled="item.actionId>0"
                    style="width:280px">
                    <el-option
                      label="JDBC"
                      value="JDBC"/>
                    <el-option
                      label="Hbase"
                      value="Hbase"/>
                    <el-option
                      label="HDFS"
                      value="HDFS"/>
                  </el-select>
                </el-form-item>
                <template v-if="form.reader==='JDBC'">
                  <el-form-item
                    key="dbId"
                    prop="dbId"
                    label="库名">
                    <el-select
                      filterable
                      placeholder="请选择库名"
                      style="width:280px"
                      @change="leftChangeDbId(null,true)"
                      @focus="focus=true"
                      v-model="form.dbId">
                      <el-option
                        :key="idx"
                        :value="Item.id"
                        :label="Item.dbName"
                        v-for="(Item,idx) in sourceList">
                        <span style="float:left;margin-right:10px">{{ Item.id }}</span>
                        <span style="margin-right:10px;color:#8492a6;font-size:13px">
                          {{ Item.metaName }}</span>
                        <span style="color:#8492a6;font-size:13px">{{ Item.dbName }}</span>
                        </el-option>
                    </el-select>
                  </el-form-item>
                  <el-form-item
                    key="dbTable"
                    prop="dbTable"
                    label="表名">
                    <el-select
                      filterable
                      multiple
                      collapse-tags
                      placeholder="请选择表名"
                      style="width:280px"
                      @focus="focus=true"
                      @change="leftChangeDbTable(true)"
                      v-model="form.dbTable">
                      <el-option
                        :key="idx"
                        :value="Item.id"
                        :label="Item.text"
                        v-for="(Item,idx) in leftTableList"/>
                    </el-select>
                  </el-form-item>
                  <el-form-item
                      label="过滤条件"
                      key="dbWhere"
                      prop="dbWhere">
                    <el-input
                      v-model.trim="form.dbWhere"
                      type="textarea"
                      autosize
                      style="width:280px"
                      :rows="1"/>
                  </el-form-item>
                </template>
                <template v-if="form.reader==='Hbase'">
                  <el-form-item
                    label="表名"
                    key="hbaseTable"
                    prop="hbaseTable">
                    <el-select
                      filterable
                      placeholder="请选择表名"
                      style="width:280px"
                      @change="changeVal=true"
                      @focus="focus=true"
                      v-model.trim="form.hbaseTable">
                      <el-option
                        :key="idx"
                        :value="Item"
                        :label="Item"
                        v-for="(Item,idx) in hbaseTableList"/>
                    </el-select>
                  </el-form-item>
                  <el-form-item
                    label="列名"
                    key="hbaseCoulmn"
                    prop="hbaseCoulmn">
                    <el-input
                      @change="changeVal=true"
                      @focus="focus=true"
                      placeholder="请输入列名，多个以 ; 隔开"
                      v-model.trim="form.hbaseCoulmn"
                      style="width:280px"/>
                  </el-form-item>
                  <el-form-item
                    label="startRowkey"
                    key="startRowkey"
                    prop="startRowkey">
                    <el-input
                      placeholder="请输入startRowkey"
                      v-model.trim="form.startRowkey"
                      style="width:280px"/>
                  </el-form-item>
                  <el-form-item
                    label="endRowkey"
                    key="endRowkey"
                    prop="endRowkey">
                    <el-input
                      placeholder="请输入endRowkey"
                      v-model.trim="form.endRowkey"
                      style="width:280px"/>
                  </el-form-item>
                  <el-form-item
                    key="scanCacheSize"
                    label="scanCacheSize">
                    <el-input
                      v-model.trim="form.scanCacheSize"
                      style="width:280px"
                      placeholder="Hbase client每次rpc从服务器端读取的行数，默认1000"/>
                  </el-form-item>
                  <el-form-item
                    key="scanBatchSize"
                    label="scanBatchSize">
                    <el-input
                      v-model.trim="form.scanBatchSize"
                      style="width:280px"
                      placeholder="Hbase client每次rpc从服务器端读取的列数，默认1440"/>
                  </el-form-item>
                </template>
                <template v-if="form.reader==='HDFS'">
                  <el-form-item
                    key="hdfsReaderDb"
                    prop="hdfsReaderDb"
                    label="库名">
                    <el-select
                      filterable
                      placeholder="请选择库名"
                      style="width:280px"
                      @change="hdfsLeftChangeDbId(null,true)"
                      @focus="focus=true"
                      v-model="form.hdfsReaderDb">
                      <el-option
                        :key="idx"
                        :value="Item"
                        :label="Item"
                        v-for="(Item,idx) in hdfsSourceList"/>
                    </el-select>
                  </el-form-item>
                  <el-form-item
                    key="hdfsReaderTable"
                    prop="hdfsReaderTable"
                    label="表名">
                    <el-select
                      filterable
                      style="width:280px"
                      placeholder="请选择表名,可模糊查询"
                      @change="hdfsLeftChangeDbTable(true)"
                      @visible-change="hdfsLeftFocus"
                      remote
                      :readonly="leftLoading"
                      :remote-method="leftHdfsRemoteMethod"
                      :loading="leftLoading"
                      v-model="form.hdfsReaderTable">
                      <el-option
                        :key="idx"
                        :value="Item"
                        :label="Item"
                        v-for="(Item,idx) in hdfsLeftTableList"/>
                    </el-select>
                  </el-form-item>
                  <el-form-item
                    label="分区信息"
                    key="hdfsReaderPartition"
                    prop="hdfsReaderPartition">
                    <el-input
                      style="width:280px"
                      placeholder="请输入分区信息"
                      v-model.trim="form.hdfsReaderPartition"
                      type="textarea"
                      autosize
                      :rows="1"/>
                  </el-form-item>
                </template>
              </el-card>
            </el-col>
            <!--数据源 右边-->
            <el-col :span="12">
              <el-card
                header="目的"
                shadow="never">
                <el-form-item label="数据源类型">
                  <el-select
                    style="width:280px"
                    :disabled="item.actionId>0"
                    v-model="form.writer">
                    <el-option
                      label="JDBC"
                      value="JDBC_Writer"/>
                    <el-option
                      label="Hbase"
                      value="Hbase_Writer"/>
                    <el-option
                      label="HDFS"
                      value="HDFS_Writer"/>
                  </el-select>
                </el-form-item>
                <template v-if="form.writer==='JDBC_Writer'">
                  <el-form-item
                    prop="jdbcWriterDbId"
                    key="jdbcWriterDbId"
                    label="库名">
                    <el-select
                      filterable
                      style="width:280px"
                      placeholder="请选择库名"
                      @change="rightChangeDbId(null,true)"
                      @focus="focus=true"
                      v-model="form.jdbcWriterDbId">
                      <el-option
                        :key="idx"
                        :value="Item.id"
                        :label="Item.dbName"
                        v-for="(Item,idx) in sourceList">
                        <span style="float:left;margin-right:10px">{{ Item.id }}</span>
                        <span style="margin-right:10px;color:#8492a6;font-size:13px">
                          {{ Item.metaName }}</span>
                        <span style="color:#8492a6;font-size:13px">{{ Item.dbName }}</span>
                        </el-option>
                    </el-select>
                  </el-form-item>
                  <el-form-item
                    prop="jdbcWriterTable"
                    key="jdbcWriterTable"
                    label="表名">
                    <el-select
                      filterable
                      style="width:280px"
                      placeholder="请选择表名"
                      @change="rightChangeDbTable(true)"
                      @focus="focus=true"
                      v-model="form.jdbcWriterTable">
                      <el-option
                        :key="idx"
                        :value="Item.id"
                        :label="Item.text"
                        v-for="(Item,idx) in rightTableList"/>
                    </el-select>
                  </el-form-item>
                  <el-form-item label="前置语句">
                    <el-input
                    style="width:280px"
                    v-model.trim="form.jdbcWriterPresql"/>
                  </el-form-item>
                </template>
                <template v-if="form.writer==='HDFS_Writer'">
                  <el-form-item
                    key="hdfsWriterDb"
                    prop="hdfsWriterDb"
                    label="库名">
                    <el-select
                      filterable
                      style="width:280px"
                      placeholder="请选择库名"
                      @change="hdfsRightChangeDbId(null,true)"
                      @focus="focus=true"
                      v-model="form.hdfsWriterDb">
                      <el-option
                        :key="idx"
                        :value="Item"
                        :label="Item"
                        v-for="(Item,idx) in hdfsSourceList"/>
                    </el-select>
                  </el-form-item>
                  <el-form-item
                    key="hdfsWriterTable"
                    prop="hdfsWriterTable"
                    label="表名">
                    <el-select
                      filterable
                      placeholder="请选择表名,可模糊查询"
                      style="width:280px"
                      @change="hdfsRightChangeDbTable(true)"
                      @visible-change="hdfsRightFocus"
                      remote
                      :loading="rightLoading"
                      :readonly="rightLoading"
                      :remote-method="rightHdfsRemoteMethod"
                      v-model="form.hdfsWriterTable">
                      <el-option
                        :key="idx"
                        :value="Item"
                        :label="Item"
                        v-for="(Item,idx) in hdfsRightTableList"/>
                    </el-select>
                  </el-form-item>
                  <el-form-item
                    label="分区信息"
                    key="hdfsWriterPartition"
                    prop="hdfsWriterPartition">
                    <el-input
                      style="width:280px"
                      v-model="form.hdfsWriterPartition"
                      type="textarea"
                      autosize
                      :rows="1"/>
                  </el-form-item>
                </template>
                <template v-if="form.writer==='Hbase_Writer'">
                  <el-form-item
                    label="表名"
                    key="hbaseWriterTable"
                    prop="hbaseWriterTable">
                    <el-select
                      filterable
                      style="width:280px"
                      placeholder="请选择表名"
                      @focus="focus=true"
                      @change="changeVal=true"
                      v-model.trim="form.hbaseWriterTable">
                      <el-option
                        :key="idx"
                        :value="Item"
                        :label="Item"
                        v-for="(Item,idx) in hbaseTableList"/>
                    </el-select>
                  </el-form-item>
                  <el-form-item
                    label="列名"
                    key="hbaseWriterCoulmn"
                    prop="hbaseWriterCoulmn">
                    <el-input
                      @change="changeVal=true"
                      @focus="focus=true"
                      placeholder="请输入列名，多个以 ; 隔开"
                      v-model.trim="form.hbaseWriterCoulmn"
                      style="width:280px"/>
                  </el-form-item>
                </template>
              </el-card>
            </el-col>
          </el-row>
          <!--参数优化-->
          <template v-if="active===stepNameList.length-1">
            <el-form-item
              label="并发量"
              key="channel"
              prop="channel">
              <el-select
                style="width:350px"
                filterable
                v-model="form.channel">
                <el-option
                  v-for="(Item,idx) in 32"
                  :value="Item"
                  :key="idx">{{ Item }}</el-option>
              </el-select>
            </el-form-item>
            <el-form-item
              label="更多参数"
              prop="params">
              <div
                class="paramsRow">
                <i
                v-if="form.paramsList.length===0"
                @click="addParams"
                class="el-icon-circle-plus-outline"/>
                <div
                  v-else
                  class="row"
                  v-for="(value,idx) in form.paramsList"
                  :key="idx">
                  <el-input
                    style="width:350px"
                    v-model="form.paramsList[idx]"
                    placeholder="参数值"/>
                  <i
                    @click="delParams(idx)"
                    class="el-icon-remove-outline"/>
                  <i
                    v-if="idx===form.paramsList.length-1"
                    @click="addParams"
                    class="el-icon-circle-plus-outline"/>
                </div>
              </div>
            </el-form-item>
          </template>
          <!--字段映射-->
          <template v-if="active===1">
            <!--来源-->
            <el-transfer
              filterable
              class="left"
              filter-placeholder="请搜索列"
              :titles="['来源']"
              :props="{key:'id',label:'coulmn'}"
              :left-default-checked="leftDefaultChecked"
              @left-check-change="leftAciveChange"
              :data="leftMapinglist">
              <el-row
                slot-scope="{ option }"
                style="margin-bottom:5px;">
                <el-col :span="10">
                  <el-input
                    disabled
                    v-model="option.coulmn"/>
                </el-col>
                <el-col
                  :span="2"
                  style="text-align:center;">
                -
                </el-col>
                <el-col :span="11">
                  <el-input
                    disabled
                    v-model="option.type"/>
                </el-col>
              </el-row>
            </el-transfer>
             <!--目的-->
            <el-transfer
              filterable
              class="right"
              filter-placeholder="请搜索列"
              :titles="['目的']"
              :props="{key:'id',label:'coulmn'}"
              :data="rightlist">
              <el-row
                slot-scope="{ option }"
                :style="{'visibility':!showOk(option)?'hidden':''}"
                style="margin-bottom:5px;">
                <el-col :span="10">
                  <el-select
                    @change="selectMaping(option)"
                    no-data-text="无可用下拉选项"
                    :class="{'error':!option.coulmn}"
                    v-model="option.coulmn">
                    <el-option
                      v-for="(Item,idx) in rightOptionlist"
                      :value="Item.coulmn"
                      :disabled="optionDisabled(option.coulmn,Item.coulmn)"
                      :key="idx">{{ Item.coulmn }}</el-option>
                  </el-select>
                </el-col>
                <el-col
                  :span="2"
                  style="text-align:center;">
                -
                </el-col>
                <el-col :span="11">
                  <el-input
                    disabled
                    v-model="option.type"/>
                </el-col>
              </el-row>
            </el-transfer>
          </template>
        </div>
      </template>
    </el-form>
    <span
      slot="footer"
      class="dialog-footer">
      <el-button
        v-if="active>0"
        @click="previous">上一步</el-button>
      <el-button
        v-if="active<stepNameList.length-1"
        @click="next">下一步</el-button>
      <el-button @click="visible=false">取 消</el-button>
      <el-button
        v-if="active===stepNameList.length-1"
        type="primary"
        :class="{'noEvent':publish===1}"
        :disabled="loading"
        @click="confim">保 存</el-button>
    </span>
  </el-dialog>
</template>
<script>
import {
  saveFlowInfo, getDataSource, getTableList, getDbTable, getCacheDataById,
  getHdfsDataSource, getHdfsTableList, getHdfsDbTable, getHbaseTableList
} from '@/api/dag';
import options from './options';

export default {
  props: {
    dialogVisible: {
      type: Boolean,
      default: false
    },
    item: {
      type: Object,
      default() {
        return {};
      }
    }
  },
  data() {
    return {
      form: {
        name: this.item.name, // 节点名称
        isCore: 0, // 否
        // 数据交换
        reader: 'JDBC',
        writer: 'HDFS_Writer',
        // JDBC 左
        dbId: null, // JDBC 数据源 (左)
        dbTable: [], // JDBC 表名 (左)
        dbWhere: null, // 过滤条件
        // JDBC 右
        jdbcWriterPresql: null, // 前置语句
        jdbcWriterDbId: null, // 右边数据源
        jdbcWriterTable: null, // 右边表名
        // HDFS 左
        hdfsReaderDb: null, // hdfs 库名
        hdfsReaderTable: null, // hdfs 表名
        hdfsReaderPartition: null, // 分区信息
        // HDFS 右
        hdfsWriterDb: null, // hdfs 库名
        hdfsWriterTable: null, // hdfs 表名
        hdfsWriterPartition: null, // 分区信息
        // Hbase 左
        hbaseTable: null, // hbase表名
        hbaseCoulmn: null, // hbase列
        startRowkey: null,
        endRowkey: null,
        scanCacheSize: null,
        scanBatchSize: null,
        // Hbase 右
        hbaseWriterTable: null, // 表名
        hbaseWriterCoulmn: null, // 表列
        //
        channel: null, // 并发量
        paramsList: [], // 参数
        //
        dbCoulmn: null, // JDBC左边字段映射
        jdbcWriterCoulmn: null, // JDBC右边字段映射
        //
        hdfsReaderCoulmn: null, // HDFS左边字段映射
        hdfsWriterCoulmn: null, // HDFS右边字段映射
      },
      //
      focus: false,
      changeVal: false,
      //
      loading: false,
      rightLoading: false,
      leftLoading: false,
      active: 0, // tab active值
      sourceList: [], // 数据源数据
      hbaseTableList: [], // hbase表名列表
      hdfsSourceList: [], // hdfs库名
      hdfsLeftTableList: [], // hdfs左边表名
      hdfsRightTableList: [], // hdfs右边表名
      rightCacheList: [], // 缓存
      leftCacheList: [], // 缓存
      leftTableList: [], // 表名
      leftMapinglist: [], // 字段映射左边列表
      rightTableList: [], // 右边表名
      rightMapinglist: [], // 字段映射右边列表
      rightlist: [], // 右边临时数据列表
      //
      leftDefaultChecked: [], // 左边默认选中项,elemnt-ui这个组件这个参数并不是响应式的
    };
  },
  computed: {
    publish() {
      return this.$store.state.dag.publish;
    },
    rightOptionlist() {
      const haveList = [];// 获取选中名列表
      let num = -1;
      const rowkeyMap = {};
      const hbaseW = this.form.writer === 'Hbase_Writer';
      this.leftDefaultChecked.forEach((id) => {
        const { coulmn } = this.rightlist[id];
        if (coulmn) {
          const rowKeyOK = coulmn.indexOf('rowkey') > -1;// 是否是rowkey
          if (rowKeyOK && hbaseW) { // 是rowkey
            const tempNum = parseFloat(coulmn.replace('rowkey', ''));
            rowkeyMap[tempNum] = id;
            num = tempNum > num ? tempNum : num;
          } else {
            haveList.push(coulmn);
          }
        }
      });
      //
      const rowlist = Object.keys(rowkeyMap);
      if (hbaseW && rowlist.length > 0) {
        rowlist.forEach((item, idx) => {
          if (item !== idx) {
            this.setRightCoulmn(rowkeyMap[item], idx);
          }
          num = idx;
        });
      }
      //
      const tempList = [];
      this.rightMapinglist.forEach((item) => {
        if (!haveList.includes(item.coulmn)) { // 未被选中
          tempList.push(item);
        }
      });
      if (hbaseW) {
        num += 1;
        tempList.push({ coulmn: `rowkey${num}`, type: null });
      }
      return tempList;
    },
    stepNameList() {
      return ['配置数据源', '字段映射', '同步参数'];
    },
    visible: {
      get() {
        return this.dialogVisible;
      },
      set() {
        this.$emit('close');
      },
    },
  },
  created() {
    const reg = '^[a-zA-Z0-9_]+$';
    this.regExp = new RegExp(reg);
    this.rules = Object.assign(options.jobRules, {
      name: [
        { required: true, message: '请输入节点名字', trigger: 'blur' },
        { validator: this.nameUnique, trigger: 'blur' },
      ]
    });
    // 获取数据源
    this.getDataSource();
    //
    if (this.item.actionId > 0) { // 修改状态
      const { jobSetDataObj } = this.$store.state.dag;
      const cacheForm = jobSetDataObj[this.item.actionId];
      if (cacheForm) { // 本地缓存获取
        Object.assign(this.form, cacheForm);
        this.initCacheData();
      } else { // api调获取
        getCacheDataById(this.item).then((res) => {
          Object.assign(this.form, res.returnObj);
          this.initCacheData();
        });
      }
    }
  },
  destroyed() {
    this.setSameTimeScroll('removeEventListener');
  },
  methods: {
    //
    setRightCoulmn(id, idx) {
      this.rightlist[id].coulmn = `rowkey${idx}`;
    },
    optionDisabled(name, optionName) {
      if (!name || !optionName) { return false; }
      const optionHasRow = optionName.indexOf('rowkey') > -1;
      const nameHasRow = name.indexOf('rowkey') > -1;
      if (optionHasRow && nameHasRow) {
        return true;
      }
      return false;
    },
    //
    initCacheData() {
      // 初始化缓存数据 设置相应显示值和leftMapinglist、rightMapinglist
      if (this.form.reader === 'JDBC') {
        if (typeof this.form.dbTable === 'string') { // api获取数据需要转换
          this.form.dbTable = this.form.dbTable.split(',');
        }
        this.form.dbId = parseFloat(this.form.dbId);// api获取数据需要转换
        this.leftChangeDbId(this.form.dbTable, false);
        this.leftChangeDbTable(false);
      } else if (this.form.reader === 'HDFS') {
        this.hdfsLeftChangeDbId(this.form.hdfsReaderTable, false);
        this.hdfsLeftChangeDbTable(false);
      } else if (this.form.reader === 'Hbase') {
        const hbaseCoulmnTempList = JSON.parse(`[${this.form.hbaseCoulmn}]`);
        this.form.hbaseCoulmn = '';
        this.leftMapinglist = [];
        hbaseCoulmnTempList.forEach((item, idx) => {
          this.form.hbaseCoulmn += `${idx === 0 ? '' : ';'}${item.name}`;
          this.leftMapinglist.push({ coulmn: item.name, type: null });// 设置 leftMapinglist
        });
      }
      if (this.form.writer === 'JDBC_Writer') {
        this.form.jdbcWriterDbId = parseFloat(this.form.jdbcWriterDbId);// api获取数据需要转换
        this.rightChangeDbId(this.form.jdbcWriterTable, false);
        this.rightChangeDbTable(false);
      } else if (this.form.writer === 'HDFS_Writer') {
        this.hdfsRightChangeDbId(this.form.hdfsWriterTable, false);
        this.hdfsRightChangeDbTable(false);
      } else if (this.form.writer === 'Hbase_Writer') {
        this.hbaseWriterCoulmnTempList = this.form.hbaseWriterCoulmn === '' ? [] : JSON.parse(`[${this.form.hbaseWriterCoulmn}]`);
        this.form.hbaseWriterCoulmn = '';
        this.rightMapinglist = [];
        this.hbaseWriterCoulmnTempList.forEach((item, idx) => {
          this.form.hbaseWriterCoulmn += `${idx === 0 ? '' : ';'}${item.name}`;
          this.rightMapinglist.push({ coulmn: item.name, type: null });
        });
      }
      // 参数
      this.form.paramsList = this.form.jvmArgs.split(',');
    },
    setRightSelectData() { // 回显状态设置后边响应值
      let valueList = null;
      if (this.form.writer === 'JDBC_Writer' && this.form.jdbcWriterCoulmn) {
        valueList = this.form.jdbcWriterCoulmn.split(',');
        valueList.forEach((names, idx) => {
          valueList[idx] = {
            name: names,
            type: this.selectMaping({ coulmn: names }).type
          };
        });
      } else if (this.form.writer === 'HDFS_Writer' && this.form.hdfsWriterCoulmn) {
        valueList = JSON.parse(`[${this.form.hdfsWriterCoulmn}]`);
      } else if (this.form.writer === 'Hbase_Writer'
      && (this.hbaseWriterCoulmnTempList || this.form.hbaseWriterRowkey)) {
        valueList = {};
        const hbaseWriterRowkeyList = this.form.hbaseWriterRowkey.split(',{ "index":-1, "type":"string", "value":"_" }');
        hbaseWriterRowkeyList.forEach((str, idx) => {
          const item = JSON.parse(str);
          valueList[item.index] = Object.assign(item, { name: `rowkey${idx}` });
        });
        this.hbaseWriterCoulmnTempList.forEach((item) => {
          valueList[item.index] = item;
        });
      }
      //
      if (valueList) {
        this.leftDefaultChecked.forEach((id, idx) => {
          const tempId = this.form.writer === 'Hbase_Writer' ? id : idx;
          this.rightlist[id].coulmn = valueList[tempId].name;
          this.rightlist[id].type = valueList[tempId].type;
        });
      }
    },
    next() { // 下一步
      this.$refs.form.validate((valid) => {
        if (valid) {
          if (this.active === 0) { // 跳转到字段映射
            if (this.form.writer === 'Hbase_Writer' && this.form.hbaseWriterCoulmn && this.form.hbaseWriterCoulmn.indexOf('rowkey') > -1) {
              this.$message({
                type: 'error',
                message: 'Hbase 列名请不要输入带有关键字 rowkey 字段'
              });
              return;
            }
            this.setMapingData();
          } else if (this.active === 1) {
            const checkedLength = this.leftDefaultChecked.length;
            if (checkedLength < 1) { // 左边选中个数
              this.$message({
                type: 'error',
                message: '至少选择一个'
              });
              return;
            }
            let returnOk = false;
            let hasRowKey = false;
            //
            for (let i = 0; i < checkedLength; i += 1) {
              const item = this.rightlist[this.leftDefaultChecked[i]];
              if (!hasRowKey && item.coulmn.indexOf('rowkey') > -1) { // 说明有rowkey
                hasRowKey = true;
              }
              if (!item.coulmn || item.coulmn === '') {
                returnOk = true;
                this.$message({
                  type: 'error',
                  message: '列名必填或删掉此行'
                });
                break;
              }
            }
            if (this.form.writer === 'Hbase_Writer' && !hasRowKey) {
              this.$message({
                type: 'error',
                message: '至少选择一个rowkey'
              });
              return;
            }
            if (returnOk) {
              return;
            }
          }
          this.active += 1;
          // 设置字段映射两边跟着滚动
          this.setSameTimeScroll('addEventListener');
        }
      });
    },
    showCacheData() { // 回显缓存数据
      // 设置leftDefaultChecked
      let activeList = null;
      if (this.form.reader === 'JDBC' && this.form.dbCoulmn) {
        activeList = this.form.dbCoulmn.split(',') || [];
      } else if (this.form.reader === 'HDFS' && this.form.hdfsReaderCoulmn) {
        this.leftDefaultChecked = [];
        const hdfsActiveList = JSON.parse(`[${this.form.hdfsReaderCoulmn}]`);
        hdfsActiveList.forEach((obj) => {
          this.leftDefaultChecked.push(obj.index);
        });
      }
      this.leftMapinglist.forEach((item, id) => {
        item.id = id;
        if (activeList && activeList.includes(item.coulmn)) { // jdbc checked
          this.leftDefaultChecked.push(id);
        } else if (this.form.reader === 'Hbase') { // hbase checked 全选
          this.leftDefaultChecked.push(id);
        }
        //
        this.rightlist.push({
          id,
          coulmn: null,
          type: null
        });
      });
      // 设置右边相应值
      this.setRightSelectData();
    },
    setMapingData() { // 设置映射数据
      this.leftDefaultChecked = [];
      this.rightlist = [];
      //
      if (this.changeVal && this.focus) { // 非回显 生成左右列
        if (this.form.reader === 'Hbase') { // 左边是hbase无缓存状态下，要这里生成leftMapinglist
          this.leftMapinglist = [];
          const leftMapinglist = this.form.hbaseCoulmn.split(';') || [];
          leftMapinglist.forEach((coulmn) => {
            this.leftMapinglist.push({ coulmn, type: null });
          });
        }
        //
        if (this.form.writer === 'Hbase_Writer') { // 右边是hbase无缓存状态下，要这里生成rightMapinglist
          this.rightMapinglist = [];
          let rightMapinglist = [];
          if (this.form.hbaseWriterCoulmn) {
            rightMapinglist = this.form.hbaseWriterCoulmn.split(';');
          }
          rightMapinglist.forEach((coulmn) => {
            this.rightMapinglist.push({ coulmn, type: null });
          });
        }
        // 设置 leftDefaultChecked rightList
        this.leftMapinglist.forEach((item, id) => {
          item.id = id;
          this.leftDefaultChecked.push(id);// 默认全选
          //
          this.rightlist.push({
            id,
            coulmn: null,
            type: null
          });
        });
      } else { // 回显左右列
        this.showCacheData();
      }
    },
    leftAciveChange(activeList) {
      this.leftDefaultChecked = activeList;
    },
    previous() {
      this.active -= 1;
      // 设置字段映射两边跟着滚动
      this.setSameTimeScroll('addEventListener');
    },
    showOk(data) { // 右边行根据左边选中显示
      if (this.leftDefaultChecked.includes(data.id)) {
        return true;
      }
      data.type = null;
      data.coulmn = null;
      return false;
    },
    selectMaping(data) { // 右 下拉选择设置对应的 type
      let item = {};
      for (let i = 0, j = this.rightMapinglist.length; i < j; i += 1) {
        if (this.rightMapinglist[i].coulmn === data.coulmn) {
          if (data.id || data.id === 0) {
            this.rightlist[data.id].type = this.rightMapinglist[i].type;
          }
          item = this.rightMapinglist[i];
          break;
        }
      }
      return item;
    },
    //
    leftChangeDbTable(mask) { // 根据数据源和表名获取左边表列表
      this.changeVal = mask;
      this.leftMapinglist = [];
      const params = { dbId: this.form.dbId, tableName: this.form.dbTable[0] };
      getDbTable(params).then((res) => {
        this.leftMapinglist = res.returnObj;
      });
    },
    leftChangeDbId(val, mask) { // 数据源改变获取表名列表
      this.changeVal = mask;
      this.form.dbTable = val;
      this.leftTableList = [];
      getTableList({ dbId: this.form.dbId }).then((res) => {
        this.leftTableList = res.returnObj;
      });
    },
    rightChangeDbTable(mask) { // 根据数据源和表名获取右边表列表
      this.changeVal = mask;
      this.rightMapinglist = [];
      const params = { dbId: this.form.jdbcWriterDbId, tableName: this.form.jdbcWriterTable };
      getDbTable(params).then((res) => {
        this.rightMapinglist = res.returnObj;
      });
    },
    rightChangeDbId(val, mask) { // 数据源改变获取表名列表
      this.changeVal = mask;
      this.form.jdbcWriterTable = val;
      this.rightTableList = [];
      getTableList({ dbId: this.form.jdbcWriterDbId }).then((res) => {
        this.rightTableList = res.returnObj;
      });
    },

    // hdfs
    // right
    hdfsLeftFocus() {
      this.focus = true;
      if (!this.form.hdfsReaderDb) return;
      this.hdfsLeftTableList = this.leftCacheList;
    },
    leftHdfsRemoteMethod(pattern) { // 远程搜索
      if (!this.form.hdfsReaderDb || pattern.length < 5) return;
      this.leftLoading = true;
      getHdfsTableList({ dbName: this.form.hdfsReaderDb, pattern }).then((res) => {
        this.hdfsLeftTableList = res.returnObj;
      }).finally(() => {
        this.leftLoading = false;
      });
    },
    hdfsLeftChangeDbTable(mask) { // hdfs 左 根据数据源和表名获取左边表列表
      this.changeVal = mask;
      this.leftMapinglist = [];
      this.leftCacheList = this.hdfsLeftTableList.concat([]);
      const params = { dbName: this.form.hdfsReaderDb, tableName: this.form.hdfsReaderTable };
      getHdfsDbTable(params).then((res) => {
        this.leftMapinglist = res.returnObj;
      });
    },
    hdfsLeftChangeDbId(val, mask) { // hdfs 左 数据源改变获取表名列表
      this.changeVal = mask;
      this.form.hdfsReaderTable = val;
      this.hdfsLeftTableList = [];
      this.leftCacheList = [];
      getHdfsTableList({ dbName: this.form.hdfsReaderDb }).then((res) => {
        this.hdfsLeftTableList = res.returnObj;
        this.leftCacheList = this.hdfsLeftTableList.concat([]);
      });
    },
    // right
    hdfsRightFocus() {
      this.focus = true;
      if (!this.form.hdfsWriterDb) return;
      this.hdfsRightTableList = this.rightCacheList;
    },
    rightHdfsRemoteMethod(pattern) { // 远程搜索
      if (!this.form.hdfsWriterDb || pattern.length < 5) return;
      this.rightLoading = true;
      getHdfsTableList({ dbName: this.form.hdfsWriterDb, pattern }).then((res) => {
        this.hdfsRightTableList = res.returnObj;
      }).finally(() => {
        this.rightLoading = false;
      });
    },
    hdfsRightChangeDbId(val, mask) { // hdfs 右 数据源改变获取表名列表
      this.changeVal = mask;
      this.form.hdfsWriterTable = val;
      this.hdfsRightTableList = [];
      this.rightCacheList = [];
      getHdfsTableList({ dbName: this.form.hdfsWriterDb }).then((res) => {
        this.hdfsRightTableList = res.returnObj;
        this.rightCacheList = this.hdfsRightTableList.concat([]);
      });
    },
    hdfsRightChangeDbTable(mask) { // hdfs 右 根据数据源和表名获取左边表列表
      this.changeVal = mask;
      this.rightMapinglist = [];
      this.rightCacheList = this.hdfsRightTableList.concat([]);
      const params = { dbName: this.form.hdfsWriterDb, tableName: this.form.hdfsWriterTable };
      getHdfsDbTable(params).then((res) => {
        this.rightMapinglist = res.returnObj;
      });
    },


    //
    addParams() {
      this.form.paramsList.push(null);
    },
    delParams(idx) {
      this.form.paramsList.splice(idx, 1);
    },
    setSameTimeScroll(mask) {
      if (this.active === 1) {
        // 设置字段映射两边跟着滚动
        this.$nextTick(() => {
          [this.left,, this.right] = document.getElementsByClassName('el-transfer-panel__list');
          if (!this.left) {
            return;
          }
          this.left[mask]('scroll', () => {
            if (this.currentTab !== 1) return;
            this.right.scrollTop = this.left.scrollTop;
          });
          this.right[mask]('scroll', () => {
            if (this.currentTab !== 2) return;
            this.left.scrollTop = this.right.scrollTop;
          });
          this.left[mask]('mouseover', () => {
            // 1 表示表示当前鼠标位于 .left元素范围内
            this.currentTab = 1;
          });
          this.right[mask]('mouseover', () => {
            // 2 表示表示当前鼠标位于 .right元素范围内
            this.currentTab = 2;
          });
        });
      }
    },
    getDataSource() { // 获取数据源
      getDataSource().then((res) => {
        this.sourceList = res.returnObj.rows;
      });
      getHdfsDataSource().then((res) => {
        this.hdfsSourceList = res.returnObj;
      });
      getHbaseTableList().then((res) => {
        this.hbaseTableList = res.returnObj;
      });
    },
    nameUnique(rule, value, callback) {
      if (!this.regExp.test(value)) {
        callback(new Error('名字必须以字母数字下划线组成'));
        return;
      }
      const { actionList, flowList } = this.$store.state.dag;
      const nameList = actionList.concat(flowList);
      for (let i = 0, j = nameList.length; i < j; i += 1) {
        if (nameList[i].name === value
        && String(this.item.actionId) !== String(nameList[i].actionId)) {
          callback(new Error('名字重复'));
          return;
        }
      }
      callback();
    },
    getConf() {
      const obj = Object.assign({}, this.form, {
        jvmArgs: this.form.paramsList.join(','),
        dbWhere: this.form.dbWhere || '1=1'
      });
      const leftMapList = [];
      const rightMapList = [];
      const leftMap = [];
      const rightMap = [];
      this.leftDefaultChecked.forEach((id) => {
        const left = this.leftMapinglist[id];
        const right = this.rightlist[id];
        leftMapList.push({
          id,
          coulmn: left.coulmn,
          type: left.type
        });
        leftMap.push(left.coulmn);
        //
        rightMapList.push({
          id,
          coulmn: right.coulmn,
          type: right.type,
        });
        rightMap.push(right.coulmn);
      });
      //
      if (this.form.reader === 'JDBC') {
        obj.dbCoulmn = leftMap.join(',');
      } else if (this.form.reader === 'HDFS') {
        obj.hdfsReaderCoulmn = '';
        leftMapList.forEach((item, idx) => {
          obj.hdfsReaderCoulmn += `${idx !== 0 ? ',' : ''}{"index":${item.id},"type":"string"}`;
        });
      } else if (this.form.reader === 'Hbase') {
        obj.hbaseCoulmn = '';
        leftMapList.forEach((item, idx) => {
          obj.hbaseCoulmn += `${idx !== 0 ? ',' : ''}{"name":"${item.coulmn}","type":"string"}`;
        });
      }
      if (this.form.writer === 'JDBC_Writer') {
        obj.jdbcWriterCoulmn = rightMap.join(',');
      } else if (this.form.writer === 'HDFS_Writer') {
        obj.hdfsWriterCoulmn = '';
        rightMapList.forEach((item, idx) => {
          obj.hdfsWriterCoulmn += `${idx !== 0 ? ',' : ''}{"name":"${item.coulmn}","type":"string"}`;
        });
      } else if (this.form.writer === 'Hbase_Writer') {
        // 需要rowkey
        let zero = true;
        obj.hbaseWriterCoulmn = '';
        obj.hbaseWriterRowkey = [];
        rightMapList.forEach((item, index) => {
          const id = this.form.reader === 'Hbase' ? index : item.id;
          if (item.coulmn.indexOf('rowkey') < 0) { // 不是rowKey
            obj.hbaseWriterCoulmn += `${zero ? '' : ','}{"index":${id},"name":"${item.coulmn}","type":"string"}`;
            zero = false;
          } else {
            const num = parseFloat(item.coulmn.replace('rowkey', ''));
            obj.hbaseWriterRowkey[num] = `{"index":${id},"type":"string"}`;
          }
        });
        //
        obj.hbaseWriterRowkey = obj.hbaseWriterRowkey.join(',{ "index":-1, "type":"string", "value":"_" }');
      }
      return obj;
    },
    confim() {
      this.$refs.form.validate((valid) => {
        if (valid) {
          const { actionLink, flowActionId } = this.$store.state.dag;
          // 获取节点的parentId列表
          const parentId = [];
          actionLink.forEach((item) => {
            if (String(item.target) === String(this.item.actionId) && item.source > 0) {
              parentId.push(item.source);
            }
          });
          //
          const params = {};
          params.isCore = this.form.isCore;
          params.parentId = parentId.length > 0 ? parentId.join(',') : flowActionId;
          params.actionId = this.item.actionId > 0 ? this.item.actionId : null;
          params.name = this.form.name;
          params.appAbbrName = `${this.item.top},${this.item.left}`;
          params.actionStageId = this.item.actionStageId;
          const conf = this.getConf();
          params.conf = JSON.stringify(conf);
          //
          this.loading = true;
          saveFlowInfo(params).then((res) => {
            //
            this.$store.commit('changeJobSetDataObj', {// 改变配置信息
              actionId: this.item.actionId,
              data: Object.assign(this.form, conf)
            });
            //
            if (!params.actionId) {
              this.$store.commit('changeActionId', [this.item.actionId, res.result]);
            }
            this.visible = false;
          }).finally(() => {
            this.loading = false;
          });
          return true;
        }
        return false;
      });
    },
  },
};
</script>
<style scoped lang="less">
  .noEvent {
    pointer-events: none;
  }
  .setSource {
    padding-top: 20px;
    .el-transfer {
      width: calc(50% - 10px);
      display: inline-block;
      /deep/ .el-select.error {
        .el-input__inner {
          border: 1px solid #f56c6c !important;
        }
      }
      /deep/ .el-transfer__buttons {
        display: none;
        & + div.el-transfer-panel {
          display: none;
        }
      }
      /deep/ .el-transfer-panel {
        width: 100%;
        .el-transfer-panel__list {
          overflow-y: auto;
          overflow-x: hidden;
        }
        .el-checkbox.el-transfer-panel__item {
          width: 100%;
          margin-bottom: 5px;
        }
      }
      &.right {
        margin-left: 20px;
        /deep/ .el-transfer-panel__header {
          pointer-events: none;
        }
        /deep/ .el-checkbox__label {
          padding-left: 0;
          span {
            display: none;
          }
        }
        /deep/ .el-checkbox__input {
          display: none;
        }
      }
    }
    .el-card {
      /deep/ .el-card__body {
        padding: 5px 0;
      }
    }
    .paramsRow {
      .row {
        margin-bottom: 5px;
      }
      i {
        cursor: pointer;
        font-size: 20px;
        margin: 5px 0 0 5px;
        vertical-align: sub;
      }
    }
  }
</style>
