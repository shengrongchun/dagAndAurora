<template>
  <el-dialog
    :title="type === 'info'?'基础信息':'调度配置'"
    top="10px"
    v-loading="dialogLoading"
    element-loading-spinner="el-icon-loading"
    element-loading-background="rgba(255, 255, 255, 0.5)"
    :close-on-click-modal="false"
    :visible.sync="visible"
    width="45%">
    <el-form
      :model="dispatchForm"
      :rules="dispatchRules"
      ref="dispatchForm"
      label-width="110px">
      <template v-if="type==='info'">
        <el-form-item
          label="业务流程名字"
          prop="name">
          <el-input
            style="width:350px"
            v-model="dispatchForm.name"/>
        </el-form-item>
        <el-form-item
          label="是否核心"
          prop="isCore">
          <el-radio-group v-model="dispatchForm.isCore">
            <el-radio :label="1">是</el-radio>
            <el-radio :label="0">否</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item
          label="描述"
          prop="description">
          <el-input
            type="textarea"
            style="width:350px"
            :autosize="{ minRows: 4 }"
            v-model="dispatchForm.description"/>
        </el-form-item>
        <el-form-item
          v-if="dispatchForm.createTime"
          label="创建时间"
          prop="createTiem">
          {{ getStampTime(dispatchForm.createTime) }}
        </el-form-item>
        <el-form-item
          v-if="dispatchForm.updateTime"
          label="更新时间"
          prop="upodateTime">
          {{ getStampTime(dispatchForm.updateTime) }}
        </el-form-item>
      </template>
      <template v-else>
        <el-form-item
          label="出错重试">
          <el-radio-group v-model="dispatchForm.runAgain">
            <el-radio :label="true">是</el-radio>
            <el-radio :label="false">否</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item
          v-if="dispatchForm.runAgain"
          label="重试次数">
          <el-select
            style="width:350px"
            filterable
            v-model="dispatchForm.autoRerunTimes">
            <el-option
              v-for="(item,idx) in 10"
              :value="item"
              :key="idx">{{ item }}</el-option>
        </el-select></el-form-item>
        <el-form-item
          v-if="dispatchForm.runAgain"
          label="重试间隔(分钟)"
          prop="delayRerunTime">
          <el-select
            style="width:350px"
            v-model="dispatchForm.delayRerunTime">
            <el-option
              v-for="(item,idx) in 59"
              :value="item"
              :key="idx">{{ item }}</el-option>
          </el-select>
        </el-form-item>
        <el-form-item
          label="调度状态">
          <el-radio-group v-model="dispatchForm.progress">
            <el-radio :label="1">开启</el-radio>
            <el-radio :label="0">暂停</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item
          label="调度周期">
          <el-select
            @change="changeTime"
            style="width:350px"
            v-model="dispatchForm.rang"
            placeholder="请选择调度周期">
            <el-option
              v-for="(cycle,idx) in cycleList"
              :key="idx"
              :label="cycle.name"
              :value="cycle.value"/>
          </el-select>
        </el-form-item>
        <el-form-item
          v-if="dispatchForm.rang !== 'hour'&& dispatchForm.rang !== 'day'"
          label="选择时间"
          prop="selectTime">
          <el-select
            style="width:350px"
            multiple
            v-model="dispatchForm.selectTime"
            placeholder="请选择时间">
            <el-option
              v-for="(item,idx) in selectTimeList"
              :key="idx"
              :label="item.name"
              :value="item.value"/>
          </el-select>
        </el-form-item>
        <el-form-item
          v-if="dispatchForm.rang !== 'hour'"
          label="具体时间"
          prop="time">
          <el-select
            style="width:150px"
            v-model="dispatchForm.time[0]">
            <el-option
              v-for="(item,idx) in 24"
              :label="idx"
              :value="idx"
              :key="idx"/>
          </el-select>
          时&nbsp;-&nbsp;
          <el-select
            style="width:150px"
            v-model="dispatchForm.time[1]">
            <el-option
              v-for="(item,idx) in 60"
              :label="idx"
              :value="idx"
              :key="idx"/>
          </el-select>
          分
        </el-form-item>
        <!--小时-->
        <template v-if="dispatchForm.rang === 'hour'">
          <el-form-item
            label="类型">
            <el-radio-group v-model="dispatchForm.hourType">
              <el-radio :label="0">指定</el-radio>
              <el-radio :label="1">区间</el-radio>
            </el-radio-group>
          </el-form-item>
          <template v-if="dispatchForm.hourType===1">
            <el-form-item
              label="开始/结束时间"
              prop="startendTime">
              <el-select
                @change="changeRangTime"
                v-model="dispatchForm.startendTime[0]">
                <el-option
                  v-for="(item,idx) in 24"
                  :label="idx"
                  :disabled="dispatchForm.startendTime[1]<=idx"
                  :value="idx"
                  :key="idx"/>
              </el-select>
              -
              <el-select
                @change="changeRangTime"
                v-model="dispatchForm.startendTime[1]">
                <el-option
                  v-for="(item,idx) in 24"
                  :label="idx"
                  :disabled="dispatchForm.startendTime[0]>=idx"
                  :value="idx"
                  :key="idx"/>
              </el-select>
            </el-form-item>
            <el-form-item
              label="间隔时间"
              prop="stepTime">
              <el-input
                style="width:320px"
                type="number"
                v-model="dispatchForm.stepTime"
                placeholder="输入间隔时间"
              />
              小时
            </el-form-item>
          </template>
          <template v-if="dispatchForm.hourType===0">
            <el-form-item
              label="指定分钟"
              prop="minutes">
              <el-select
                style="width:350px"
                multiple
                v-model="dispatchForm.minutes">
                <el-option
                  v-for="(item,idx) in 59"
                  :label="item"
                  :value="item"
                  :key="idx"/>
              </el-select>
            </el-form-item>
          </template>
        </template>
        <el-form-item
          label="crontab表达式"
          prop="expre">
          {{ frequency }}
        </el-form-item>

        <el-form-item
          label="数据偏移"
          prop="dataDateOffset">
          <el-input
            style="width:350px"
            type="number"
            v-model.number="dispatchForm.dataDateOffset"/>
        </el-form-item>
        <el-form-item
          label="是否告警">
          <el-radio-group v-model="dispatchForm.isMonitor">
            <el-radio :label="1">是</el-radio>
            <el-radio :label="0">否</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item
          label="优先级">
          <el-select
            style="width:350px"
            v-model.number="dispatchForm.priority">
            <el-option
              v-for="(item,idx) in 30"
              :value="item"
              :key="idx">{{ item }}</el-option>
          </el-select>
        </el-form-item>
        <el-form-item
          prop="deadline"
          label="deadline">
          <el-time-picker
          style="width:350px"
            value-format="HH:mm"
            format="HH:mm"
            v-model="dispatchForm.deadline"
            placeholder="请输入截止时间"/>
        </el-form-item>
      </template>
    </el-form>
    <span
      slot="footer"
      class="dialog-footer">
      <el-button @click="visible=false">取 消</el-button>
      <el-button
        type="primary"
        :disabled="dialogLoading"
        @click="confim">保 存</el-button>
    </span>
  </el-dialog>
</template>
<script>
import { saveFlowInfo } from '@/api/dag';
import options from './options';
import moment from 'moment';

export default {
  props: {
    dialogVisible: {
      type: Boolean,
      default: false
    },
    type: {
      type: String,
      default: null
    }
  },
  data() {
    return {
      dialogLoading: false,
      dispatchForm: {
        name: null, // 名称
        description: null, // 描述
        isCore: 0, // 否
        parentId: null, // 前置任务id
        actionStageId: '35', // 任务节点类型
        isMonitor: 0, // 0:不告警，1告警
        progress: 1, // 调度状态
        autoRerunTimes: 0, // 重试次数
        delayRerunTime: 1, // 重试间隔
        dataDateOffset: -1, // 数据偏移
        priority: 5, // 任务优先级
        deadline: '09:00', // 截止时间
        appId: process.env.VUE_APP_ENV === 'pro' ? 2 : 1, // 资源分组类型
        // 以下参数不会带入请求接口
        stepTime: 1, // 间隔时间
        selectTime: ['1'], // 选择时间
        runAgain: false, // 是否出错重试
        rang: 'day', // 调度周期
        time: [0, 5], // 具体时间
        startendTime: [0, 23], // 开始结束时间
        hourType: 0, // 小时指定类型
        minutes: [1], // 指定分钟
      },
    };
  },
  computed: {
    frequency() {
      const val = [];
      const {
        rang, time, selectTime, startendTime, stepTime, hourType, minutes
      } = this.dispatchForm;
      if (rang === 'day') { // 日
        val.push(time[1]);// 分
        val.push(time[0]);// 时
        val.push('*');// 日
        val.push('*');// 月
        val.push('?');
      } else if (rang === 'hour') {
        if (hourType === 0) { // 指定
          val.push(minutes.join(','));// 分
          val.push('*');// 时
        } else {
          val.push('*');// 分
          val.push(`${startendTime[0]}-${startendTime[1]}/${stepTime}`);// 时
        }
        val.push('*');// 日
        val.push('*');// 月
        val.push('?');
      } else if (rang === 'week') {
        val.push(time[1]);// 分
        val.push(time[0]);// 时
        val.push('?');// 日
        val.push('*');// 月
        val.push(selectTime.join(','));// 周
      } else if (rang === 'month') {
        val.push(time[1]);// 分
        val.push(time[0]);// 时
        val.push(selectTime.join(','));// 日
        val.push('*');// 月
        val.push('?');// 周
      }
      return val.join(' ');
    },
    selectTimeList() {
      if (this.dispatchForm.rang === 'week') {
        return options.selectWeekList;
      }// month
      return options.selectMonthList;
    },
    visible: {
      get() {
        return this.dialogVisible;
      },
      set() {
        this.$emit('close');
      },
    },
  },
  created() {
    const reg = '^[a-zA-Z0-9_]+$';
    this.regExp = new RegExp(reg);
    this.dispatchRules = Object.assign(options.dispatchRules, {
      name: [
        { required: true, message: '请输入业务流程名称', trigger: 'blur' },
        { validator: this.nameUnique, trigger: 'blur' }
      ],
      stepTime: [
        { required: true, message: '请输入间隔时间', trigger: 'blur' },
        { validator: this.validatestepTime, trigger: 'blur' },
      ],
    });
    //
    this.cycleList = options.cycleList;
    const { jobSetDataObj, flowActionId } = this.$store.state.dag;
    this.dispatchForm = Object.assign(this.dispatchForm, jobSetDataObj[flowActionId]);
    this.setDispatchForm();
  },
  methods: {
    getStampTime(time) {
      return moment(time).format('YYYY-MM-DD HH:mm:ss');
    },
    gap() {
      return this.dispatchForm.startendTime[1] - this.dispatchForm.startendTime[0];
    },
    setDispatchForm() { // 设置frequency和runAgain
      const { autoRerunTimes, frequency } = this.dispatchForm;
      this.dispatchForm.runAgain = true;
      if (autoRerunTimes === 0) {
        this.dispatchForm.autoRerunTimes = 1;
        this.dispatchForm.delayRerunTime = 1;
        this.dispatchForm.runAgain = false;
      }
      if (!frequency) { return; }
      const frequencyList = frequency.split(' ');
      if (frequencyList[3] === '*' && frequencyList[4] === '?' && frequencyList[2] !== '*') { // 月
        this.dispatchForm.rang = 'month';
        this.dispatchForm.selectTime = frequencyList[2].split(',');
        this.dispatchForm.time = [frequencyList[1], frequencyList[0]];
      } else if (frequencyList[4] !== '*' && frequencyList[4] !== '?') { // 周
        this.dispatchForm.rang = 'week';
        this.dispatchForm.selectTime = frequencyList[4].split(',');
        this.dispatchForm.time = [frequencyList[1], frequencyList[0]];
      } else if (frequencyList[0] !== '*' && frequencyList[1] !== '*' && frequencyList[2] === '*') { // 日
        this.dispatchForm.time = [frequencyList[1], frequencyList[0]];
      } else { // 小时
        this.dispatchForm.rang = 'hour';
        if (frequencyList[0] === '*') { // 区间
          this.dispatchForm.hourType = 1;
          const [startendTime, stepTime] = frequencyList[1].split('/');
          this.dispatchForm.stepTime = stepTime;
          this.dispatchForm.startendTime = startendTime.split('-');
        } else {
          this.dispatchForm.hourType = 0;
          this.dispatchForm.minutes = frequencyList[0].split(',');
        }
      }
    },
    changeRangTime() {
      if (this.dispatchForm.stepTime > this.gap()) {
        this.dispatchForm.stepTime = 1;
      }
    },
    nameUnique(rule, value, callback) {
      if (!this.regExp.test(value)) {
        callback(new Error('名字必须以字母数字下划线组成'));
        return;
      }
      const { actionList, flowList, flowActionId } = this.$store.state.dag;
      const nameList = actionList.concat(flowList);
      for (let i = 0, j = nameList.length; i < j; i += 1) {
        if (nameList[i].name === value && String(nameList[i].actionId)
        !== String(flowActionId)) {
          callback(new Error('名字重复'));
          return;
        }
      }
      callback();
    },
    validatestepTime(rule, value, callback) {
      if (this.gap() < this.dispatchForm.stepTime) {
        callback(new Error('时间间隔不能大于区间范围'));
      }
      callback();
    },
    changeTime() {
      this.dispatchForm.selectTime = ['1'];
    },
    confim() {
      this.$refs.dispatchForm.validate((valid) => {
        if (valid) {
          const { flowActionId, actionList } = this.$store.state.dag;
          const params = Object.assign({}, this.dispatchForm, { frequency: this.frequency });
          if (!this.dispatchForm.runAgain) { // 不出错重试
            params.autoRerunTimes = 0;
            params.delayRerunTime = 0;
          }
          if (this.dispatchForm.rang === 'hour') { // 小时
            params.offsetUnit = 'h';
          } else {
            params.offsetUnit = 'D';
          }
          delete params.stepTime;
          delete params.selectTime;
          delete params.runAgain;
          delete params.rang;
          delete params.time;
          delete params.startendTime;
          delete params.hourType;
          delete params.minutes;
          delete params.createTime;
          delete params.updateTime;
          delete params.confXml;
          //
          const { svgW } = this.$store.state.dag;
          if (flowActionId) { // 修改
            params.actionId = flowActionId;
            for (let i = 0, j = actionList.length; i < j; i += 1) {
              if (String(actionList[i].actionId) === String(flowActionId)) {
                params.appAbbrName = `${actionList[i].top},${actionList[i].left}`;
                break;
              }
            }
          } else { // 新建
            params.appAbbrName = `${40},${svgW}`;
          }
          //
          this.dialogLoading = true;
          saveFlowInfo(params).then((res) => {
            if (!flowActionId) { // 创建的话调一下业务流程list接口
              this.$store.dispatch('getFlowList');
              // 创建新节点
              this.$store.commit('createFlowNode', {
                actionId: res.result,
                name: this.dispatchForm.name,
                top: 40,
                left: svgW
              });
            } else { // 修改业务流程信息
              this.$store.commit('changeFlowName', this.dispatchForm.name);
            }
            //
            this.$store.commit('changeJobSetDataObj', {// 改变配置信息
              actionId: res.result,
              data: params
            });
            this.visible = false;
          }).finally(() => {
            this.dialogLoading = false;
            return true;
          });
        }
        return false;
      });
    }
  }
};
</script>
