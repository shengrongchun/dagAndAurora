<template>
  <el-dialog
    title="任务配置"
    top="10px"
    :close-on-click-modal="false"
    :visible.sync="visible"
    v-loading="disabled"
    element-loading-spinner="el-icon-loading"
    element-loading-background="rgba(255, 255, 255, 0.5)"
    width="65%">
    <el-form
      :class="{'noEvent':publish===1}"
      :model="form"
      :rules="rules"
      ref="form"
      label-width="110px"
      class="form">
      <el-form-item
        label="节点名字"
        prop="name">
        <el-input
          style="width:350px"
          v-model.trim="form.name"/>
      </el-form-item>
      <el-form-item
        label="是否核心"
        prop="isCore">
        <el-radio-group v-model="form.isCore">
          <el-radio :label="1">是</el-radio>
          <el-radio :label="0">否</el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item
        label="节点类型">
        <span>{{ typeNameObj(item.actionStageId) }}</span>
      </el-form-item>
      <!--数据计算-->
      <template v-if="item.actionStageId==='10'">
        <el-form-item
          label="计算类型">
          <span style="font-weight:bolder">Hive</span>
        </el-form-item>
        <el-form-item
          class="codeMirror"
          prop="hql"
          label="">
          <textarea ref="textarea"/>
        </el-form-item>
      </template>
      <!--自定义脚本-->
      <template v-if="item.actionStageId==='26'">
        <el-form-item
          label="脚本"
          prop="scriptsId">
          <el-select
            style="width:350px"
            v-model="form.scriptsId"
            filterable
            placeholder="请选择脚本名称">
            <el-option
              v-for="items in scriptList"
              :key="items.id"
              :label="items.scriptName"
              :value="items.id">
              <span style="float:left;margin-right:10px">{{ items.scriptName }}</span>
              <span style="float:right;color:#8492a6;font-size:13px">{{ items.scriptPath }}</span>
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item
          label="自定义参数"
          prop="params">
          <div
            class="paramsRow">
            <i
            v-if="form.paramsList.length===0"
            @click="addParams"
            class="el-icon-circle-plus-outline"/>
            <div
              v-else
              class="row"
              v-for="(value,idx) in form.paramsList"
              :key="idx">
              <el-input
                style="width:350px"
                v-model.trim="form.paramsList[idx]"
                placeholder="参数值"/>
              <i
                @click="delParams(idx)"
                class="el-icon-remove-outline"/>
              <i
                v-if="idx===form.paramsList.length-1"
                @click="addParams"
                class="el-icon-circle-plus-outline"/>
            </div>
          </div>
        </el-form-item>
      </template>
      <!--邮件推送-->
      <template v-if="item.actionStageId==='32'">
        <el-form-item
          label="邮件主题"
          prop="subject">
          <el-input
            v-model.trim="form.subject"
            style="width:350px"/>
        </el-form-item>
        <el-form-item
          label="表名"
          prop="tableName">
          <el-input
            v-model.trim="form.tableName"
            style="width:350px"/>
        </el-form-item>
        <el-form-item
          label="接收人"
          prop="to">
          <el-input
            type="email"
            placeholder="多个用;隔开"
            v-model.trim="form.to"
            style="width:350px"/>
        </el-form-item>
        <el-form-item
          label="抄送"
          prop="cc">
          <el-input
            v-model.trim="form.cc"
            placeholder="多个用;隔开"
            style="width:350px"/>
        </el-form-item>
        <el-form-item label="分区字段">
          <el-input
            v-model.trim="form.partitionKey"
            style="width:350px"/>
        </el-form-item>
        <el-form-item label="分区值">
          <el-input
            v-model.trim="form.partitionValue"
            style="width:350px"/>
        </el-form-item>
      </template>
    </el-form>
    <span
      slot="footer"
      class="dialog-footer">
      <el-button @click="visible=false">取 消</el-button>
      <el-button
        type="primary"
        :disabled="disabled"
        :class="{'noEvent':publish===1}"
        @click="confim">保 存</el-button>
    </span>
  </el-dialog>
</template>
<script>
// 引入全局实例
import CodeMirror from 'codemirror';
// 核心样式
import 'codemirror/lib/codemirror.css';
// 引入主题后还需要在 options 中指定主题才会生效
import 'codemirror/theme/yonce.css';// base16-dark
// 引入sql模式
import 'codemirror/mode/sql/sql.js';
// api
import {
  getScriptList, saveFlowInfo, getCacheDataById
} from '@/api/dag';
import options from './options';

const emailReg = /^[A-Za-zd0-9]+([-_.][A-Za-zd]+)*@([A-Za-zd]+[-.])+[A-Za-zd]{2,5}$/;
export default {
  props: {
    dialogVisible: {
      type: Boolean,
      default: false
    },
    item: {
      type: Object,
      default() {
        return {};
      }
    }
  },
  data() {
    return {
      form: {
        name: this.item.name, // 节点名称
        isCore: 0, // 否
        // 邮件推送
        subject: null, // 邮件主题
        tableName: null, // 表名
        to: null, // 接收人
        cc: null, // 抄送
        partitionKey: null, // 分区字段
        partitionValue: null, // 分区值
        // 自定义脚本
        scriptsId: null, // 脚本
        paramsList: [], // 类型参数
        // 数据计算
        hql: null, // hive sql脚本
      },
      scriptList: [], // 脚本下拉列表
      disabled: false
    };
  },
  computed: {
    publish() {
      return this.$store.state.dag.publish;
    },
    visible: {
      get() {
        return this.dialogVisible;
      },
      set() {
        this.$emit('close');
      },
    },
  },
  created() {
    const reg = '^[a-zA-Z0-9_]+$';
    this.regExp = new RegExp(reg);
    this.rules = Object.assign(options.jobRules, {
      name: [
        { required: true, message: '请输入节点名字', trigger: 'blur' },
        { validator: this.nameUnique, trigger: 'blur' },
      ],
      to: [
        { required: true, message: '请输入接收人', trigger: 'blur' },
        { validator: this.validateEmail, trigger: 'blur' }
      ],
      cc: [
        { validator: this.validateEmail, trigger: 'blur' }
      ],
    });
    // 初始化sql
    this.initCodeMirror();
    // 获取脚本下拉列表
    this.getScriptList();
    //
    if (this.item.actionId > 0) { // api获取配置信息
      const { jobSetDataObj } = this.$store.state.dag;
      const cacheForm = jobSetDataObj[this.item.actionId];
      if (cacheForm) {
        Object.assign(this.form, cacheForm);
        this.initCacheData();
      } else { // api调
        getCacheDataById(this.item).then((res) => {
          Object.assign(this.form, res.returnObj);
          this.initCacheData();
        });
      }
    }
  },
  methods: {
    initCacheData() {
      if (this.coder) {
        this.coder.setValue(this.form.hql || '');
      }
      if (this.item.actionStageId === '26' && this.form.otherArgs) {
        this.form.paramsList = this.form.otherArgs;
      }
    },
    confim() {
      this.$refs.form.validate((valid) => {
        if (valid) {
          const { actionLink, flowActionId } = this.$store.state.dag;
          // 获取节点的parentId列表
          const parentId = [];
          actionLink.forEach((item) => {
            if (String(item.target) === String(this.item.actionId) && item.source > 0) {
              parentId.push(item.source);
            }
          });
          //
          const params = {};
          params.isCore = this.form.isCore;
          params.parentId = parentId.length > 0 ? parentId.join(',') : flowActionId;
          params.actionId = this.item.actionId > 0 ? this.item.actionId : null;
          params.name = this.form.name;
          params.appAbbrName = `${this.item.top},${this.item.left}`;
          params.actionStageId = this.item.actionStageId;
          const conf = this.getConf(this.item.actionStageId);
          params.conf = JSON.stringify(conf);
          //
          this.disabled = true;
          saveFlowInfo(params).then((res) => {
            this.visible = false;
            //
            this.$store.commit('changeJobSetDataObj', {// 改变配置信息
              actionId: this.item.actionId,
              data: this.form
            });
            //
            if (!params.actionId) {
              this.$store.commit('changeActionId', [this.item.actionId, res.result]);
            }
          }).finally(() => {
            this.disabled = false;
          });
          return true;
        }
        return false;
      });
    },
    getConf(id) {
      if (id === '32') { // 邮件推送
        return {
          subject: this.form.subject, // 邮件主题
          tableName: this.form.tableName, // 表名
          to: this.form.to, // 接收人
          cc: this.form.cc, // 抄送
          partitionKey: this.form.partitionKey, // 分区字段
          partitionValue: this.form.partitionValue, // 分区值
        };
      }
      if (id === '10') { // 数据计算
        return {
          id: '',
          otherArgs: '',
          hql: this.form.hql
        };
      }
      if (id === '26') { // 自定义脚本
        return {
          scriptsId: this.form.scriptsId,
          arg: this.form.paramsList
        };
      }
      return {};
    },
    getScriptList() {
      if (this.item.actionStageId === '26') {
        getScriptList().then((res) => {
          this.scriptList = res.returnObj;
        });
      }
    },
    addParams() {
      this.form.paramsList.push(null);
    },
    delParams(idx) {
      this.form.paramsList.splice(idx, 1);
    },
    typeNameObj(id) {
      const { jobTypeMenuList } = this.$store.state.dag;
      let nameV = null;
      for (let i = 0, j = jobTypeMenuList.length; i < j; i += 1) {
        if (jobTypeMenuList[i].actionStageId === id) {
          nameV = jobTypeMenuList[i].name;
          break;
        }
      }
      return nameV;
    },
    validateEmail(rule, value, callback) {
      if (value) {
        const emailList = value.split(';');
        for (let i = 0, j = emailList.length; i < j; i += 1) {
          if (!emailReg.test(emailList[i])) {
            callback(new Error('邮件类型错误'));
            return;
          }
        }
      }
      callback();
    },
    nameUnique(rule, value, callback) {
      if (!this.regExp.test(value)) {
        callback(new Error('名字必须以字母数字下划线组成'));
        return;
      }
      const { actionList, flowList } = this.$store.state.dag;
      const nameList = actionList.concat(flowList);
      for (let i = 0, j = nameList.length; i < j; i += 1) {
        if (nameList[i].name === value && String(this.item.actionId)
        !== String(nameList[i].actionId)) {
          callback(new Error('名字重复'));
          return;
        }
      }
      callback();
    },
    initCodeMirror() {
      if (this.item.actionStageId === '10') {
        this.$nextTick(() => {
          this.coder = CodeMirror.fromTextArea(this.$refs.textarea, {
            // 缩进格式
            tabSize: 2,
            // 主题，对应主题库 JS 需要提前引入
            theme: 'yonce',
            // 显示行号
            lineNumbers: true,
            line: true,
            mode: 'text/x-sql'
          });
          // 编辑器赋值
          this.coder.setValue(this.form.hql || '');
          // 支持双向绑定
          this.coder.on('change', (coder) => {
            this.form.hql = coder.getValue();
            this.$refs.form.validate();
          });
        });
      }
    },
  },
};
</script>
<style scoped lang="less">
  .noEvent {
    pointer-events: none;
  }
  .codeMirror {
    /deep/ .el-form-item__content {
      margin-left: 42px !important;
    }
  }
  .paramsRow {
    .row {
      margin-bottom: 5px;
    }
    i {
      cursor: pointer;
      font-size: 20px;
      margin: 5px 0 0 5px;
      vertical-align: sub;
    }
  }
</style>
