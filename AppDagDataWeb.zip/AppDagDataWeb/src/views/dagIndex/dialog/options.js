const cycleList = [{
  name: '月',
  value: 'month'
}, {
  name: '周',
  value: 'week'
}, {
  name: '日',
  value: 'day'
}, {
  name: '小时',
  value: 'hour'
},
// {
//   name: '分钟',
//   value: 'minute'
// }
];
const selectWeekList = [{
  name: '星期一',
  value: '2'
}, {
  name: '星期二',
  value: '3'
}, {
  name: '星期三',
  value: '4'
}, {
  name: '星期四',
  value: '5'
}, {
  name: '星期五',
  value: '6'
}, {
  name: '星期六',
  value: '7'
}, {
  name: '星期日',
  value: '1'
}];
const typeList = [
  'INYINT',
  'SMALLINT',
  'INT',
  'BIGINT',
  'FLOAT',
  'DOUBLE',
  'STRING',
  'VARCHAR',
  'CHAR',
  'BOOLEAN',
  'DATE',
  'TIMESTAMP'];
const selectMonthList = [{
  name: '每月15号',
  value: '15'
}, {
  name: '每月20号',
  value: '20'
}, {
  name: '每月第一天',
  value: '1'
}];
const dispatchRules = {
  dataDateOffset: [
    { required: true, message: '请输入数据偏移', trigger: 'blur' },
  ],
  selectTime: [
    { required: true, message: '请选择时间', trigger: 'blur' },
  ],
  deadline: [
    { required: true, message: '请输入截止时间', trigger: 'blur' },
  ],
  description: [{ required: true, message: '请输入业务流程描述', trigger: 'blur' }]
};
const jobRules = {
  dbId: [{ required: true, message: '请选择库名', trigger: 'change' }],
  jdbcWriterDbId: [{ required: true, message: '请选择库名', trigger: 'change' }],
  subject: [{ required: true, message: '请输入邮件主题', trigger: 'blur' }],
  tableName: [{ required: true, message: '请输入表名', trigger: 'blur' }],
  scriptsId: [{ required: true, message: '请输入脚本', trigger: 'blur' }],
  hql: [{ required: true, message: '请输入SQL脚本', trigger: 'blur' }],
  dbTable: [{ required: true, message: '请选择表名', trigger: 'blur' }],
  jdbcWriterTable: [{ required: true, message: '请选择表名', trigger: 'blur' }],
  hdfsWriterPath: [{ required: true, message: '请输入hdfs路径', trigger: 'blur' }],
  hdfsWriterPartition: [{ required: true, message: '请输入分区信息', trigger: 'blur' }],
  hdfsReaderPartition: [{ required: true, message: '请输入分区信息', trigger: 'blur' }],
  hbaseTable: [{ required: true, message: '请选择表名', trigger: 'blur' }],
  hbaseCoulmn: [{ required: true, message: '请输入列名', trigger: 'blur' }],
  startRowkey: [{ required: true, message: '请输入startRowkey', trigger: 'blur' }],
  endRowkey: [{ required: true, message: '请输入endRowkey', trigger: 'blur' }],
  //
  hdfsReaderTable: [{ required: true, message: '请选择表名', trigger: 'blur' }],
  hdfsReaderDb: [{ required: true, message: '请选择库名', trigger: 'blur' }],
  hdfsWriterDb: [{ required: true, message: '请选择库名', trigger: 'blur' }],
  hdfsWriterTable: [{ required: true, message: '请选择表名', trigger: 'blur' }],
  hdfsReaderCoulmn: [{ required: true, message: '请输入hdfs列', trigger: 'blur' }],
  //
  hbaseWriterTable: [{ required: true, message: '请选择表名', trigger: 'blur' }],
  //

};
//
export default {
  cycleList,
  selectWeekList,
  selectMonthList,
  dispatchRules,
  jobRules,
  typeList
};
