<template>
  <div
    v-if="visible"
    ref="log"
    class="logClass">
    <el-tabs
      type="border-card"
      v-model="activeName">
      <el-tab-pane
        label="节点任务信息"
        name=".info">
        <div class="info">任务类型
          <span class="name">{{ getType(item) }}</span>
        </div>
        <div class="info">任务名称
          <span class="name">{{ item.name }}</span>
        </div>
      </el-tab-pane>
      <el-tab-pane
        label="运行日志"
        name=".out">
        <span
        v-html="log"/>
      </el-tab-pane>
      <el-tab-pane
        label="错误日志"
        name=".err">
        <span
        v-html="errorLog"/>
      </el-tab-pane>
    </el-tabs>
    <i
      @click="visible=false"
      class="el-icon-close"/>
    <i
      v-if="fullscreen"
      @click="fullScreen"
      class="iconfont iconclosefull"/>
    <i
      v-else
      @click="fullScreen"
      class="iconfont iconfullscreen"/>
  </div>
</template>
<script>
import {
  getLog
} from '@/api/dag';

export default {
  props: {
    dialogVisible: {
      type: Boolean,
      default: false
    },
    item: {
      type: Object,
      default() {
        return {};
      }
    },
    change: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      activeName: '.info',
      log: null,
      errorLog: null,
      fullscreen: false
    };
  },
  computed: {
    visible: {
      get() {
        return this.dialogVisible;
      },
      set() {
        this.$emit('close');
      },
    },
  },
  watch: {
    change() {
      this.getAllLog();
    }
  },
  created() {
    this.jobTypeMenuList = this.$store.state.dag.jobTypeMenuList;
  },
  methods: {
    getAllLog() {
      this.log = null;
      this.errorLog = null;
      getLog({ actionId: this.item.actionId, type: '.out' }).then((res) => {
        if (res.returnObj instanceof Array && res.returnObj.length > 0) {
          this.log = res.returnObj[0].logInfo;
        }
      });
      getLog({ actionId: this.item.actionId, type: '.err' }).then((res) => {
        if (res.returnObj instanceof Array && res.returnObj.length > 0) {
          this.errorLog = res.returnObj[0].logInfo;
        }
      });
    },
    getType(item) {
      let type = null;
      for (let i = 0, j = this.jobTypeMenuList.length; i < j; i += 1) {
        if (this.jobTypeMenuList[i].actionStageId === item.actionStageId) {
          type = this.jobTypeMenuList[i].name;
          break;
        }
      }
      return type;
    },
    fullScreen() {
      const element = this.$refs.log;
      if (this.fullscreen) { // 退出全屏
        if (document.exitFullscreen) {
          document.exitFullscreen();
        }
      } else if (element.requestFullscreen) {
        element.requestFullscreen();
      }
      this.fullscreen = !this.fullscreen;
    }
  }
};
</script>
<style scoped lang="less">
  .logClass {
    position: absolute;
    left: 0;
    bottom: 0;
    width: 100%;
    max-height: 70%;
    min-height: 200px;
    background: #3c3f4f;
    //
    .el-tabs  {
      &.el-tabs--border-card {
        background: #3c3f4f;
        border: none;
        box-shadow: none;
        /deep/ .el-tabs__header {
          border: none;
          background: #24272f;
          .el-tabs__item {
            color: #fff;
            border: none;
            border-top: 3px solid #383838;
            background: #383838;
            line-height: 30px;
            height: 30px;
            &.is-active {
              border-top: 3px solid #409EFF;
              background: #3c3f4f;
            }
          }
        }
        /deep/ .el-tabs__content {
          overflow: auto;
          max-height: 1000px;
        }
      }
    }
    .info {
      margin-bottom: 10px;
      font-size: 14px;
      color: #eee;
      .name {
        margin-left: 20px;
      }
    }
    .el-icon-close {
      cursor: pointer;
      font-size: 24px;
      position: absolute;
      right: 28px;
      top: 2px;
    }
    .iconfont {
      cursor: pointer;
      font-size: 15px;
      position: absolute;
      right: 6px;
      top: 5px;
      &.iconclosefull {
        font-size: 18px;
      }
    }
  }
</style>
