import {
  getFlowList, pushLink, delLink, delJob, changeLeftTop, getFlowDataById, getDagById,
  getFlowStatus
} from '@/api/dag';

const baseNode = {// 移动node节点信息
  actionStageId: null, // 节点类型
  name: null,
  rightIcon: null,
  show: false,
  left: 0,
  top: 0,
};
const jobTypeMenuList = [{
  actionStageId: '29',
  name: '数据交换',
  icon: 'iconigration'
}, {
  actionStageId: '10',
  name: '数据计算',
  icon: 'iconcomputed'
}, {
  actionStageId: '32',
  name: '邮件推送',
  icon: 'iconpush'
}, {
  actionStageId: '26',
  name: '自定义脚本',
  icon: 'iconscript'
}, {
  actionStageId: '35',
  name: '业务流程',
  icon: 'iconnode'
}];
let targetList = null;
function cycle(source, target, state, vm) {
  if (source === target) { // 闭环
    vm.$message({
      message: '禁止成环',
      type: 'warning'
    });
    state.closed = true;
    return;
  }
  const getTlist = targetList[target];
  if (getTlist instanceof Array) {
    for (let i = 0, j = getTlist.length; i < j; i += 1) {
      if (state.closed) {
        break;
      }
      cycle(source, getTlist[i], state, vm);
    }
  }
}
function showTips(state, vm, info) {
  state.closed = false;
  if (String(info.target) === String(state.flowActionId)) {
    vm.$message({
      message: '不能连接虚拟节点',
      type: 'warning'
    });
    state.closed = true;
    return;
  }
  const list = state.actionLink;
  targetList = {};
  for (let i = 0, j = list.length; i < j; i += 1) {
    if (!targetList[list[i].source]) { targetList[list[i].source] = []; }
    targetList[list[i].source].push(list[i].target);
  }
  const targets = targetList[info.source];
  if (targets instanceof Array && targets.includes(info.target)) {
    vm.$message({
      message: '重复连线',
      type: 'warning'
    });
    state.closed = true;
    return;
  }
  cycle(info.source, info.target, state, vm);
}
function delJobAndLink(state, job) {
  const jobList = state.actionList;
  const linkList = state.actionLink;
  for (let i = 0, j = jobList.length; i < j; i += 1) { // 删节点
    if (String(jobList[i].actionId) === String(job.actionId)) {
      jobList.splice(i, 1);
      break;
    }
  }
  state.actionLink = linkList.filter(link => String(link.source) !== String(job.actionId)
    && String(link.target) !== String(job.actionId));
}
function delLinkCommon(state, link) {
  const list = state.actionLink;
  for (let i = 0, j = list.length; i < j; i += 1) {
    if (list[i].source === link.source && list[i].target === link.target) {
      list.splice(i, 1);
      break;
    }
  }
}
function delAndAddJob(state, job) {
  for (let i = 0, j = state.actionList.length; i < j; i += 1) {
    if (String(state.actionList.actionId) === String(job.actionId)) {
      state.actionList.splice(i, 1, job);
      break;
    }
  }
}
function dagById(state) {
  getDagById({ actionId: state.flowActionId }).then((res) => {
    // 重新设置actionList
    const list = res.returnObj.actionList || [];
    state.actionList = [];
    list.forEach((item) => {
      let [top, left] = item.app_Abbr_Name.split(',');
      top = parseFloat(top);
      left = parseFloat(left);
      const {
        actionId, name, status, actionStageId
      } = item;
      state.actionList.push({
        actionId,
        name,
        status,
        actionStageId,
        top,
        left
      });
    });
  }, () => {
    if (state.timeInterval) {
      clearInterval(state.timeInterval);
      state.timeInterval = null;
    }
  });
}
function flowStatusM(state) {
  getFlowStatus({ actionId: state.flowActionId }).then((res) => {
    state.flowStatus = res.result;
    if (state.flowStatus === '4' || state.flowStatus === '5') {
      dagById(state);
      if (state.timeInterval) {
        clearInterval(state.timeInterval);
        state.timeInterval = null;
      }
    }
  }, () => {
    if (state.timeInterval) {
      clearInterval(state.timeInterval);
      state.timeInterval = null;
    }
  });
}

const dagStore = {
  state: {// 定义响应式变量
    node: baseNode,
    jobTypeMenuList,
    actionList: [// job列表
      // {
      //   actionId: null,
      //   name: null,
      //   actionStageId: 对应类型id,
      //   status:  '1'->未运行,'2'->等待中,'3'->执行中,'4'->成功，'5'->失败//对应状态
      //   left: 0,
      //   top: 0
      // }
    ], // joblist
    actionLink: [// link列表
      // {
      //   source: actionId,
      //   target: actionId,
      // }
    ],
    flowList: [], // 业务流程列表
    jobSetDataObj: {}, // 每个job的临时配置信息
    flowActionId: null,
    flowStatus: null, // 业务流程的状态 运行中：3，成功：4，失败：5
    timeInterval: null,
    publish: 0, // 0 未发布 1已发布
    svgX: 0, // 偏移量 X
    svgY: 0, // 偏移量 Y
    svgH: 0, // svg一半高度
    svgW: 0, // svg一半宽度
  },
  mutations: {// 改变state状态的唯一定义同步方法
    initNode(state) { // 初始化节点
      state.node = baseNode;
    },
    changeNode(state, node) { // 改变移动节点
      state.node = node;
    },
    setSvgHW(state, data) { // 获取svg区域的宽高 (1/2)
      [state.svgH, state.svgW] = data;
    },
    changeFlowName(state, name) { // 修改flow节点的名字
      for (let i = 0, j = state.flowList.length; i < j; i += 1) {
        if (String(state.flowList[i].actionId) === String(state.flowActionId)) {
          state.flowList[i].name = name;
          break;
        }
      }
    },
    changeSvgPos(state, data) { // 改变偏移量
      [state.svgX, state.svgY] = data;
    },
    createFlowNode(state, data) { // 新增flow节点
      const {
        actionId, name, left, top
      } = data;
      state.flowActionId = actionId;
      this.commit('pushJob', {
        actionId,
        name,
        actionStageId: '35',
        left,
        top,
        show: true
      });
    },
    pushJob(state, job) { // 新增或者修改节点
      if (job.show) { // 新增
        delete job.show;
        state.actionList.push(job);
      } else if (job.actionId > 0) { // 修改
        changeLeftTop({// 调api改变 left,top
          actionId: job.actionId,
          appAbbrName: `${job.top},${job.left}`
        }).then(() => {
          delAndAddJob(state, job);
        });
      } else { // 修改
        delAndAddJob(state, job);
      }
    },
    changeJobSetDataObj(state, { actionId, data }) { // 修改节点配置项
      const obj = state.jobSetDataObj;
      obj[actionId] = Object.assign({}, obj[actionId], data);
      state.jobSetDataObj = Object.assign({}, obj);
      // 修改job名字
      for (let i = 0, j = state.actionList.length; i < j; i += 1) {
        if (String(state.actionList[i].actionId) === String(actionId)) {
          state.actionList[i].name = data.name;
          break;
        }
      }
    },
    changeActionId(state, ids) {
      state.jobSetDataObj[ids[1]] = state.jobSetDataObj[ids[0]];
      delete state.jobSetDataObj[ids[0]];
      for (let i = 0, j = state.actionList.length; i < j; i += 1) { // 改节点actionId
        if (String(state.actionList[i].actionId) === String(ids[0])) {
          [, state.actionList[i].actionId] = ids;
          break;
        }
      }
      // 修改相关连线信息
      state.actionLink.forEach((item) => {
        if (item.source === ids[0]) {
          [, item.source] = ids;
        }
        if (item.target === ids[0]) {
          [, item.target] = ids;
        }
      });
    },
    initflowData(state, id) { // 切换业务节点
      if (state.timeInterval) {
        clearInterval(state.timeInterval);
        state.timeInterval = null;
      }
      state.publish = 0;
      state.jobSetDataObj = {};
      state.flowActionId = null;
      state.flowStatus = null;
      state.actionList = [];
      state.actionLink = [];
      if (!id) { // 没有id是新建，有是切换
        return;
      }
      const promiseA = getFlowDataById({ actionId: id });
      const promiseB = getDagById({ actionId: id });
      //
      Promise.all([promiseA, promiseB]).then((res) => {
        const flowData = res[0].returnObj;
        const listObj = res[1].returnObj;
        //
        const jobSetDataObj = {};
        jobSetDataObj[flowData.actionId] = flowData;
        state.publish = flowData.progress;
        state.flowActionId = flowData.actionId;
        state.jobSetDataObj = jobSetDataObj;
        flowStatusM(state);
        // 重新设置actionList
        listObj.actionList.forEach((item) => {
          let [top, left] = item.app_Abbr_Name.split(',');
          top = parseFloat(top);
          left = parseFloat(left);
          const {
            actionId, name, status, actionStageId
          } = item;
          state.actionList.push({
            actionId,
            name,
            status,
            actionStageId,
            top,
            left
          });
        });
        // 重新设置actionLink
        listObj.actionLink.forEach((item) => {
          state.actionLink.push({
            source: listObj.actionList[item.source].actionId,
            target: listObj.actionList[item.target].actionId,
          });
        });
        //
      });
    },
    clearTime(state) {
      clearInterval(state.timeInterval);
      state.timeInterval = null;
      state.flowStatus = null;
      dagById(state);
    },
    publishSuccess(state, val) {
      state.publish = val;
    }
  },
  actions: {// 辅助调用mutations,这里可以异步
    async getFlowList({ state }, data) {
      const res = await getFlowList(data);
      state.flowList = res.returnObj.rows;
    },
    delLink({ state }, link) { // 删除连接线
      if (link.source > 0 && link.target > 0) {
        delLink({
          parentId: state.flowActionId,
          actionId: link.target,
          preActionId: link.source
        }).then(() => {
          delLinkCommon(state, link);
        });
      } else {
        delLinkCommon(state, link);
      }
    },
    pushLinkInfo({ state }, data) { // 新增连接线
      const [vm, link] = data;
      if (state.publish === 1) {
        vm.$message({
          type: 'warning',
          message: '发布状态禁止连线！'
        });
        return;
      }
      showTips(state, vm, link);
      if (!state.closed) { // 非成环或者非重复连线
        if (link.source > 0 && link.target > 0) {
          pushLink({
            parentId: state.flowActionId,
            actionId: link.target,
            preActionId: link.source
          }).then(() => {
            state.actionLink.push(link);
          });
        } else {
          state.actionLink.push(link);
        }
      }
    },
    delJob({ state }, job) { // 删除job节点
      if (job.actionId > 0) {
        delJob({ actionIds: job.actionId }).then(() => {
          delJobAndLink(state, job);
        });
      } else {
        delJobAndLink(state, job);
      }
    },
    updateFlowStatus({ state }) { // 测试运行，更新状态
      if (state.timeInterval) {
        clearInterval(state.timeInterval);
        state.timeInterval = null;
      }
      state.timeInterval = setInterval(() => {
        flowStatusM(state);
        dagById(state);
      }, 10000);
    }
  },
};
export default dagStore;
