const config = {
  dev: {
    DAG_API: 'http://47.111.135.157:8080', //  dev 172.17.217.219
    // DAG_API: 'http://172.17.202.46:8080', //
  },
  fat: {
    DAG_API: 'http://47.111.77.129:8080',
  },
  uat: {
    DAG_API: 'http://47.111.77.129:8080',
  },
  pro: {
    DAG_API: 'http://116.62.172.92:8080',
  }
};

export default config[process.env.VUE_APP_ENV];
