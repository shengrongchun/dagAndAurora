import Ax from 'base/api/axios';
import config from '@/env.config';

const API = config.SPACE_API;

// 获取用户数据集
export function queryOnline(params) {
  return Ax.post(`${API}/api/v1/dataSet/queryOnline`, params).then(res => res.data);
}
// 根据数据集查询维度和度量
export function queryXyOnline(params) {
  return Ax.post(`${API}/api/v1/column/queryOnline`, params).then(res => res.data);
}
// 获取图表数据源
export function queryChartData(params, type) {
  return Ax.post(`${API}/api/v1/chart/queryChartData/${type}`, params).then(res => res.data);
}
// 获取仪表盘数据
export function dashboard(id) {
  return Ax.get(`${API}/api/v1/dashboard/${id}`).then(res => res.data);
}
// 保存仪表盘数据
export function saveDashboard(params) {
  return Ax.post(`${API}/api/v1/dashboard`, params).then(res => res.data);
}
// 删除仪表盘数据
export function delDashboard(id) {
  return Ax.delete(`${API}/api/v1/dashboard/${id}`).then(res => res.data);
}

// 自助取数数据集分析获取状态
export function getDataStatus(dataSetId, dataSetType) {
  return Ax.get(`${API}/api/v1/refreshJob/state/${dataSetType}/${dataSetId}`).then(res => res.data);
}
