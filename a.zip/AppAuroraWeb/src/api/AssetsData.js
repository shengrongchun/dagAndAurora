import Ax from 'base/api/axios';
import config from '@/env.config';

const API = config.DATABOX_API;


// 获取数据域 | 业务线
async function getBizAndFieldDataInfo(type) {
  let api = `${API}/pai/dataRegion/getDataRegions`;
  if (type === 'business')api = `${API}/pai/bizModule/getBizModules`;
  const response = await Ax.post(api);
  response.unshift({ name: '全部', id: null });
  return response.data;
}

// 动态获取指标/维度接口
// yapi地址 http://yapi.hellobike.cn/project/2392/interface/api/38391
async function getIndexAndDimData(params) {
  const response = await Ax.post(`${API}/pai/engine/loadDynamic`, params);
  // const response = await Ax.post(`http://yapi.hellobike.cn/mock/2392/38391`, params);
  return response.data;
}

// 获取table list
// yapi http://yapi.hellobike.cn/project/2392/interface/api/38353
async function getTableData(params) {
  const response = await Ax.post(`${API}/pai/task/list`, params);
  return response.data;
}

// 执行任务 || 停止任务
// yapi http://yapi.hellobike.cn/project/2392/interface/api/38387
async function changeTaskStatus(params) {
  const response = await Ax.post(`${API}/pai/task/changeStatus`, params);
  return response.data;
}

// 删除任务
// yapi http://yapi.hellobike.cn/project/2392/interface/api/38352
async function delTask(params) {
  const response = await Ax.post(`${API}/pai/task/remove`, params);
  return response.data;
}

// 预览任务
// yapi http://yapi.hellobike.cn/project/2392/interface/api/38335
async function previewTask(params, cancel) {
  const response = await Ax.post(`${API}/pai/task/preview`, params, cancel);
  return response.data;
}

// 获取模型字段信息
// yapi http://yapi.hellobike.cn/project/2392/interface/api/38397
async function getModelField(params) {
  const response = await Ax.post(`${API}/pai/model/fields`, params);
  // const response = await Ax.post(`http://yapi.hellobike.cn/mock/2392/38397`, params);
  return response.data;
}

// 获取数据集信息
// yapi http://yapi.hellobike.cn/project/2392/interface/api/38398
async function getDataSet(params) {
  const response = await Ax.post(`${API}/pai/dataSet/search`, params);
  return response.data;
}

// 根据数据集查询枚举值
// yapi http://yapi.hellobike.cn/project/2392/interface/api/38396
async function getDim(params) {
  const response = await Ax.post(`${API}/pai/dim/dimensions`, params);
  return response.data;
}

// 预览sql
// http://yapi.hellobike.cn/project/2392/interface/api/38239
async function getParse(params) {
  const response = await Ax.post(`${API}/pai/engine/parse`, params);
  return response.data;
}

// 提交任务
// http://yapi.hellobike.cn/project/2392/interface/api/38239
async function subTask(params) {
  const response = await Ax.post(`${API}/pai/task/submit`, params);
  return response.data;
}

// 获取详情
// http://yapi.hellobike.cn/project/2392/interface/api/38364
async function getTaskDetail(params) {
  const response = await Ax.post(`${API}/pai/task/detail`, params);
  return response.data;
}

// 获取城市列表
// http://yapi.hellobike.cn/project/2392/interface/api/39587
async function getCityList(params) {
  const response = await Ax.post(`${API}/pai/common/cityMsg`, params);
  return response.data;
}

// 获取钉钉人员
// http://yapi.hellobike.cn/project/2392/interface/api/39587
async function getManagerList(params) {
  const response = await Ax.post(`${API}/pai/common/querySystemUser`, params);
  return response.data;
}

// 获取定时任务列表
// https://yapi.hellobike.cn/project/2392/interface/api/47312
async function getTaskTableData(params) {
  const response = await Ax.post(`${API}/pai/task/schduled/list`, params);
  return response.data;
}


// 获取定时任务详情
// https://yapi.hellobike.cn/project/2392/interface/api/47314
async function getTaskDetailData(params) {
  const response = await Ax.post(`${API}/pai/task/schduled/detail`, params);
  return response.data;
}

// 操作定时任务
// https://yapi.hellobike.cn/project/2392/interface/api/47402
async function changeTimingTaskStatus(params) {
  const response = await Ax.post(`${API}/pai/task/schduled/changeStatus`, params);
  return response.data;
}

// 回选定时任务
// https://yapi.hellobike.cn/project/2392/interface/api/50194
async function getTimingTaskDetail(params) {
  const response = await Ax.post(`${API}/pai/task/schduled/detailTaskInfo`, params);
  return response.data;
}

// 定时任务手动执行
// https://yapi.hellobike.cn/project/2392/interface/api/50260
async function getManulSumbit(params) {
  const response = await Ax.post(`${API}/pai/task/schduled/manulSumbit`, params);
  return response.data;
}

// 修改任务名称
// https://yapi.hellobike.cn/project/2392/interface/api/53483
async function changeTaskName(params) {
  const response = await Ax.post(`${API}/pai/task/rename`, params);
  return response.data;
}


// 获取指标组下拉
// https://yapi.hellobike.cn/project/2392/interface/api/66609
async function getIndexGroup(params) {
  const response = await Ax.post(`${API}/pai/dataset/getDataSetConfigGroup`, params);
  return response.data;
}

// 获取公告内容
// https://yapi.hellobike.cn/project/2392/interface/api/66602
async function getNoticeData(params) {
  const response = await Ax.post(`${API}/pai/dataset/getCurrentDayDataSetList`, params);
  return response.data;
}

// 获取事实模型
// https://yapi.hellobike.cn/project/2392/interface/api/78106
async function getSelectDataModel(params) {
  const response = await Ax.post(`${API}/pai/engine/getSelectdDataModel`, params);
  return response.data;
}

// 获取自助分析数据集
// https://yapi.hellobike.cn/project/2392/interface/api/82743
async function getAnaly(params) {
  const response = await Ax.post(`${API}/pai/engine/getAuroraLocationUrl`, params);
  return response.data;
}

// 获取在线分析按钮权限
// https://yapi.hellobike.cn/project/2392/interface/api/84167
async function getAuroraAuth(params) {
  const response = await Ax.post(`${API}/pai/engine/getAuroraAuth`, params);
  return response.data;
}


export default {
  getTableData,
  changeTaskStatus,
  previewTask,
  getIndexAndDimData,
  getModelField,
  getDataSet,
  delTask,
  getDim,
  getParse,
  subTask,
  getTaskDetail,
  getCityList,
  getManagerList,
  getTaskTableData,
  getTaskDetailData,
  changeTimingTaskStatus,
  getTimingTaskDetail,
  getManulSumbit,
  getBizAndFieldDataInfo,
  changeTaskName,
  getIndexGroup,
  getNoticeData,
  getSelectDataModel,
  getAnaly,
  getAuroraAuth
};
