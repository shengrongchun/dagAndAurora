import Ax from 'base/api/axios';
import config from '@/env.config';

const API = config.SPACE_API;

// 获取用户所有项目
export function getProjectList() {
  return Ax.get(`${API}/api/v1/project/projects`).then(res => res.data);
}
// 新建项目
export function createProject(params) {
  if (params.id) {
    return Ax.put(`${API}/api/v1/project`, params).then(res => res.data);
  }
  return Ax.post(`${API}/api/v1/project`, params).then(res => res.data);
}
// 删除项目
export function delProject(params) {
  return Ax.delete(`${API}/api/v1/project?id=${params.id}`, {}).then(res => res.data);
}
// 获取项目下面的所有条目
export function getProjectAll(params) {
  return Ax.post(`${API}/api/v1/directory/all`, params).then(res => res.data);
}
// 获取项目下面的目录树
export function getTreeDirList(params) {
  return Ax.get(`${API}/api/v1/directory/treeInProject`, { params }).then(res => res.data);
}
// 新建文件夹
export function createDir(params) {
  if (params.id) {
    return Ax.put(`${API}/api/v1/directory`, params).then(res => res.data);
  }
  return Ax.post(`${API}/api/v1/directory`, params).then(res => res.data);
}
// 删除文件夹
export function delDir(params) {
  return Ax.delete(`${API}/api/v1/directory?id=${params.id}`, {}).then(res => res.data);
}
// 新建数据集
export function createDataset(params) {
  return Ax.post(`${API}/api/v1/dataSet/sql`, params).then(res => res.data);
}


/* 新建sql数据集 */

// 查询指定项目下的可选数据源
export function getDataSourceList(params) {
  return Ax.get(`${API}/api/v1/dataSource/queryProjectRelated`, { params }).then(res => res.data);
}
// 执行sql语句
export function executeSql(params) {
  return Ax.post(`${API}/api/v1/dataSource/executeSql`, params).then(res => res.data);
}
// getSqlParamsList
export function getSqlParamsList(params) {
  return Ax.post(`${API}/api/v1/dataSource/loadColumns`, params).then(res => res.data);
}
// 数据集详细信息
export function getDataSetInfo(params) {
  return Ax.get(`${API}/api/v1/dataSet/detail`, { params }).then(res => res.data);
}
// 数据集删除
export function delDataSet(params) {
  return Ax.delete(`${API}/api/v1/dataSet?id=${params.id}&type=${params.type}`, {}).then(res => res.data);
}
// 数据集基本信息
export function getDataSetBaseInfo(params) {
  return Ax.get(`${API}/api/v1/dataSet`, { params }).then(res => res.data);
}
// 修改数据集基本信息
export function editDataSetBaseInfo(params) {
  return Ax.put(`${API}/api/v1/dataSet`, params).then(res => res.data);
}

// es
// 查询指定数据源
export function getDatasources(params) {
  return Ax.get(`${API}/api/v1/dataSource/queryProjectRelated`, { params }).then(res => res.data);
}
// 保存es
export function saveData(params) {
  const type = params.dataSet.baseSql ? 'sql' : 'es';
  return Ax.post(`${API}/api/v1/dataSet/${type}`, params).then(res => res.data);
}
// 保存pai
export function savePaiData(params) {
  return Ax.post(`${API}/api/v1/dataSet/pai`, params).then(res => res.data);
}
// 复制至
export function copyData(params) {
  return Ax.post(`${API}/api/v1/dataSet/copy`, params).then(res => res.data);
}
// 获取仪表盘url
export function getUrl(params) {
  return Ax.get(`${API}/api/v1/dashboard/publishUrl/${params.dataSetId}`).then(res => res.data);
}
// 上线
export function online(params) {
  if (params.dataSetType === 'dashboard') {
    return Ax.post(`${API}/api/v1/dashboard/upLine/${params.dataSetId}`, params).then(res => res.data);
  }
  return Ax.post(`${API}/api/v1/dataSet/upLine`, params).then(res => res.data);
}
// 下线
export function offline(params) {
  if (params.dataSetType === 'dashboard') {
    return Ax.post(`${API}/api/v1/dashboard/downLine/${params.dataSetId}`, params).then(res => res.data);
  }
  return Ax.post(`${API}/api/v1/dataSet/downLine`, params).then(res => res.data);
}
// 获取配置信息
export function queryScheduleInfo(params) {
  return Ax.post(`${API}/api/v1/dataSet/queryScheduleInfo`, params).then(res => res.data);
}
// 保存配置信息
export function updateScheduleInfo(params) {
  return Ax.post(`${API}/api/v1/dataSet/updateScheduleInfo`, params).then(res => res.data);
}
// 刷新数据集
export function triggerRefresh(params) {
  return Ax.post(`${API}/api/v1/dataSet/triggerRefresh`, params).then(res => res.data);
}
// 分页请求刷新列表
export function refreshLogs(params) {
  return Ax.post(`${API}/api/v1/dataSet/refreshLogs`, params).then(res => res.data);
}
// 查看能配置的权限选项
export function queryDashBoardAuthDef(dashboardId) {
  const params = { dashboardId };
  return Ax.get(`${API}/api/v1/dashboardAuth/queryDashBoardAuthDef`, { params }).then(res => res.data);
}

// 查询已配置的权限
export function queryDashBoardAuth(dashboardId) {
  const params = { dashboardId };
  return Ax.get(`${API}/api/v1/dashboardAuth/queryDashBoardAuth`, { params }).then(res => res.data);
}

// 保存权限
export function saveDashBoardAuth(params) {
  return Ax.post(`${API}/api/v1/dashboardAuth/saveDashBoardAuth`, params).then(res => res.data);
}
