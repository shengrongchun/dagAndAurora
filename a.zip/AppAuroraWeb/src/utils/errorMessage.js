import { Message } from 'element-ui';

export default {
  show(error) {
    if (error.name === 'BusinessError') {
      // eslint-disable-next-line
      Message({
        type: 'error',
        message: process.env.NODE_ENV === 'pro'
          ? '系统出现错误，请稍后再重试' : error.message || error.message,
      });
    } else if ((error.name === 'HttpBusinessError')
      || (error.name === 'HttpSystemError')) {
      // eslint-disable-next-line
      Message({
        type: 'error',
        message: error.message || error.message,
      });
    } else if (!(error.name === 'HttpCancelError')) {
      // eslint-disable-next-line
      if (error.message) {
        Message({
          type: 'error',
          message: process.env.NODE_ENV === 'pro'
            ? '系统出现错误' : error.message || error.message,
        });
      }
      // eslint-disable-next-line
      console.error(error);
    }
  },
};
