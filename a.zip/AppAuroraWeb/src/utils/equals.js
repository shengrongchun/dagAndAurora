
/* eslint-disable */
const { isArray } = Array;
function isDate(value) {
  return toString.call(value) === '[object Date]';
}

function simpleCompare(a, b) { return a === b || (Number.isNaN(a) && Number.isNaN(b)); }

function isRegExp(value) {
  return toString.call(value) === '[object RegExp]';
}

function isWindow(obj) {
  return obj && obj.window === obj;
}

function createMap() {
  return Object.create(null);
}

function isFunction(value) { return typeof value === 'function'; }

function isDefined(value) {return typeof value !== 'undefined';}


function equals(o1, o2) {
  if (o1 === o2) return true;
  if (o1 === null || o2 === null) return false;
  if (o1 !== o1 && o2 !== o2) return true; // NaN === NaN
  const t1 = typeof o1;
  const t2 = typeof o2;
  if(t1==='undefined'||t2==='undefined') return false;
  let key;
  let keySet;
  if (t1 === t2 && t1 === 'object') {
    if (isArray(o1)) {
      if (!isArray(o2)) return false;
      if (o1.length === o2.length) {
        for (key = 0; key < o1.length; key += 1) {
          if (!equals(o1[key], o2[key])) return false;
        }
        return true;
      }
    } else if (isDate(o1)) {
      if (!isDate(o2)) return false;
      return simpleCompare(o1.getTime(), o2.getTime());
    } else if (isRegExp(o1)) {
      if (!isRegExp(o2)) return false;
      return o1.toString() === o2.toString();
    } else {
      if ( isWindow(o1) || isWindow(o2)
        || isArray(o2) || isDate(o2) || isRegExp(o2)) return false;
      keySet = createMap();
      for (key in o1) {
        if (isFunction(o1[key])) continue;
        if (!equals(o1[key], o2[key])) return false;
        keySet[key] = true;
      }
      for (key in o2) {
        if (!(key in keySet)
            && isDefined(o2[key])
            && !isFunction(o2[key])) return false;
      }
      return true;
    }
  }
  return false;
}

export default equals;
