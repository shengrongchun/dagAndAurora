<template>
  <div>
    <el-select
      v-model="diffStyle"
      placeholder="请选择">
      <el-option
        v-for="item in diffStyleList"
        :key="item.id"
        :label="item.text"
        :value="item.id"/>
    </el-select>
    <bi-code-diff
      :old-string="oldStr"
      :new-string="newStr"/>
    <div id="diff-editor" />
  </div>
</template>

<script>
import * as monaco from 'monaco-editor';

export default {
  data() {
    return {
      editor: null,
      diffStyleList: [{ id: 'line-by-line', text: '逐行比较' }, { id: 'side-by-side', text: '按页比较' }],
      diffStyle: 'side-by-side',
      oldStr: `aaa`,
      newStr: `bbb`,
    };
  },
  mounted() {
    const originalModel = monaco.editor.createModel('SELECT * FROM table', 'text/plain');
    const modifiedModel = monaco.editor.createModel('SELECT  table', 'text/plain');

    const diffEditor = monaco.editor.createDiffEditor(document.getElementById('diff-editor'));
    diffEditor.setModel({
      original: originalModel,
      modified: modifiedModel
    });
  },
};
</script>

<style lang="less">
#diff-editor {
  height: 600px;
}
</style>
