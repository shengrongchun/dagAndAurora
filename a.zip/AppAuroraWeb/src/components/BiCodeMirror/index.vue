<template>
  <div class="costom-sql">
    <div class="operate-bar">
      <div class="operate-item">
        <el-tooltip
          content="测试运行"
          placement="bottom-start"
          effect="dark">
          <i class="iconfont icon-yunhang"/>
        </el-tooltip>
      </div>
      <div class="operate-item">
        <el-tooltip
          content="结束"
          placement="bottom-start"
          effect="dark">
          <i class="iconfont icon-jieshu"/>
        </el-tooltip>
      </div>

      <div class="operate-item">
        <el-tooltip
          content="保存"
          placement="bottom-start"
          effect="dark">
          <i class="iconfont icon-baocun"/>
        </el-tooltip>
      </div>
      <div class="operate-item">
        <el-tooltip
          content="格式化"
          placement="bottom-start"
          effect="dark">
          <i
            class="iconfont icon-format_icon"
            @click="formatCode"/>
        </el-tooltip>
      </div>
      <div class="operate-item">
        <el-tooltip
          content="主题切换"
          placement="bottom-start"
          effect="dark">
          <i class="iconfont icon-zhutifenxi" />
        </el-tooltip>
      </div>

    </div>
    <codemirror
      ref="myCm"
      v-model="code"
      :options="cmOptions"/>
    <div class="result">
      <el-tabs>
        <el-tab-pane>
          <span slot="label"><i class="el-icon-date"/>运行结果</span>
          <div class="runing">
            <i class="el-icon-loading" />
            <span>快马加鞭处理中...</span>
          </div>
          <div class="runed">
            <el-table
              :data="tableData"
              style="width: 100%">
              <el-table-column
                prop="date"
                label="日期"
                width="180"/>
              <el-table-column
                prop="name"
                label="姓名"
                width="180"/>
              <el-table-column
                prop="address"
                label="地址"/>
            </el-table>
          </div>
        </el-tab-pane>
      </el-tabs>
    </div>
  </div>
</template>
<script>
import { codemirror } from 'vue-codemirror';
import 'codemirror/mode/sql/sql.js';
import 'codemirror/lib/codemirror.css';
import 'codemirror/theme/yonce.css';
import 'codemirror/theme/eclipse.css';
import 'codemirror/addon/hint/show-hint.js';
import 'codemirror/addon/hint/sql-hint.js';
import 'codemirror/addon/hint/show-hint.css';
import 'codemirror/addon/scroll/simplescrollbars.css';
import 'codemirror/addon/scroll/simplescrollbars';
import sqlFormatter from 'sql-formatter';

import options from './options';

export default {
  components: {
    codemirror,
  },
  data() {
    return {
      code: 'SELECT * FROM table',
      cmOptions: {
        tabSize: 4,
        mode: 'text/x-sql',
        theme: options.theme[0],
        lineNumbers: true,
        line: true,
        height: 500,
        autofocus: true,
        hintOptions: {
          tables: {
            mytable1: ['name', 'score', 'birthDate'],
            mytable2: ['name', 'population', 'size']
          }
        }, // 动态设置自动提示
        scrollbarStyle: 'simple', // “simple”,"overlay"选择内侧与外侧的滚动
        lineWrapping: true, // 代码折叠
      },
      themeList: options.theme,
      theme: 0,
      tableData: [{
        date: '2016-05-02',
        name: '王小虎',
        address: '上海市普陀区金沙江路 1518 弄'
      }, {
        date: '2016-05-04',
        name: '王小虎',
        address: '上海市普陀区金沙江路 1517 弄'
      }, {
        date: '2016-05-01',
        name: '王小虎',
        address: '上海市普陀区金沙江路 1519 弄'
      }, {
        date: '2016-05-03',
        name: '王小虎',
        address: '上海市普陀区金沙江路 1516 弄'
      }]
    };
  },
  computed: {
    codemirror() {
      return this.$refs.myCm.codemirror;
    }
  },
  watch: {
    theme(val) {
      this.cmOptions.theme = this.themeList[val];
    },
  },
  mounted() {
    this.codemirror.on('change', (editor, change) => {
      // 任意键触发autocomplete
      if (change.origin === '+input') {
        // const { text } = change;
        // if (!ignoreToken(text)) {
        setTimeout(() => { this.codemirror.execCommand('autocomplete'); }, 20);
        // }
      }
    });
  },
  methods: {
    // onCmReady(cm) {
    // },
    // onCmFocus(cm) {
    // },
    onCmCodeChange(newCode) {
      this.code = newCode;
    },
    // 格式化
    formatCode() {
      const sqlContent = this.codemirror.getValue();
      this.codemirror.setValue(sqlFormatter.format(sqlContent));
    },
    // 代码比较
    onCmScroll() {
    }
  }
};
</script>

<style lang="less" scoped>
.operate-bar {
  display: flex;
  padding: 10px 14px;
  background: rgb(243,243,243);
  .operate-item {
    margin-right: 16px;
    display: flex;
    flex-direction: column;
    align-items: center;
    color: #333;
    cursor: pointer;
    i {
      font-size: 18px;
    }
  }
}
.result {
  border-top: 1px solid rgb(211,211,211);
  /deep/.el-tabs__nav-wrap::after {
    position: inherit;
  }
  /deep/.el-tabs__item {
    color: #999;
    font-size: 14px;
    font-weight: 400;
    &.is-active {
      color: #000;

    }
    i {
      margin-right: 2px;
    }
  }
  /deep/.el-tabs__active-bar  {
    height: 1px;
    background-color: #333;
  }

  .runing {
    font-size: 14px;
    margin-left: 4px;
    color: #666;
    span {
      margin-left: 4px;
    }
  }
}
</style>
