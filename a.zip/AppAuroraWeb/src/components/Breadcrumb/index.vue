<template>
  <div class="bread-contaner">
    <div class="flex">
      <el-breadcrumb :separator="separator">
        <el-breadcrumb-item
          v-for="(item,idx) in breadList"
          :key="idx">
          <span @click="breadClick(idx)">{{ item.name }}</span>
        </el-breadcrumb-item>
      </el-breadcrumb>
      <div class="left">
        <slot name="left"/>
      </div>
    </div>
    <div class="center">
      <slot name="center"/>
    </div>
    <div class="right">
      <slot />
    </div>
  </div>
</template>
<script>

export default {
  props: {
    separator: {
      type: String,
      default: '/'
    },
    breadList: {
      type: Array,
      default() {
        return [{
          name: 'demo',
        }];
      }
    }
  },
  methods: {
    breadClick(idx) {
      if (idx === this.breadList.length - 1) { // 最后一个不跳转
        return;
      }
      this.$emit('breadClick', this.breadList.slice(0, idx + 1));
    }
  }
};
</script>
<style scoped lang="less">
.bread-contaner {
  padding: 8px 0;
  display: flex;
  justify-content: space-between;
  align-items: center;
  border-bottom: 1px solid #eee;
  .flex {
    display: inline-flex;
    align-items: center;
    .el-breadcrumb {
      font-size: 15px;
      /deep/ .el-breadcrumb__item {
        .el-breadcrumb__inner {
          font-weight: bolder;
          cursor: pointer;
          &:hover {
            color: #409EFF;
          }
        }
      }
    }
    .left {
      margin: 2px 10px 0;
    }
  }
  .right {
    display: flex;
  }
}
</style>
