const tableList = [
  { label: '字段名 ', prop: 'name' },
  { label: '显示名称', prop: 'label' },
  { label: '字段类型', prop: 'dataType' },
  { label: '字段种类', prop: 'type' },
];

export default {
  tableList,
};
