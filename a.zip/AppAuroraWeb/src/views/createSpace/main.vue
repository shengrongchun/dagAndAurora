<template>
  <div class="main">
    <div
      :class="{'close':isCollapse}"
      class="left-menu">
      <div class="coll-icon">
        <i
          :class="'el-icon-s-'+(isCollapse?'unfold':'fold')"
          @click="isCollapse=!isCollapse"/>
      </div>
      <el-menu
        v-loading="loading"
        :collapse="isCollapse"
        :default-active="activeKey"
        background-color="#091425"
        text-color="rgb(255, 255, 255)"
        active-text-color="rgb(56, 204, 255)"
      >
        <el-submenu index="1">
          <template slot="title">
            <i
              class="el-icon-plus"
              @click.stop="dialogVisible=true;dialogObj={}"/>
            <span>项目列表</span>
          </template>
          <el-menu-item
            v-for="(item,idx) in projectList"
            :key="idx"
            :index="item.id+''"
            @click="routePush({
              projectId: item.id,
              parentId: -1,
              breadList: JSON.stringify([{name:item.name,id:item.id}])})">
            <span class="title">{{ item.name }}</span>
            <i
              class="el-icon-edit"
              @click.stop="dialogVisible=true;dialogObj=item"/>
            <i
              class="el-icon-delete"
              @click.stop="clickDel(item)"/>
          </el-menu-item>
        </el-submenu>
      </el-menu>
    </div>
    <div
      :class="{'close':isCollapse}"
      class="right-main">
      <router-view :key="key"/>
    </div>
    <Dialog
      v-if="dialogVisible"
      :obj="dialogObj"
      :visible="dialogVisible"
      @close="dialogVisible=false"
      @success="success"/>
  </div>
</template>
<script>
import { getProjectList, delProject } from 'src/api/space.js';
import Dialog from './components/dialogCreateProject';

export default {
  components: {
    Dialog
  },
  props: {
    list: {
      type: Array,
      default() {
        return [];
      }
    }
  },
  data() {
    return {
      isCollapse: false,
      activeKey: `${this.list[0].id}`,
      loading: false,
      dialogVisible: false,
      projectList: this.list,
      dialogObj: {}
    };
  },
  computed: {
    key() {
      return this.$route + new Date().getTime();
    }
  },
  watch: {
    $route() {
      this.activeKey = `${this.$route.params.projectId}`;
    }
  },
  created() {
    if (this.$route.params && this.$route.params.panel) {
      return;
    }
    this.initRoute();
  },
  methods: {
    initRoute() {
      const [{ id, name }] = this.projectList;
      let obj = {
        projectId: id,
        parentId: -1,
        breadList: JSON.stringify([{ name, id }])
      };
      if (this.$route.params.breadList) { // 刷新
        obj = this.$route.params;
        this.activeKey = `${this.$route.params.projectId}`;
      }
      this.routePush(obj);
    },
    routePush(params) {
      if (`${params.parentId}` === `${params.projectId}`) {
        params.parentId = -1;
      }
      this.$router.push({
        name: 'createSpaceIndex',
        params
      });
    },
    async success(obj) {
      if (obj.name && obj.id) { // 编辑
        for (let i = 0, j = this.projectList.length; i < j; i += 1) {
          if (this.projectList[i].id === obj.id) {
            this.projectList[i].name = obj.name;
            this.projectList[i].bizType = obj.bizType;
            this.projectList[i].description = obj.description;
            this.routePush({
              projectId: obj.id,
              parentId: -1,
              breadList: JSON.stringify([{ name: obj.name, id: obj.id }])
            });
            break;
          }
        }
        return;
      }
      // 新建
      this.loading = true;
      this.dialogVisible = false;
      const res = await getProjectList();
      this.loading = false;
      if (res && res instanceof Array && res.length > 0) {
        this.projectList = res;
      }
    },
    clickDel(obj) {
      this.$confirm(`确实删除 ${obj.name}?`, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        delProject(obj).then(() => {
          this.projectList = this.projectList.filter(item => item.id !== obj.id);
          if (this.activeKey === `${obj.id}`) {
            const [{ id, name }] = this.projectList;
            this.routePush({
              projectId: id,
              parentId: -1,
              breadList: JSON.stringify([{ name, id }])
            });//
          }
        });
      });
    }
  }
};
</script>
<style scoped lang="less">
.main {
  .left-menu {
    transition: 0.5s all;
    position: relative;
    user-select: none;
    float: left;
    height: calc(100vh - 60px);
    background: #091425;
    width: 210px;
    &.close {
      width: 64px;
      .coll-icon {
        top: 21px;
        left: 45px;
      }
    }
    .coll-icon {
      position: absolute;
      color: #fff;
      z-index:1;
      top: 20px;
      left: 185px;
      cursor: pointer;
    }
    .el-menu {
      border-color: #091425;
      .el-menu-item {
        position: relative;
        .title {
          display: inline-block;
          width: 100px;
          text-overflow: ellipsis;
          overflow: hidden;
        }
        i {
          display: none;
          position: absolute;
          top: 18px;
          right: 5px;
          &.el-icon-edit {
            right: 35px;
          }
          &:hover {
            color: rgb(56, 204, 255);
          }
        }
      }
      .el-menu-item:hover {
        background: #000 !important;
        i {
          display: inline-block;
        }
      }
      /deep/ .el-submenu {
        .el-submenu__title {
          .el-submenu__icon-arrow {
            display: none;
          }
          > span {
            margin-left: 3px;
            font-weight: bolder;
          }
          > i {
            color: #fff;
            font-weight: bolder;
            font-size: 16px;
          }
          &:hover {
            background: #000 !important;
          }
        }
      }
    }
  }
  .right-main {
    transition: 0.5s all;
    margin-left: 210px;
    &.close {
      margin-left: 64px;
    }
    height: calc(100vh - 60px);
    background: #eee;
    padding: 10px;
  }
}
</style>
