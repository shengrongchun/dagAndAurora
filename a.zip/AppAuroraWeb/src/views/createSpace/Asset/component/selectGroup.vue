<template>
  <div style="display:inline-flex;align-items: flex-start;">
    <!-- 模型字段 -->
    <div class="attr-name">
      <el-select
        v-model="attrCnName"
        placeholder="请选择"
        filterable
        @change="changeSelect(item)">
        <el-option
          v-for="(items,ind) in selectOptions"
          :key="ind+'attr'"
          :label="items.attrCnName"
          :value="items.attrCnName">
          <template v-if="items.hoverName">
            <el-tooltip
              class="item"
              effect="dark"
              :content="items.attrCnName"
              placement="right-end">
              <span>{{ items.hoverName }}</span>
            </el-tooltip>
          </template>
          <template v-if="!items.hoverName">
            <span>{{ items.attrCnName }}</span>
          </template>
        </el-option>
      </el-select>
      <span
        class="validate-text"
        v-if="!attrNameValidate"
      >请选择字段</span>
    </div>
    <!-- 关系字段, 日期类型不需要关系字段 -->
    <el-select
      v-if="dataType != 'date'"
      v-model="compareSymbol"
      class="select-symbol"
      placeholder="请选择"
      @change="changeCompare">
      <el-option
        v-for="(items,idx) in filterOptions"
        :key="idx+'compare'"
        :disabled="items.disabled"
        :label="items.name"
        :value="items.value"/>
    </el-select>
    <!-- 表达式右侧字段   string类型input   枚举类型 select -->
    <div
      v-if="!needUserInput"
      class="attr-name">
      <template v-if="dataType != 'date'">
        <!--非日期类型 -->
        <el-select
          v-if="selectType"
          v-model="rightValueNew"
          :collapse-tags="isTag"
          multiple
          filterable
          style="min-width:360px"
          @change="changeEnum(item)"
          @focus="focusEnum">
          <el-option
            v-for="(items,ind) in options"
            :key="ind+'city'"
            :label="items.secondPair"
            :value="items.firstPair"/>
        </el-select>
        <el-input
          v-if="!selectType"
          v-model="rightValue"
          @change="changeInput"
          @clear="changeInput"
          clearable
          style="min-width:360px"
          :placeholder="placeholder"/>
      </template>
      <template v-if="dataType == 'date'">
        <!-- 日期类型 -->
        <!-- date 类型input yyyy-MM-dd HH:mm:ss -->
        <el-date-picker
          v-if="item.timeType == 0"
          v-model="rightValue"
          type="datetimerange"
          :clearable="false"
          range-separator="至"
          start-placeholder="开始日期"
          :picker-options="pickerOptionsHour"
          end-placeholder="结束日期"
          value-format="yyyy-MM-dd HH:mm:ss"
          :default-time="['00:00:00', '23:59:59']"
          @change="changeInput"/>
        <!-- date 类型input yyyy-MM-dd -->
        <el-date-picker
          v-if="item.timeType == 1"
          v-model="rightValue"
          type="daterange"
          :clearable="false"
          range-separator="至"
          value-format="yyyy-MM-dd"
          start-placeholder="开始日期"
          end-placeholder="结束日期"
          :picker-options="pickerOptions"
          @change="changeInput"/>
      </template>
      <span
        class="validate-text"
        v-if="!isValidate">输入内容不规范，请重新输入</span>
      <span
        class="validate-text"
        v-if="!rightValueValidate">{{ validateText }}</span>
    </div>
  </div>
</template>
<script>
import request from '@/api/AssetsData.js';
import options from '../options';

export default {
  props: {
    item: {
      type: Object,
      default: () => {}
    },
    index: {
      type: Number,
      default: null
    },
    // 表达式左侧的下拉框的所有值
    selectData: {
      type: Array,
      default: () => []
    },
    dictionaryFieldType: { // 字典字段类型
      type: Number,
      default: null
    },
    dataSetId: {
      type: [Number, String],
      default: null
    }
  },
  data() {
    return {
      request,
      filterOptions: options.filterOptions,
      pickerOptions: options.pickerOptions, // 日期快捷选项天级
      pickerOptionsHour: options.pickerOptionsHour, // 日期快捷选项小时级
      selectOptions: [], // 表达式左侧的下拉框的数值
      selectType: false,
      options: [], // 下拉类型数据，表达式右侧的select options
      placeholder: '多选请用英文逗号隔开',
      validateText: '请输入内容', // 表达式右侧变量，校验提示文本
      rightValue: '',
      rightValueNew: [],
      attrCnName: '',
      compareSymbol: '5',
      isTag: false,
      isValidate: true,
      attrNameValidate: true,
      rightValueValidate: true,
      isDetail: false
    };
  },
  computed: {
    // 是否需要用户输入的标志 false表示需要用户输入，true表示不需要用户输入
    needUserInput() {
      const noNeedUserInputCompareSymbols = ['9', '10'];
      return noNeedUserInputCompareSymbols.indexOf(this.compareSymbol) > -1;
    },
    // 变量的数据类型，目前只用来区分date类型和非date类型
    dataType() {
      // timeType 字段枚举信息---和资产一致
      if (this.item.timeType === 0 || this.item.timeType === 1) {
        return 'date';
      }
      return -1;
    }
  },
  watch: {
    needUserInput() {
      if (this.needUserInput) {
        this.rightValue = '';
        this.rightValueNew = [];
        this.item.rightValueValidate = true;
        this.rightValueValidate = true;
      }
    },
    selectData(newVal) {
      this.selectOptions = newVal;
      this.isDetail = true;
      let attrList = [];
      if (!(this.selectOptions && this.selectOptions.length)) {
        this.attrCnName = '';
        this.item.attrCnName = '';
        this.item.attrNameValidate = false;
      } else {
        attrList = this.selectOptions.filter(item => item.attrCnName === this.item.attrCnName);
      }
      if (!attrList.length) {
        this.attrCnName = '';
        this.item.attrCnName = '';
        this.item.attrNameValidate = false;
      }
    },
    dictionaryFieldType(newVal) {
      const { phyFieldEnName } = this.item;
      this.selectType = newVal === 3 || (phyFieldEnName && (phyFieldEnName.indexOf('city_guid') > -1 || phyFieldEnName.indexOf('city_name') > -1 || phyFieldEnName.indexOf('city_area_name') > -1 || phyFieldEnName.indexOf('city_area_guid') > -1));
    },
    rightValue: {
      handler() {
        if (this.rightValue && this.rightValue.indexOf('[') > 0) {
          this.rightValue = JSON.parse(this.rightValue);
        }
      },
      immediate: true
    },
    item: {
      handler(newVal) {
        const { phyFieldEnName } = newVal;
        if (!phyFieldEnName) return;
        if (phyFieldEnName.indexOf('city_guid') > -1 || phyFieldEnName.indexOf('city_name') > -1 || phyFieldEnName.indexOf('city_area_name') > -1 || phyFieldEnName.indexOf('city_area_guid') > -1) {
          this.selectType = true;
          this.isTag = phyFieldEnName.indexOf('city_guid') > -1 || phyFieldEnName.indexOf('city_area_guid') > -1;
        }
        if (this.selectType) {
          this.options = newVal.rightOptions;
          this.rightValueNew = newVal.rightValueNew;
        } else {
          this.rightValue = newVal.rightValue;
        }
        this.attrCnName = newVal.attrCnName;
        this.handleFilterOptions(newVal.fieldType);
      },
      deep: true
    },
  },
  created() {
    if (!this.item.attrCnName) { // 非编辑状态
      this.$set(this.item, 'timeType', -1);
    }
    this.selectOptions = this.selectData;
    this.isDetail = Boolean(this.selectData.length);
  },
  mounted() {
    this.selectType = this.dictionaryFieldType === 3;
    if (Object.keys(this.item).length > 2) {
      ['attrNameValidate', 'rightValueValidate'].forEach((value) => {
        this[value] = true;
        this.item[value] = true;
      });
      const {
        rightOptions, rightValue, attrCnName,
        phyFieldEnName, compareSymbol, fieldType
      } = this.item;
      if (
        // eslint-disable-next-line max-len
        // eslint-disable-next-line no-mixed-operators
        phyFieldEnName && (phyFieldEnName.indexOf('city_guid') > -1
      // eslint-disable-next-line no-mixed-operators
      || phyFieldEnName.indexOf('city_name') > -1
      || phyFieldEnName.indexOf('city_area_name') > -1
      || phyFieldEnName.indexOf('city_area_guid') > -1)) {
        this.selectType = true;
        this.isTag = phyFieldEnName.indexOf('city_guid') > -1 || phyFieldEnName.indexOf('city_area_guid') > -1;
      }
      // 处理date类型数据回显问题，（后端之前约定，传值的时候，传string。所以在回显的时候需要反序列化s）
      if (rightValue && rightValue.indexOf('[') > -1) {
        this.rightValue = JSON.parse(rightValue);
      } else {
        this.rightValue = rightValue;
      }
      this.attrCnName = attrCnName;
      this.compareSymbol = compareSymbol || '5';
      // 疑问点
      // this.selectOptions = selectOptions;
      if (this.selectType && rightOptions) {
        this.rightValueNew = this.item.rightValueNew;
        this.options = rightOptions;
      }
      this.handleFilterOptions(fieldType);
    }
  },
  methods: {
    // 校验筛选条件项
    validateItem() {
      if (!this.attrCnName) this.attrNameValidate = false;
      // 下拉框情况下，表达式右侧的值都是必传的。
      if (this.selectType && !this.rightValueNew) {
        this.item.rightValueValidate = false;
        this.rightValueValidate = false;
      }
      // 非下拉框
      if (!this.selectType) {
        // 如果字段类型是string 或者 （ 右侧的值存在并且是0 并且 字段类型不等于string）。此时表达式右侧的值都是非必传的。
        const rightValidate = this.item.fieldType === 'string'
          || ((this.rightValue || this.rightValue === 0) && this.item.fieldType !== 'string');
        this.item.rightValueValidate = rightValidate;
        this.rightValueValidate = rightValidate;
      }
    },
    // 筛选条件变量数值改变，表达式左侧数据
    changeSelect(value) { // 选择框第一个1
      // if (this.item.timeType === 0 || this.item.timeType === 1) {
      // } else {
      //   this.$set(this.item, 'timeType', -1);
      // }
      this.item.attrNameValidate = true;
      this.attrNameValidate = true;
      // 把表达式左侧选中的值，赋值item
      value.attrCnName = this.attrCnName;

      const selectData = this.selectOptions.filter(item => item.attrCnName === value.attrCnName);
      const attrType = selectData[0]; // 根据表达式左侧选中的attrCnName 筛选出表达式左侧当前选中的item
      this.$set(this.item, 'timeType', attrType.timeType);

      // if (attrType.timeType === 0 || attrType.timeType === 1) {
      //   this.$set(this.item, 'timeType', attrType.timeType);
      // } else {
      //   this.$set(this.item, 'timeType', -1);
      // }
      const { dictionaryFieldType, fieldType, phyFieldEnName } = attrType;
      this.selectType = dictionaryFieldType === 3; // 枚举维度为下拉框
      if (this.dataType !== 'date') {
        this.compareSymbol = '5';
      } else { // dataType类型为date的时候，新增比较符号类型，between BETWEEN("11","");
        this.compareSymbol = '11';
      }
      value.compareSymbol = this.compareSymbol;
      // 字段类型：1指标，2普通维度，3枚举维度，4属性   字段值的类型： 字段属性bigint/double/int/string
      // 如果是枚举维度selectType select
      // 如果是普通维度，phyFieldEnName = city_name || city_guid selectType select
      // 如果compareSymbol = in||not in  selectType select
      // rightValueType值 0=string 1=bigint/double/int 2=array[string] 3=array[bigint/double/int]

      // 根据字段类型处理compareSymbols string类型可选like
      this.handleFilterOptions(fieldType);
      if (dictionaryFieldType === 1 && fieldType !== 'string') {
        this.placeholder = '';
        this.compareSymbol = '0';
        value.compareSymbol = this.compareSymbol;
      }
      // 枚举维度 动态获取枚举options
      if (dictionaryFieldType === 3) {
        this.request.getDim({ id: selectData[0].dictionaryFieldId }).then((res) => {
          this.options = res || [];
        });
        // 2=array[string] 3=array[bigint/double/int]
        value.rightValueType = fieldType === 'string' ? 2 : 3;
      } else if ((dictionaryFieldType === 2 || dictionaryFieldType === 4) // 普通维度或者是属性
        && (phyFieldEnName.indexOf('city_guid') > -1 || phyFieldEnName.indexOf('city_name') > -1 || phyFieldEnName.indexOf('city_area_name') > -1 || phyFieldEnName.indexOf('city_area_guid') > -1)) {
        this.isTag = phyFieldEnName.indexOf('city_guid') > -1 || phyFieldEnName.indexOf('city_area_guid') > -1;
        this.selectType = true;
        this.options = [];
        // 动态请求options的内容
        // eslint-disable-next-line max-len
        this.request.getCityList({ data: { type: this.isTag ? 1 : 2, dataSetId: this.dataSetId } }).then((res) => {
          // eslint-disable-next-line max-len
          if (res && res.length) this.options = res.map(item => ({ firstPair: item, secondPair: item }));
        });
        value.rightValueType = fieldType === 'string' ? 2 : 3;
      } else if (value.compareSymbol && (value.compareSymbol === '5' || value.compareSymbol === '6')) { // 比较符号是包含，或者不包含
        value.rightValueType = fieldType === 'string' ? 2 : 3;
      } else {
        value.rightValueType = fieldType === 'string' ? 0 : 1;
      }
      value.selectOptions = this.selectOptions;
      if (!this.selectType) { // 非下拉
        this.rightValue = '';
        this.item.rightOptions = undefined;
        this.item.rightValue = this.rightValue;
        // 字符串类型可以为空，或者 （右侧有数值且为0，）校验通过
        const rightValidate = fieldType === 'string'
        || ((value.rightValue || value.rightValue === 0) && fieldType !== 'string');
        this.item.rightValueValidate = rightValidate;
        this.rightValueValidate = rightValidate;
        if (this.needUserInput) {
          this.rightValue = '';
          this.rightValueNew = [];
          this.item.rightValue = this.rightValueNew.join(',');
          this.item.rightValueNew = this.rightValueNew;
          this.item.rightValueValidate = true;
          this.rightValueValidate = true;
        }
      } else { // 下拉 右侧必须有值
        // eslint-disable-next-line no-lonely-if
        if (this.needUserInput) { // 用户不需要输入
          this.rightValue = '';
          this.rightValueNew = [];
          this.item.rightValue = this.rightValueNew.join(',');
          this.item.rightValueNew = this.rightValueNew;
          this.item.rightValueValidate = true;
          this.rightValueValidate = true;
        } else {
          this.rightValueNew = [];
          this.item.rightValue = this.rightValueNew.join(',');
          this.item.rightValueNew = this.rightValueNew;
          this.item.rightValueValidate = this.item.rightValue.length;
          this.rightValueValidate = this.item.rightValue.length;
        }
      }
      this.validateText = this.selectType ? '请选择内容' : '请输入内容';
      Object.assign(value, { ...selectData[0] });
    },
    changeCompare(val) {
      this.item.compareSymbol = val;
      if (this.item.fieldType && this.item.dictionaryFieldType && this.item.phyFieldEnName) {
        const { dictionaryFieldType, fieldType, phyFieldEnName } = this.item;
        if (dictionaryFieldType === 3
          || ((dictionaryFieldType === 2 || dictionaryFieldType === 4) && (phyFieldEnName.indexOf('city_guid') > -1 || phyFieldEnName.indexOf('city_name') > -1 || phyFieldEnName.indexOf('city_area_name') > -1 || phyFieldEnName.indexOf('city_area_guid') > -1))
          || (this.item.compareSymbol === '5' || this.item.compareSymbol === '6')
        ) {
          this.item.rightValueType = fieldType === 'string' ? 2 : 3;
        } else {
          this.item.rightValueType = fieldType === 'string' ? 0 : 1;
        }
      }
      this.rightValue = '';
      this.rightValueNew = [];
      this.item.rightValue = '';
      this.item.rightValueNew = [];
      // 切换比较符号以后，判断右侧值是否是必填的
      if (this.selectType) {
        if (this.needUserInput) { // 用户不需要输入
          this.rightValue = '';
          this.rightValueNew = [];
          this.item.rightValue = this.rightValueNew.join(',');
          this.item.rightValueNew = this.rightValueNew;
          this.item.rightValueValidate = true;
          this.rightValueValidate = true;
        } else {
          this.rightValueNew = [];
          this.item.rightValue = this.rightValueNew.join(',');
          this.item.rightValueNew = this.rightValueNew;
          this.item.rightValueValidate = this.item.rightValue.length;
          this.rightValueValidate = this.item.rightValue.length;
        }
      }
      if (this.compareSymbol === 9 || this.compareSymbol === 10) {
        this.item.rightValueValidate = true;
        this.rightValueValidate = true;
      }
    },
    changeEnum(item) {
      item.rightValue = this.rightValueNew.join(',');
      this.item.rightValueNew = this.rightValueNew;
      item.rightOptions = this.options;
      this.item.rightValueValidate = this.rightValueNew.length;
      this.rightValueValidate = this.rightValueNew.length;
    },
    changeInput() {
      if (this.dataType !== 'date') {
        const { rightValue, item } = this;
        const newVal = rightValue.replace(/\s+/g, '');
        this.isValidate = (/^[\w\u4E00-\u9FA5,-]*$/.test(newVal));
        if (this.isValidate) {
          const newValLower = newVal;
          // eslint-disable-next-line max-len
          // AND | CREATE | DELETE | DROP | FROM | INSERT | JOIN | LIKE | OR | SELECT | UNION | UPDATE | WHERE | TRUNCATE
          this.isValidate = !(/^(and|create|delete|drop|insert|or|update|truncate|select|from|where|join|union|like)$/.test(newValLower.toLowerCase()));
        }
        this.item.rightValue = newVal;
        this.item.isValidate = this.isValidate;
        // 验证必填 字符串类型可以为空，数字类型必填
        const rightValidate = item.fieldType === 'string'
          || ((rightValue || rightValue === 0) && item.fieldType !== 'string');
        this.item.rightValueValidate = rightValidate;
        this.rightValueValidate = rightValidate;
      } else if (this.dataType === 'date') { // 后台要求序列化之后传值
        this.item.rightValue = this.rightValue;
      }
    },
    // 根据字段类型处理compareSymbols
    handleFilterOptions(fieldType) { // string类型可选模糊等于（like），其他类型不可选
      this.filterOptions.forEach((item) => {
        if (item.value === '7')item.disabled = fieldType !== 'string';
      });
    },
    focusEnum() {
      if (this.isDetail) {
        // 有些时候新开城，刚开始没考虑focus情况，后续需要把这块逻辑优化，
        // 不需要传options给接口，直接focus调取接口就行
        this.isDetail = false;
        const { dictionaryFieldType, phyFieldEnName } = this.item;
        const {
          // eslint-disable-next-line no-unused-vars
          selectOptions, attrCnName, isTag, dataSetId
        } = this;
        const selectData = selectOptions.find(item => item.attrCnName === attrCnName);
        if (dictionaryFieldType === 3) {
          this.request.getDim({ id: selectData.dictionaryFieldId }).then((res) => {
            this.options = res || [];
          });
        }
        if ((dictionaryFieldType === 2 || dictionaryFieldType === 4)
          && (phyFieldEnName.indexOf('city_guid') > -1 || phyFieldEnName.indexOf('city_name') > -1 || phyFieldEnName.indexOf('city_area_name') > -1 || phyFieldEnName.indexOf('city_area_guid') > -1)) {
          // eslint-disable-next-line max-len
          this.request.getCityList({ data: { type: this.isTag ? 1 : 2, dataSetId } }).then((res) => {
          // eslint-disable-next-line max-len
            if (res && res.length) this.options = res.map(item => ({ firstPair: item, secondPair: item }));
          });
        }
      }
    }
  }
};
</script>

<style scoped lang="less">
@import '../style/variable';
.el-select {
  margin-right: 10px
}
.select-symbol{
  width: 130px;
}
.el-input{
  display: inline-block;
  width: auto;
  margin-right: 10px
}
.attr-name{
  display: inline-block;
  position: relative;
}
span.validate-text{
  position: absolute;
  top: 34px;
  left: 0;
  font-size: 12px;
  color: @red;
}

</style>
