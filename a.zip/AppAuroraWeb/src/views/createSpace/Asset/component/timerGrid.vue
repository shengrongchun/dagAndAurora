<template>
  <div class="flex-box">
    <div class="flex-box">
      <el-table
        v-loading="searching"
        ref="table"
        :data="data"
        :cell-class-name="classNameHandle"
        :border="border"
        :stripe="stripe"
        :header-cell-style="tableHeaderColor"
        height="100%"
        highlight-current-row
        style="width:100%;margin-bottom: 12px;"
        @sort-change="sortMethod"
        @row-dblclick="rowClick">
        <slot/>
      </el-table>
    </div>
    <el-pagination
      v-if="pagination"
      :current-page="currentPage"
      :page-sizes="pageSizes"
      :page-size="size"
      :layout="layout"
      :total="total"
      background
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
    />
  </div>
</template>

<script>
import deepCopy from '@/utils/deepCopy';
import errorMessage from '@/utils/errorMessage';
import isEqual from '@/utils/equals';

export default {
  props: {
    remoteMethod: {
      type: Function,
      required: true
    },
    rowClick: {
      type: Function,
      default() {}
    },
    border: {
      type: Boolean,
      default: true
    },
    stripe: {
      type: Boolean,
      default: true
    },
    pageSize: {
      type: Number,
      default: 20
    },
    pageSizes: {
      type: Array,
      default: () => [15, 20, 30, 40, 50]
    },
    layout: {
      type: String,
      default: 'total, sizes, prev, pager, next, jumper'
    },
    pageIndexName: {
      type: String,
      default: 'current'
    },
    pageSizeName: {
      type: String,
      default: 'pageSize'
    },
    totalCountName: {
      type: String,
      default: 'total'
    },
    dataName: {
      type: String,
      default: 'data'
    },
    classNameHandle: {
      type: [String, Function],
      default: ''
    },
    pagination: {
      type: Boolean,
      default: true
    },
  },

  data() {
    return {
      postData: {},
      searching: false,
      data: [],
      currentPage: 1,
      size: 20,
      total: 0,
      timer: null
    };
  },
  beforeDestroy() {
    clearTimeout(this.timer);
  },
  methods: {
    loadData(params) {
      this.currentPage = 1;
      return this._loadData(params);
    },
    _loadData(params) {
      if (params) {
        this.postData = deepCopy(params);
      }
      this.postData = this.postData || {};
      this.postData[this.pageIndexName] = this.currentPage;
      this.postData[this.pageSizeName] = this.size;
      this.getTableData();
    },
    async getTableData() {
      try {
        const response = await this.remoteMethod(this.postData);
        if (response) {
          if (isEqual(this.data, response[this.totalCountName])) {
            this.timer = setTimeout(() => {
              this.getTableData();
            }, 3000);
          } else {
            this.searching = true;
            this.data = response[this.dataName];
            this.total = response[this.totalCountName];
            let isRefresh = false;
            this.data.forEach((item) => {
              if (item.taskStatus === '-1' || item.taskStatus === '02')isRefresh = true;
            });
            if (isRefresh) {
              clearTimeout(this.timer);
              this.timer = setTimeout(() => {
                this.getTableData();
              }, 3000);
            }
          }
        }
        this.searching = false;
        return response;
      } catch (e) {
        errorMessage.show(e);
        this.searching = false;
        return null;
      }
    },
    async reload() {
      return this._loadData(this.postData);
    },
    handleSizeChange(size) {
      this.size = size;
      this._loadData();
    },
    handleCurrentChange(page) {
      this.currentPage = page;
      this._loadData();
    },
    tableHeaderColor({ rowIndex }) {
      if (rowIndex === 0) {
        return 'background-color: #f4f6f9;font-weight: 500;font-size:14px';
      }
      return null;
    },
    sortMethod(col) {
      this.$emit('sortMethod', col);
    }
  }
};
</script>

<style scoped>
  .flex-box {
    display: flex;
    flex-direction: column;
    flex-grow: 1;
    height: inherit;
    width: 100%;
  }
  .el-pagination {
    text-align: right
  }
</style>
