<template>
  <el-dialog
    title="配置"
    :visible.sync="dialogVisible"
    :show-close="false"
    :close-on-click-modal="false"
    :close-on-press-escape="false"
    width="800px"
    custom-class="config-dialog">
    <div
      class="dialog-content"
      v-loading="loading">
      <el-tabs
        type="border-card"
        v-model="activeName">
        <el-tab-pane
          v-for="(item,index) in groupList"
          :key="item.tableName+index"
          :label="item.tableName"
          :name="item.tableName">
          <div class="group-index-dim">
            <div class="index-content">
              <span>指标</span>
              <span
                v-if="!(item.indexInfoVos && item.indexInfoVos.length)"
                style="font-size:14px"
              >暂无数据</span>
              <div class="item-content">
                <span
                  v-for="(indexItem,key) in item.indexInfoVos"
                  :key="key+'index'">{{ indexItem.indexName }}</span>
              </div>
            </div>
            <div class="dim-content">
              <span>维度</span>
              <span
                v-if="!(item.dimInfoVos && item.dimInfoVos.length)"
                style="font-size:14px"
              >暂无数据</span>
              <div class="item-content">
                <span
                  v-for="(dimItem,key) in item.dimInfoVos"
                  :key="key+'dim'">{{ dimItem.dimName }}</span>
              </div>
            </div>
          </div>
          <div class="group-time">
            数据日期：
            <el-date-picker
              v-model="item.dateRange"
              type="daterange"
              range-separator="至"
              value-format="yyyy-MM-dd"
              start-placeholder="开始日期"
              end-placeholder="结束日期"
              :picker-options="pickerOptions"/>
          </div>
        </el-tab-pane>
      </el-tabs>
    </div>
    <span
      slot="footer"
      class="dialog-footer">
      <el-button
        type="primary"
        @click="confirmDialog">确 认</el-button>
      <el-button @click="cancelConfirm">取消规则</el-button>
    </span>
  </el-dialog>
</template>
<script>
import request from '@/api/AssetsData.js';
import options from '../options.js';

export default {
  props: {
    indexInfoList: {
      type: Array,
      default: () => []
    },
    dimInfoList: {
      type: Array,
      default: () => []
    },
    dataSetId: {
      type: [String, Number],
      default: null
    },
    currentGuid: {
      type: String,
      default: undefined
    },
    detailType: {
      type: String,
      default: undefined
    }
  },
  data() {
    return {
      dialogVisible: false,
      loading: false,
      groupList: [],
      tempSaveTime: {},
      pickerOptions: options.pickerOptions,
      isCancel: false,
      activeName: ''
    };
  },
  mounted() {
  },
  methods: {
    toggleDialog() {
      this.dialogVisible = !this.dialogVisible;
      if (this.dialogVisible) this.getConfigData();
    },
    getConfigData() {
      const { indexInfoList, dimInfoList, dataSetId } = this;
      const params = {
        indexInfoList,
        dimInfoList,
        dataSetId,
        taskGuid: this.detailType ? undefined : this.currentGuid,
        scheduleGuid: this.detailType ? this.currentGuid : undefined,
      };
      this.loading = true;
      request.getSelectDataModel(params).then((res) => {
        if (res.length) {
          res.forEach((item) => {
            // eslint-disable-next-line max-len
            item.dateRange = this.tempSaveTime[item.tableName] || (!this.isCancel && item.startDate && item.endDate ? [item.startDate, item.endDate] : []);
          });
        }
        this.groupList = res || [];
        if (this.groupList && this.groupList.length) this.activeName = this.groupList[0].tableName;
      }).finally(() => {
        this.loading = false;
      });
    },
    cancelConfirm(type) {
      this.tempSaveTime = {};
      if (type !== false) this.$emit('confirmConfig', false);
      this.dialogVisible = false;
      this.isCancel = type !== false;
    },
    confirmDialog() {
      const timeList = this.groupList.filter(item => item.dateRange && item.dateRange.length);
      const isAllTime = timeList.length === this.groupList.length;
      this.tempSaveTime = this.groupList.reduce((obj, item) => {
        obj[item.tableName] = item.dateRange;
        return obj;
      }, {});
      if (isAllTime) {
        this.dialogVisible = false;
        this.isCancel = false;
        if (isAllTime) this.$emit('confirmConfig', true, this.groupList);
      } else {
        // eslint-disable-next-line max-len
        const noTimeList = this.groupList.filter(item => !(item.dateRange && item.dateRange.length));
        this.$message({
          type: 'error',
          message: `请选择${noTimeList[0].tableName}对应日期!`
        });
      }
    }

  }
};
</script>
<style lang="less" scoped>
@import '../style/variable';
.el-tabs{
  /deep/ .el-tabs__content{
    padding:15px 0 0 0;
  }
}
/deep/ .el-tabs__nav-wrap{
  overflow: unset;
}
.content-group-name{
  width: 100%;
  display: flex;
  overflow-x:auto;
  // padding-bottom: 12px;
  span{
    flex-shrink: 0;
    padding:13px 18px;
    border:1px solid #d4d2d2;
    border-right:none;
    cursor: pointer;
    &:last-child{
      border-right:1px solid #d4d2d2;
    };
    &.active{
      color:@blue
    }
  }
}
.index-content,.dim-content{
  padding:15px 0 0 15px;
  display: flex;
  // border-bottom: 1px solid #d4d2d2;
  &>span{
    width: 70px;
    flex-shrink: 0;
    font-size: 16px;
  }
  &>div.item-content{
    flex-grow: 1;
    flex-wrap: wrap;
    display: flex;
    span{
      margin-right: 10px;
      padding:5px 8px;
      background: #d1d1d1;
      margin-bottom: 15px;
    }
  }
}
.group-time{
  margin:20px 0 20px 10px;
}
.clear-select{
  cursor: pointer;
  color:@blue;
  font-size: 14px;
  .el-icon-delete-solid{
    font-size: 16px;
    margin-right: 3px
  }
}

</style>
<style lang="less">
.config-dialog{
  .el-dialog-header{
    background-color: #f9f9f9;
  }
  .el-dialog__body{
    padding-top:0;
  }
  .el-dialog__footer{
    text-align:center
  }
}
</style>
