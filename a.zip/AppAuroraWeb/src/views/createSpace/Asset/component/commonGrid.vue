<template>
  <div
    class="flex-box"
    :class="{'small-table':smallPagination}">
    <div class="flex-box">
      <el-table
        v-loading="searching"
        ref="table"
        :data="data"
        :cell-class-name="classNameHandle"
        :border="border"
        :stripe="stripe"
        :header-cell-style="tableHeaderColor"
        height="100%"
        highlight-current-row
        :empty-text="emptyText"
        style="width: 100%;margin-bottom: 12px;"
        @selection-change="handleSelectionChange"
        @sort-change="sortMethod"
        @row-dblclick="rowClick">
        <slot/>
      </el-table>
    </div>
    <el-pagination
      v-if="pagination"
      :class="{'small-pagination':smallPagination}"
      :current-page="currentPage"
      :page-sizes="pageSizes"
      :pager-count="smallPagination ? 5 : null"
      :page-size="size"
      :layout="layout"
      :total="total"
      :background="!smallPagination && pagination"
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
    />
  </div>
</template>

<script>
import deepCopy from 'src/utils/deepCopy';
import errorMessage from 'src/utils/errorMessage';

export default {
  props: {
    remoteMethod: {
      type: Function,
      required: true,
    },
    rowClick: {
      type: Function,
      default() {}
    },
    border: {
      type: Boolean,
      default: true,
    },
    stripe: {
      type: Boolean,
      default: true,
    },
    pageSize: {
      type: Number,
      default: 20,
    },
    pageSizes: {
      type: Array,
      default: () => [15, 20, 30, 40, 50],
    },
    layout: {
      type: String,
      default: 'total, sizes, prev, pager, next, jumper',
    },
    pageIndexName: {
      type: String,
      default: 'current'
    },
    pageSizeName: {
      type: String,
      default: 'pageSize'
    },
    totalCountName: {
      type: String,
      default: 'total'
    },
    dataName: {
      type: String,
      default: 'data'
    },
    classNameHandle: {
      type: [String, Function],
      default: ''
    },
    pagination: {
      type: Boolean,
      default: true
    },
    emptyText: {// 无数据的提示话术
      type: String,
      default: '暂无数据'
    },
    smallPagination: {
      type: Boolean,
      default: false
    },
  },

  data() {
    return {
      postData: {},
      searching: false,
      data: [],
      currentPage: 1,
      size: 20,
      total: 0,
      multipleSelection: [],
    };
  },
  methods: {
    loadData(params) {
      this.currentPage = 1;
      return this._loadData(params);
    },

    async _loadData(params) {
      if (params) {
        this.postData = deepCopy(params);
      }
      this.postData = this.postData || {};
      this.postData[this.pageIndexName] = this.currentPage;
      this.postData[this.pageSizeName] = this.size;
      this.searching = true;
      try {
        const response = await this.remoteMethod(this.postData);
        if (response) {
          this.data = response[this.dataName];// data也需要重定义名称
          this.total = Number(response[this.totalCountName] || 0);
        }
        this.searching = false;
        return response;
      } catch (e) {
        errorMessage.show(e);
        this.searching = false;
        return null;
      }
    },
    async reload() {
      return this._loadData(this.postData);
    },
    handleSizeChange(size) {
      this.size = size;
      this._loadData();
    },
    handleCurrentChange(page) {
      this.currentPage = page;
      this._loadData();
    },
    handleSelectionChange(val) {
      this.multipleSelection = val;
      this.$emit('handleSelectionChange', this.multipleSelection);
    },

    clearSelectionChange() {
      this.multipleSelection = [];
    },
    tableHeaderColor({ rowIndex }) {
      if (rowIndex === 0) {
        return 'background-color: #f4f6f9;font-weight: 500;font-size:14px';
      }
      return null;
    },
    sortMethod(col) {
      this.$emit('sortMethod', col);
    }
  },
};
</script>

<style scoped lang="less">
  .flex-box {
    display: flex;
    flex-direction: column;
    flex-grow: 1;
    height: inherit;
    width: 100%;
  }
  .small-table{
    background: #fff;
  }
  .el-pagination {
    text-align: right;
    /deep/ .el-pagination__sizes{
      display: none
    }
    /deep/ ul.el-pager{
      /deep/ li{
        margin:0 2px;
        min-width: 25px;
      }
    }
    /deep/ .el-pagination__jump{
      margin-left:10px;
      /deep/ .el-input{
        width: 40px;
      }
    }
    /deep/ .btn-next{
      padding-left: 0;
      min-width: 25px;
    }
    /deep/ .btn-prev{
      padding-right: 0;
      min-width: 25px;
    }
  }
</style>
