<template>
  <el-dialog
    title="数据预览"
    width="700px"
    :visible.sync="dialogTableVisible"
    @close="closeDialog"
    custom-class="common-dialog">
    <el-table
      v-loading="loading"
      :data="gridData"
      border>
      <template v-for="(item,index) in gridTableTitle">
        <el-table-column
          align="center"
          :key="index"
          :property="item"
          :label="item"
          :width="item==='序号'?'60':'auto'"/>
      </template>
    </el-table>
    <span
      slot="footer"
      class="dialog-footer">
      <el-button
        type="primary"
        @click="dialogTableVisible=false">确 定</el-button>
    </span>
  </el-dialog>
</template>

<script>
import axios from 'axios';
import request from '@/api/AssetsData.js';

export default {
  data() {
    return {
      request,
      gridData: [],
      gridTableTitle: [],
      dialogTableVisible: false,
      loading: false,
      cancel: null
    };
  },
  created() {
  },
  methods: {
    toggleDialog(guid) {
      this.dialogTableVisible = !this.dialogTableVisible;
      this.loading = true;
      this.gridData = [];
      this.gridTableTitle = [];
      this.request.previewTask({ guid }, {
        cancelToken: new axios.CancelToken((c) => {
          this.cancel = c;
        })
      }).then((res) => {
        if (res && res.records) {
          const resData = res.records || [];
          const tableTitle = Object.keys(resData[0]) || [];
          tableTitle.unshift('序号');
          resData.forEach((val, index) => { val['序号'] = index + 1; });
          this.gridData = resData;
          this.gridTableTitle = tableTitle;
        }
      }).finally(() => {
        this.loading = false;
      });
    },
    closeDialog() {
      if (typeof this.cancel === 'function') {
        this.cancel('终止请求'); // 取消请求
      }
    }
  }
};
</script>
