<template>
  <div class="flex-box">
    <div class="search">
      <el-input
        placeholder="快速搜索保存的任务，双击可重复选中，亦可选择快速直接执行"
        v-model="taskName"
        @keyup.enter.native="searchData"
        clearable
        @clear="searchData"/>
      <el-button
        type="primary"
        @click="searchData">搜索</el-button>
    </div>
    <grid
      ref="grid"
      data-name="records"
      :smallPagination="true"
      :border="false"
      emptyText="无相关任务，请重新输入查询"
      :remote-method="getTableDataRemoteMethod"
      :row-click="rowClick"
      @sortMethod="sortMethod">
      <template v-for="item in collectTableList">
        <el-table-column
          :key="item.prop"
          :prop="item.prop"
          :label="item.label"
          header-align="center"
          align="center"
          :min-width="item.minWidth"
          :sortable="item.sortable"
          show-overflow-tooltip/>
      </template>
      <el-table-column
        label="操作"
        header-align="center"
        align="center"
        width="100px">
        <template slot-scope="scope">
          <span class="icon-handle">
            <el-tooltip
              effect="dark"
              content="立即执行"
              placement="top">
              <i
                class="el-icon-video-play"
                @click="executeTask(scope.row.guid)"/>
            </el-tooltip>
            <el-tooltip
              effect="dark"
              content="删除"
              placement="top">
              <i
                class="el-icon-delete-solid"
                @click="changeStatusDel(scope.row)"/>
            </el-tooltip>
          </span>
        </template>
      </el-table-column>
    </grid>
    <el-dialog
      :visible.sync="dialogVisible"
      custom-class="select-dialog"
      center
      append-to-body
      width="500px">
      <span>
        <i class="el-icon-warning"/>确认删除<span style="color:#E6A23C">
        {{ delTaskItem.taskName || '--' }} </span>收藏任务？
      </span>
      <span
        slot="footer"
        class="dialog-footer">
        <el-button @click="dialogVisible =false">取 消</el-button>
        <el-button
          type="primary"
          @click="delConfirm">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>
<script>
import request from '@/api/AssetsData.js';
import options from '../options';
import grid from './commonGrid';

export default {
  components: {
    grid
  },
  data() {
    return {
      taskName: null,
      collectTableList: options.collectTableList,
      searchParams: { taskName: null, taskType: 3 },
      delTaskItem: {},
      dialogVisible: false,
    };
  },
  created() {
  },
  methods: {
    searchData() {
      this.searchParams.taskName = this.taskName;
      this.loadTableData();
    },
    loadTableData() { // 我的收藏列表
      this.$refs.grid.loadData({ search: this.searchParams });
    },
    getTableDataRemoteMethod(params) { // 收藏列表list
      return request.getTaskTableData(params);
    },
    sortMethod(item) { // 排序
      let type = 0;
      if (item.order) type = item.order === 'ascending' ? 1 : 2;
      Object.assign(this.searchParams, {
        sort: { name: item.prop, type },
      });
      this.loadTableData();
    },
    rowClick(row) { // 获取详情接口
      this.$emit('getDetail', row.guid, 'timingTask');
    },
    executeTask(guid) { // 立即执行
      const params = { guid, taskType: 3 };
      request.getManulSumbit(params).then((res) => {
        if (res) {
          this.$message.success('立即执行成功');
          this.$emit('getRightTableList');
        }
      });
    },
    changeStatusDel(item) { // 删除任务
      this.delTaskItem = item;
      this.dialogVisible = true;
    },
    delConfirm() { // 删除确认
      const params = {
        guid: this.delTaskItem.guid,
        taskTag: 2,
        taskType: 3
      };
      request.changeTimingTaskStatus(params).then((res) => {
        if (res) {
          this.$message.success('删除成功');
          this.loadTableData();
        }
      }).finally(() => {
        this.dialogVisible = false;
      });
    },
  },

};
</script>
<style lang="less" src="../style/index.less"></style>
