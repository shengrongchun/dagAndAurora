import moment from 'moment';

const tableList = [
  { label: '任务号', prop: 'guid', width: 150 },
  { label: '任务名称', prop: 'taskName' },
  { label: '任务描述', prop: 'taskDesc' },
  { label: '状态', prop: 'taskStatus', width: 80 },
  { label: '数据通知人', prop: 'notifyList' },
  { label: '开始时间', prop: 'startDate' },
  { label: '结束时间', prop: 'endDate' }
];

const statusList = [// 状态筛选
  { name: '全部', status: '' },
  { name: '初始化', status: '-1' },
  { name: '已完成', status: '00' },
  { name: '运行中', status: '02' },
  { name: '取消', status: '03' },
  { name: '异常', status: '01' }
];

const statusType = {// 状态转化
  '02': '运行中',
  '03': '取消',
  '00': '已完成',
  '01': '异常',
  '-1': '初始化'
};

const filterOptions = [// 筛选条件select
  { name: '等于(=)', value: '0' },
  { name: '大于(>)', value: '1' },
  { name: '小于(<)', value: '2' },
  { name: '大于等于(>=)', value: '3' },
  { name: '小于等于(<=)', value: '4' },
  { name: '包含(in)', value: '5' },
  { name: '不包含(not in)', value: '6' },
  { name: '模糊等于(like)', value: '7', disabled: false },
  { name: '不等于(<>)', value: '8' },
  { name: '为空(is null)', value: '9' },
  { name: '不为空(is not null)', value: '10' },
];

const cycleOptions = [
  { name: '每天', value: 1 },
  { name: '每周', value: 2 },
  { name: '每月', value: 3 },
];

const weekOptions = [
  { name: '周一', value: '1' },
  { name: '周二', value: '2' },
  { name: '周三', value: '3' },
  { name: '周四', value: '4' },
  { name: '周五', value: '5' },
  { name: '周六', value: '6' },
  { name: '周日', value: '7' },
];

const drawerTableList = [// 定时任务
  { label: '任务名称', prop: 'taskName' },
  { label: '定时周期', prop: 'schduledCycle' },
  {
    label: '最后执行时间', prop: 'lastProcessDate', sortable: 'custom', minWidth: 90
  },
  {
    label: '创建日期', prop: 'createDate', sortable: 'custom', minWidth: 100
  },
];

const collectTableList = [// 收藏列表
  { label: '任务名称', prop: 'taskName' },
  { label: '任务描述', prop: 'taskDesc' },
  {
    label: '保存时间', prop: 'createDate', sortable: 'custom', minWidth: 100
  },
];


function monthOptions() {
  const arr = [];
  new Array(30).fill(1).map((item, index) => (arr.push({ name: `${index + 1}日`, value: index + 1 })));
}


function dateObj(start, end) {
  const startDate = moment().subtract(start, 'days').format('YYYYMMDD');
  const endDate = moment().subtract(end, 'days').format('YYYYMMDD');
  return [startDate, endDate];
}

function lastDayTime() {
  return dateObj(1, 1);
}

function lastDayTimeHour() {
  const startDate = moment().subtract(1, 'days').format('YYYYMMDDHH');
  const endDate = moment().subtract(0, 'days').format('YYYYMMDDHH');
  return [startDate, endDate];
}

const pickerOptions = {
  disabledDate(time) {
    return time.getTime() > Date.now() - (3600 * 1000 * 24);
  },
  shortcuts: [{
    text: '昨天',
    onClick(picker) {
      picker.$emit('pick', dateObj(1, 1));
    }
  }, {
    text: '最近一周',
    onClick(picker) {
      picker.$emit('pick', dateObj(7, 1));
    }
  }, {
    text: '最近15天',
    onClick(picker) {
      picker.$emit('pick', dateObj(15, 1));
    }
  }, {
    text: '最近一个月',
    onClick(picker) {
      picker.$emit('pick', dateObj(30, 1));
    }
  }],
};


const pickerOptionsHour = {
  disabledDate(time) {
    return time.getTime() > Date.now();
  },
};


export default {
  lastDayTime,
  pickerOptions,
  tableList,
  statusList,
  statusType,
  filterOptions,
  monthOptions,
  cycleOptions,
  weekOptions,
  drawerTableList,
  collectTableList,
  pickerOptionsHour,
  lastDayTimeHour
};
