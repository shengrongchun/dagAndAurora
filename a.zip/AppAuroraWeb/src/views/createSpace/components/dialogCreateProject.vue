<template>
  <el-dialog
    :visible.sync="visible"
    :close-on-click-modal="false"
    :before-close="()=> {$emit('close')}"
    :title="obj.id?'编辑项目':'创建项目'"
    width="500px">
    <el-form
      ref="form"
      :model="form"
      :rules="rules"
      label-width="100px">
      <el-form-item
        label="项目名称"
        prop="name">
        <el-input
          v-model="form.name"
          :maxlength="20"
          :show-word-limit="true"
          placeholder="请输入项目名称，最多20个字符"
          style="width: 300px;"/>
      </el-form-item>
      <el-form-item
        label="业务线"
        prop="bizType">
        <el-select
          v-model="form.bizType"
          style="width: 300px;">
          <el-option
            v-for="(name,idx) in bizTypeList"
            :key="idx"
            :value="name"
          >{{ name }}</el-option>
        </el-select>
      </el-form-item>
      <el-form-item
        label="描述"
        prop="description">
        <el-input
          v-model="form.description"
          :rows="4"
          type="textarea"
          style="width: 300px;"/>
      </el-form-item>
      <!-- <el-form-item
        label="管理员"
        prop="manager">
        <el-input
          v-model="form.manager"
          type="textarea"
          placeholder="用户中文名+工号。多个管理员时，中间用分号相隔"
          style="width: 300px;"/>
      </el-form-item> -->
    </el-form>
    <span
      slot="footer"
      class="dialog-footer">
      <el-button @click="$emit('close')">取 消</el-button>
      <el-button
        type="primary"
        @click="save">保存</el-button>
    </span>
  </el-dialog>
</template>
<script>
// import ssoAuth from '@hb/sso-auth';
import { createProject } from 'src/api/space.js';

export default {
  props: {
    visible: {
      type: Boolean,
      default: false
    },
    obj: {
      type: Object,
      default() {
        return {};
      }
    }
  },
  data() {
    return {
      form: {
        id: this.obj.id,
        name: this.obj.name, // 名称
        bizType: this.obj.bizType, // 业务线
        description: this.obj.description, // 描述
        // manager: ssoAuth.userInfo.realName, // 管理员
      }
    };
  },
  created() {
    this.bizTypeList = ['单车', '助力车', '直租', '顺风', '风控', '金融', '景区', '政府', '换电', '财务', '平台', '客服'];
    this.rules = {
      name: [
        { required: true, message: '请输入项目名称', trigger: 'blur' },
      ],
      bizType: [
        { required: true, message: '请选择业务线', trigger: 'blur' },
      ],
    };
  },
  methods: {
    save() {
      this.$refs.form.validate((valid) => {
        if (valid) {
          createProject(this.form).then(() => {
            this.$emit('close');
            this.$emit('success', this.form.id ? this.form : {});
          });
          return true;
        }
        return false;
      });
    }
  }
};
</script>
