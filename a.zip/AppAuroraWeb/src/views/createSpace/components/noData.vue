<template>
  <div class="no-data">
    <img
      :draggable="false"
      :style="noDataStyle"
      src="../../../assets/no.png"
    >
    <div class="text">{{ title }}</div>
    <slot />
  </div>
</template>
<script>
export default {
  props: {
    title: {
      type: String,
      default: '暂时没有任何项目哦，快开始吧'
    },
    noDataStyle: {
      type: Object,
      default: () => ({
      })
    }
  }
};
</script>
<style scoped lang="less">
.no-data {
  height: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  img {
    min-width: 50px;
    max-width: 300px;
    min-height: 50px;
    max-height: 300px;
  }
  .text {
    color: #aaa;
    margin: 15px 0;
  }
}
</style>
