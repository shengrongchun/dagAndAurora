<template>
  <el-dialog
    :visible.sync="visible"
    :close-on-click-modal="false"
    :before-close="()=> {$emit('close')}"
    :title="title"
    width="580px"
    append-to-body>
    <el-form
      ref="form"
      :model="form"
      :rules="rules"
      label-width="100px">
      <template>
        <template v-if="sqlPresto">
          <el-form-item
            label="数据缓存"
            prop="refreshable">
            <el-switch
              v-model="form.refreshable"
              active-color="#409EFF"
              inactive-color="#aaa"
              :active-value="1"
              :inactive-value="0"
              @change="$refs.form.clearValidate('cacheRefreshCron')"/>
          </el-form-item>
          <!-- <el-form-item
            v-if="form.refreshable"
            label="刷新模式"
            prop="cacheRefreshMode">
            <el-radio-group
              v-if="form.refreshable"
              v-model="form.cacheRefreshMode">
              <el-radio label="total">全量</el-radio>
              <el-radio label="increment">增量</el-radio>
            </el-radio-group>
          </el-form-item> -->
          <el-form-item
            v-if="form.refreshable"
            :prop="form.refreshable?'cacheRefreshCron':''"
            label="刷新频率">
            <CronTime
              v-model="form.cacheRefreshCron"/>
          </el-form-item>
          <!-- <el-alert
            title="提示"
            type="warning"
            :closable="false"
            show-icon>
            <span>
              <div :style="{'margin':'10px 0'}">1. 数据缓存用于缓存源数据集的数据，主要用于presto类型的耗时数据集</div>
              <div :style="{'margin':'10px 0'}">2. 数据缓存在数据集的数量上有一定限制，目前单个数据集仅支持缓存20w数据行</div>
              <div :style="{'margin':'10px 0'}">3. 增量刷新和全量刷新的模式区别，在于全量刷新会清除历史数据</div>
            </span>
          </el-alert> -->
        </template>
        <span v-else>确定上线吗？</span>
      </template>
    </el-form>
    <span
      slot="footer"
      class="dialog-footer">
      <el-button
        @click="$emit('close')"
      >{{ (type==='online'||type==='line')?'暂不上线':'取消' }}</el-button>
      <el-button
        type="primary"
        @click="line">{{ (type==='online'||type==='line')?'上线':'保存' }}</el-button>
    </span>
  </el-dialog>
</template>
<script>
import { online, queryScheduleInfo, updateScheduleInfo } from 'src/api/space.js';
import CronTime from './cronTime';

export default {
  components: {
    CronTime
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
    type: {
      type: String,
      default: 'online'
    },
    obj: {
      type: Object,
      default() {
        return {};
      }
    }
  },
  data() {
    return {
      sqlPresto: this.type !== 'online',
      form: {
        dataSetId: this.obj.dataSetId || this.obj.id,
        dataSetType: this.obj.dataSetType || this.obj.type,
        refreshable: this.obj.dataSourceType === 'presto' ? 1 : 0, // 0 不刷新 1刷新
        cacheRefreshCron: null, // 时间 cron表达式
        cacheRefreshMode: 'total', // increment 增量 total 全量
      }
    };
  },
  computed: {
    title() {
      return `数据集-${this.obj.name}`;
    }
  },
  created() {
    if (this.type === 'line') {
      this.sqlPresto = true;
    }
    this.queryScheduleInfo();
    this.rules = {
      cacheRefreshCron: [
        { required: true, message: '刷新时间必填', trigger: 'change' },
      ]
    };
  },
  methods: {
    queryScheduleInfo() {
      queryScheduleInfo({
        dataSetId: this.obj.dataSetId || this.obj.id,
        dataSetType: this.obj.dataSetType || this.obj.type,
      }).then((res) => {
        if (res) {
          const { refreshable, cacheRefreshMode, cacheRefreshCron } = res;
          this.form.refreshable = refreshable;
          this.form.cacheRefreshMode = cacheRefreshMode || 'total';
          this.form.cacheRefreshCron = cacheRefreshCron;
        }
      });
    },
    line() {
      if (this.obj.dataSourceType === 'presto' && !this.sqlPresto) {
        this.sqlPresto = true;
        return;
      }
      //
      this.$refs.form.validate((valid) => {
        if (valid) {
          if (this.type === 'online' || this.type === 'line') {
            online(this.form).then(() => {
              this.$message({ type: 'success', message: '上线成功' });
              this.$emit('close');
            });
          } else { // 配置信息保存
            updateScheduleInfo(this.form).then(() => {
              this.$message({ type: 'success', message: '保存成功' });
              this.$emit('close');
            });
          }
          return true;
        }
        return false;
      });
    }
  }
};
</script>
