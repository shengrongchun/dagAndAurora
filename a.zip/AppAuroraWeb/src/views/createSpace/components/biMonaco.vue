<template>
  <div
    v-loading="loading"
    :style="{height: sqlHeight + 'px'}"
    class="costom-sql">
    <div class="query">
      <div
        :class="`operate-bar ${theme}`">
        <div
          v-if="showOperate.run"
          :class="{gray: dataSourceId === 'undefined'}"
          class="operate-item"
          @click="executeSql">
          <el-tooltip
            :open-delay="1000"
            content="测试运行"
            placement="bottom-start"
            effect="dark">
            <i class="iconfont icon-yunhang"/>
          </el-tooltip>
        </div>
        <div
          v-if="showOperate.close"
          class="operate-item">
          <el-tooltip
            :open-delay="1000"
            content="结束"
            placement="bottom-start"
            effect="dark">
            <i class="iconfont icon-jieshu"/>
          </el-tooltip>
        </div>
        <div
          v-if="showOperate.save"
          class="operate-item">
          <el-tooltip
            :open-delay="1000"
            content="保存"
            placement="bottom-start"
            effect="dark">
            <i class="iconfont icon-baocun"/>
          </el-tooltip>
        </div>
        <div
          v-if="showOperate.format"
          class="operate-item">
          <el-tooltip
            :open-delay="1000"
            content="格式化"
            placement="bottom-start"
            effect="dark">
            <i
              class="iconfont icon-format_icon"
              @click="formatCode"/>
          </el-tooltip>
        </div>
        <div
          v-if="showOperate.changeTheme"
          class="operate-item">
          <el-tooltip
            :open-delay="1000"
            content="主题切换"
            placement="bottom-start"
            effect="dark">
            <i
              class="iconfont icon-zhutifenxi"
              @click="changeTheme"/>
          </el-tooltip>
        </div>
      </div>
      <div
        id="editor"
        :class="{'look':disabled}"
        :style="{height: (sqlHeight*0.6-42)+'px'}"
      />
    </div>
    <div
      v-if="showOperate.run"
      :class="`result ${theme}`">
      <el-tabs>
        <el-tab-pane>
          <span slot="label"><i class="el-icon-date"/>运行结果</span>
          <div
            v-if="!tableData.length"
            class="runing">
            <NoData
              :noDataStyle="noDataStyle"
              title="运行sql后可以看到结果噢~"/>
          </div>
          <div
            v-else
            class="runed">
            <el-table
              :data="tableData"
              :height="sqlHeight*0.4-80"
              border
              style="width: 100%">
              <el-table-column
                v-for="item in columnList"
                :key="item"
                :prop="item"
                :label="item"
                min-width="200"
              />
            </el-table>
          </div>
        </el-tab-pane>
      </el-tabs>
    </div>
  </div>
</template>
<script>
import * as monaco from 'monaco-editor';
import sqlFormatter from 'sql-formatter';
import { executeSql } from 'src/api/space.js';
import NoData from './noData';

export default {
  components: {
    NoData,
  },
  props: {
    showOperate: {
      type: Object,
      default: () => {},
    },
    dataSourceId: {
      type: String,
      default: () => '',
    },
    sql: {
      type: String,
      default: null
    },
    dataSourceType: {
      type: String,
      default: () => '',
    },
    disabled: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      // options: {
      //   theme: 'vs-dark', // 两种主题 vs/vs-dark
      //   automaticLayout: true, // 编辑器随浏览器窗口自动调整大小
      //   // 代码略缩图
      //   minimap: {
      //     enabled: false
      //   },
      //   readOnly: true // 编辑器不可编辑
      // },
      tableData: [],
      columnList: [],
      editor: null,
      theme: 'vs-code', // 两种主题 vs/vs-dark
      noDataStyle: {
        width: '100px',
        marginTop: '0',
      },
      loading: false,
      sqlHeight: document.body.clientHeight - 250,
    };
  },
  mounted() {
    this.projectId = this.$route.params.projectId;
    this.editor = monaco.editor.create(document.getElementById('editor'), {
      value: this.sql,
      language: this.dataSourceType,
      theme: this.theme
    });
    //  自动提示
    // this.editor.trigger('', 'editor.action.triggerSuggest', {});
    // 自适应宽度
    window.onresize = () => {
      this.editor.layout();
    };
  },
  methods: {
    onMounted(editor) {
      this.editor = editor;
    },
    executeSql() {
      // 数据源有值的时候，才能运行
      if (this.dataSourceId === 'undefined') {
        return;
      }
      this.loading = true;
      const params = {
        dataSourceId: this.dataSourceId, // 数据源id
        dataSourceType: this.dataSourceType,
        sql: this.getValue()
      };
      executeSql(params).then((res) => {
        this.tableData = res.data;
        this.columnList = Object.keys(res.data[0] || {});
      }).finally(() => {
        this.loading = false;
      });
    },
    getValue() {
      return this.editor.getValue();
    },
    // onCodeChange(value) {
    // },
    // 格式化
    formatCode() {
      this.editor.setValue(sqlFormatter.format(this.editor.getValue()));
    },
    changeTheme() {
      this.theme = this.theme === 'vs' ? 'vs-dark' : 'vs';
      monaco.editor.setTheme(this.theme);
    }
  }
};
</script>

<style lang="less" scoped>
.look {
  pointer-events: none;
}
.costom-sql {
  border: 2px solid #f1f1f1;
  .query {
    height: 60%;
    .operate-bar {
      display: flex;
      padding: 10px 14px;
      background: rgb(244, 244, 245);
      color: #333;
      .gray {
        color: #999;
      }
      &.vs-dark {
        background: rgb(48, 49, 51);
        color: #fff;
      }
      .operate-item {
        margin-right: 16px;
        display: flex;
        flex-direction: column;
        align-items: center;
        cursor: pointer;

        i {
          font-size: 18px;
        }
      }
  }
  }

  .result {
    height: 220px;
    border-top: 1px solid rgb(211,211,211);
    color: #666;
    /deep/.el-tabs__header {
      padding: 0 20px;
    }
    /deep/.el-tabs__content {
      padding: 0 20px;
    }
    &.vs-dark {
      background: rgb(30, 30, 30);
      border-top: 1px solid rgb(92, 90, 90);
      color: #fff;
      /deep/.el-tabs__active-bar  {
        background-color: #fff;
      }
      /deep/.el-tabs__item.is-active {
        color: #fff;
      }
      /deep/.el-tabs__header {
        box-shadow: 0px 2px 5px #000;
      }
    }
    /deep/.el-tabs__nav-wrap::after {
      position: inherit;
    }
    /deep/.el-tabs__item {
      color: #999;
      font-size: 14px;
      font-weight: 400;
      &.is-active {
        color: #000;

      }
      i {
        margin-right: 2px;
      }
    }
    /deep/.el-tabs__active-bar  {
      height: 1px;
      background-color: #333;
    }
    /deep/.el-table th>.cell {
      white-space: inherit;
    }

    .runing {
      font-size: 14px;
      margin-left: 4px;
      span {
        margin-left: 4px;
      }
    }
  }
  #editor {
    height: 300px;
  }
}
</style>
