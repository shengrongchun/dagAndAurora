<template>
  <div v-loading="loading">
    <div
      ref="chart"
      class="charts"/>
    <slot />
  </div>
</template>
<script>
import echarts from 'echarts';
import { queryChartData } from '../../../api/panel';
import deepCopy from '../../../utils/deepCopy';

export default {
  props: {
    data: {
      type: Object,
      default() {
        return {};
      }
    }
  },
  data() {
    return {
      loading: false,
      extra: []
    };
  },
  watch: {
    '$store.state.panel.theme': function theme() {
      this.myChart.dispose();
      this.myChart = echarts.init(this.$refs.chart, this.$store.state.panel.theme);
      this.init();
    },
    'data.styles': {// 监听样式变化立即apply
      handler: function watch() {
        if (Object.keys(this.data.params).length < 1 || this.data.params.changeData) {
          delete this.data.params.changeData;
          return;
        }
        // 样式变动重新设置echarts
        this.$emit('apply', { res: this.res, chartData: deepCopy(this.data), myChart: this.myChart });
      },
      deep: true
    },
  },
  created() {
    this.preView = this.$store.state.panel.preView;
    this.$store._vm.$on(`${this.data.i}update${this.preView}`, (data) => { // 请求数据 更新
      this.queryChartData(data);
    });
    this.$store._vm.$on(`${this.data.i}search${this.preView}`, (data) => { // 请求数据 查询
      this.searchInit = true;
      this.extra = data;
      this.queryChartData(this.data);
    });
  },
  mounted() {
    this.myChart = echarts.init(this.$refs.chart, this.$store.state.panel.theme);
    if (!this.searchInit) {
      this.init();
    }
  },
  destroyed() {
    this.$store._vm.$off(`${this.data.i}update${this.preView}`);
    this.$store._vm.$off(`${this.data.i}search${this.preView}`);
  },
  methods: {
    init() {
      const { dimensions, metrics } = this.data.params;
      if (dimensions && metrics && dimensions.length > 0 && metrics.length > 0) { // 初始化编辑请求数据
        this.queryChartData(this.data);
      }
    },
    queryChartData(data) {
      this.loading = true;
      const { params, type, i } = data;
      const { id, state } = this.$route.params;
      queryChartData({
        params,
        extra: this.extra,
        compQuery: {
          compId: i,
          dashBoardId: id === 'create' ? null : id,
          dashBoardStage: state === 'online' ? 3 : null
        }
      }, type).then((res) => {
        this.res = res;
        this.$emit('apply', { res, chartData: deepCopy(data), myChart: this.myChart });
      }).finally(() => {
        this.loading = false;
      });
    },
  },
};
</script>
<style scoped lang="less">
.charts {
  width: 100%;
  height: 100%;
  > div {
    width: 100% !important;
  }
}
</style>
