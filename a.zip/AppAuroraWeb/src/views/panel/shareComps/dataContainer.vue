<template>
  <div class="container">
    <div class="left"><slot /></div>
    <div class="right">
      <template v-if="!dataAnalyName">
        <el-select
          :style="{'width':dataset?'calc(100% - 25px)':'100%'}"
          placeholder="请选择数据集"
          value-key="id"
          :popper-append-to-body="false"
          @change="setChange"
          v-model="dataset">
          <el-option
            v-for="(set,index) in datasetList"
            :value="set"
            :label="set.name"
            :key="index+'set'"/>
        </el-select>
        <i
          v-if="dataset&&!urlParams.dataSetId"
          @click="editdataset"
          class="el-icon-edit"
          style="cursor: pointer;margin-left:5px"/>
      </template>
      <el-input
        v-else
        readonly
        v-model="dataAnalyName"/>
      <div
        class="dataset"
        v-for="(xy,idx) in xyList"
        :key="idx+'xy'">
        <div class="title">
          <i :class="'iconfont '+xy.icon"/>
          <span>{{ xy.name }}</span>
          <el-input
            v-if="xy.name==='维度'"
            v-model="searchx"
            suffix-icon="el-icon-search"
            placeholder="请查询维度"/>
          <el-input
            v-else
            v-model="searchy"
            suffix-icon="el-icon-search"
            placeholder="请查询度量"/>
        </div>
        <div class="data-container">
          <ul class="list-container">
            <li
              draggable
              @dragstart.stop="(ev)=> {dragstart(ev,datas)}"
              v-for="(datas,idxs) in filterXY(xy.type)"
              :key="idxs">
              <i :class="'iconfont icon-'+datas.dataType"/>
              <span :class="{'double':datas.dataType==='double'}">{{ datas.label }}</span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { getDataSetInfo } from 'src/api/space.js';
import { queryOnline, queryXyOnline } from '../../../api/panel';
import { xyList } from './options';

export default {
  props: {
    data: {
      type: Object,
      default() {
        return {};
      }
    }
  },
  data() {
    return {
      dataAnalyName: null,
      dataset: null,
      searchx: '',
      searchy: '',
      datasetList: [], // 数据集列表
      xList: [], // 维度列表
      yList: [], // 度量列表
    };
  },
  computed: {
    filterXY() {
      return type => this[`${type}List`].filter(item => item.label.indexOf(this[`search${type}`]) > -1);
    }
  },
  created() {
    this.xyList = xyList;
    this.urlParams = this.$route.params;
    if (this.urlParams && this.urlParams.projectId !== undefined) {
      this.queryOnlineSets({
        projectId: parseFloat(this.urlParams.projectId),
        directoryId: parseFloat(this.urlParams.parentId)
      });
    } else if (this.urlParams && this.urlParams.dataSetId !== undefined) { // 自助取数
      this.dataAnalyName = this.urlParams.dataSetName;
      this.queryXyOnline(this.urlParams);
    }
  },
  methods: {
    editdataset() {
      const {
        id, type, projectId, directoryId
      } = this.dataset;
      getDataSetInfo({
        id,
        type
      }).then((res) => {
        this.$router.push({
          name: type === 'es' ? 'createSpaceES' : 'createSpaceSQL',
          params: {
            res,
            look: null,
            panel: true,
            type: res.dataSet.dataSourceType,
            parentId: directoryId,
            projectId,
            breadList: []
          }
        });
      });
    },
    setDataSet(res) {
      this.datasetList = res;
      const { dataSetType, dataSetId } = this.data.params;
      if (dataSetType) {
        for (let i = 0, j = this.datasetList.length; i < j; i += 1) {
          const { id, type, name } = this.datasetList[i];
          if (dataSetId === id && dataSetType === type) {
            this.dataset = this.datasetList[i];
            this.setChange({ id, type, name });
            return;
          }
        }
      } else if (this.datasetList.length > 0) { // 新建默认选中第一个
        const { id, type, name } = this.datasetList[0];
        [this.dataset] = this.datasetList;
        this.setChange({ id, type, name });
      }
    },
    queryOnlineSets(params) {
      if (this.$store.state.panel.datasetList) { // 有缓存用缓存
        this.setDataSet(this.$store.state.panel.datasetList);
      } else {
        queryOnline(params).then((res) => {
          this.$store.state.panel.datasetList = res;
          this.setDataSet(res);
        });
      }
    },
    queryXyOnline(params) {
      queryXyOnline(params).then((res) => {
        this.xList = [];
        this.yList = [];
        res.forEach((obj) => {
          obj.dataSetName = params.dataSetName;
          if (obj.type === 'dimension') { // 维度
            this.xList.push(obj);
          } else { // 度量
            this.yList.push(obj);
          }
        });
      });
    },
    setChange(val) {
      this.queryXyOnline({
        dataSetId: val.id,
        dataSetType: val.type,
        dataSetName: val.name
      });
    },
    dragstart(ev, data) {
      ev.dataTransfer.setData('data', JSON.stringify(data));
    },
  }
};
</script>
<style scoped lang="less">
.container {
  height: 100%;
  display: flex;
  padding-top: 5px;
  border-top: 1px solid #3a4158;
  .left {
    padding-right: 10px;
    flex: 1;
  }
  .right {
    border-left: 1px solid #3a4158;
    padding-left: 10px;
    flex: 1;
    .dataset {
      margin-top: 5px;
      height: calc(50% - 19px);
      .title {
        display: flex;
        align-items: center;
        border-bottom: 1px solid #3a4158;
        padding: 4px 0;
        > i {
          color: #61a9f8;
        }
        span {
          font-weight: bolder;
          font-size: 13px;
          margin: 0 5px;
        }
        .el-input {
          flex: 1;
          /deep/ .el-input__inner {
            padding-left: 8px;
            line-height: 22px;
            height: 22px;
          }
          /deep/ .el-input__icon {
            line-height: 22px;
          }
        }
      }
      .data-container {
        height: calc(100% - 32px);
        overflow: auto;
        .list-container {
          list-style: none;
          margin: 0;
          padding: 0 0 20px 15px;
          li {
            cursor: pointer;
            padding: 5px 0 5px 5px;
            i {
              font-size: 15px;
              color: #61a9f8;
            }
            span {
              margin-left: 10px;
              font-size: 12px;
              font-weight: bolder;
              &.double {
                margin-left: -1px;
              }
            }
          }
        }
      }
    }
  }
}
</style>
