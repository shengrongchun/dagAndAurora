<template>
  <div class="tab-container">
    <div class="header">
      <div class="title">{{ data.styles.label.text }}</div>
      <div
        class="rightSelect"
        v-if="showSwitch">
        <el-popover
          placement="bottom"
          width="350"
          v-model="show"
          popper-class="compSwitch"
          :visible-arrow="false"
          trigger="click">
          <compSwitch :data="data"/>
          <span
            class="title"
            slot="reference">更改图表类型<i :class="'el-icon-caret-'+(show?'bottom':'top')" /></span>
        </el-popover>
      </div>
    </div>
    <el-tabs type="border-card">
      <slot />
    </el-tabs>
  </div>
</template>
<script>
import compSwitch from './compSwitch';
import { compCList } from '../../../store/modules/options';

export default {
  components: {
    compSwitch
  },
  props: {
    data: {
      type: Object,
      default() {
        return {};
      }
    }
  },
  data() {
    return {
      show: false
    };
  },
  computed: {
    showSwitch() {
      for (let i = 0, j = compCList.length; i < j; i += 1) {
        if (compCList[i].icon === this.data.type
        && !this.$store.state.panel.searchComps[this.data.type]) {
          return true;
        }
      }
      return false;
    }
  },
};
</script>
<style scoped lang="less">
.tab-container {
  height: 100%;
  color: #ccc;
  .header {
    display: flex;
    justify-content: space-between;
    background: #282f46;
    .rightSelect{
      .title {
        cursor: pointer;
        font-size: 13px;
        border: none;
      }
    }
    .title {
      font-size: 14px;
      font-weight: bolder;
      padding: 0 10px;
      height: 30px;
      line-height: 30px;
      border-left: 1px solid #21273a;
    }
  }
  .el-tabs {
    height: calc(100% - 30px);
    background: #21273a;
    border: none;
    box-shadow: none;
    /deep/ .el-tabs__header {
      border: none;
      background: #282f46;
      .el-tabs__item {
        height: 35px;
        line-height: 35px;
        border: none;
        &.is-active {
          background: #21273a;
          color: #fff;
        }
        &:hover {
          color: #fff;
        }
      }
    }
    /deep/ .el-tabs__content {
      height: calc(100% - 34px);
      padding: 10px;
      overflow: auto;
      .el-tab-pane {
        height: 100%;
      }
    }
    /deep/ .el-form {
      .el-form-item {
        margin-bottom: 10px;
      }
      .el-form-item__label {
        color: #ccc;
        font-weight: bolder;
        font-size: 13px;
      }
    }
    /deep/ .el-switch {
      height: 18px;
      line-height: 18px;
      .el-switch__core {
        width: 35px !important;
        height: 18px;
        &:after {
          width: 14px;
          height: 14px;
        }
      }
    }
    /deep/ .el-input {
      .el-input__inner {
        border: none;
        border-radius: 2px;
        font-weight: bolder;
        color: #fff;
        background: #282f46;
      }
    }
    /deep/ .el-select {
      width: 100%;
      .el-select__tags {
        max-width: 100%;
        .el-tag {
          color: #5A6276;
        }
      }
      .el-select-dropdown {
        background: #282f46;
        border-color: #282f46;
        box-shadow: 0 2px 12px 0 #141721;
        .el-select-dropdown__item {
          color: #bbb;
          font-weight: bolder;
          &.hover {
            color: #bbb;
            background: #282f46;
          }
          &:hover,&.selected {
            color: #61a9f8;
            background: #282f46;
          }
        }
      }
      .popper__arrow {
        border-bottom-color: #282f46;
        &::after {
          border-bottom-color: #282f46;
        }
      }
    }
  }
}
</style>
