const ySetTypeList = [
  { label: '原始', value: null },
  { label: '计数', value: 'count' },
  { label: '求和', value: 'sum' },
  { label: '去重', value: 'count_distinct' },
  { label: '最大值', value: 'max' },
  { label: '最小值', value: 'min' },
  { label: '平均值', value: 'avg' },
];
const ySetTypeMap = {
  sum: '(求和) ',
  count: '(计数) ',
  count_distinct: '(去重) ',
  max: '(最大值) ',
  min: '(最小值) ',
  avg: '(平均值) ',
  null: '',
};
const xyList = [{
  name: '维度',
  type: 'x',
  icon: 'icon-weidu'
}, {
  name: '度量',
  type: 'y',
  icon: 'icon-duliang'
}];
const filterStringList = [{
  name: '精确匹配',
  value: '='
}, {
  name: '包含',
  value: 'like'
}, {
  name: '不包含',
  value: 'not like'
}, {
  name: '开头是',
  value: 'start'
}, {
  name: '不匹配',
  value: '!='
}, {
  name: '为空',
  value: 'is null'
}, {
  name: '不为空',
  value: 'is not null'
}, {
  name: '正则匹配',
  value: 'regex'
}];
const filterNumList = [{
  name: '大于',
  value: '>'
}, {
  name: '小于',
  value: '<'
}, {
  name: '大于等于',
  value: '>='
}, {
  name: '小于等于',
  value: '<='
}, {
  name: '等于',
  value: '='
}, {
  name: '不等于',
  value: '!='
}];
const timeList = [{
  name: '分',
  value: 'minute'
}, {
  name: '时',
  value: 'hour'
}, {
  name: '日',
  value: 'day'
}, {
  name: '周',
  value: 'week'
}, {
  name: '月',
  value: 'month'
}, {
  name: '年',
  value: 'year'
}];
export {
  xyList,
  ySetTypeList,
  ySetTypeMap,
  filterNumList,
  filterStringList,
  timeList
};
