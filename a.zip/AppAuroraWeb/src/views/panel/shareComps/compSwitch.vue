<template>
  <div class="compSwitch">
    <div
      class="compItem"
      :key="item.name"
      v-for="item in compList">
      <template v-if="!$store.state.panel.searchComps[item.icon]">
        <div class="title">{{ item.name }}</div>
        <div class="panel">
          <div
            :class="{'active':active===item.icon}"
            @click="clickItem(item)"
            class="panelItem"><i :class="'iconfont icon-'+item.icon"/></div>
          <template v-if="item.children">
            <div
              v-for="obj in item.children"
              :key="obj.icon"
              @click="clickItem(obj)"
              :class="{'active':active===obj.icon}"
              class="panelItem"><i :class="'iconfont icon-'+obj.icon"/></div>
          </template>
        </div>
      </template>
    </div>
  </div>
</template>
<script>
import { compCList } from '../../../store/modules/options';

export default {
  props: {
    data: {
      type: Object,
      default() {
        return {};
      }
    }
  },
  data() {
    return {
      active: this.data.type
    };
  },
  created() {
    this.compList = compCList;
  },
  methods: {
    clickItem(item) {
      this.active = item.icon;
      // 切换组件操作
      this.$store.commit('switchComp', this.active);
    }
  },
};
</script>
<style scoped lang="less">
.compSwitch {
  width: 100%;
  max-height: 600px;
  overflow: auto;
  background: #21273a;
  padding: 20px;
  display: flex;
  flex-direction: column;
  box-shadow: 0 2px 12px 0 rgba(0,0,0);
  .title {
    font-size: 13px;
    color: #ddd;
    font-weight: bolder;
    border-bottom: 1px solid #293148;
    padding-bottom: 10px;;
  }
  .panel {
    display: flex;
    .panelItem {
      &.active {
       border: 1px solid rgb(134,203,157);
      }
      cursor: pointer;
      background: rgb(60,66,86);
      padding: 0px 12px;
      margin: 20px;
      height: 45px;
      line-height: 45px;
      .iconfont {
        font-size: 35px;
        color: rgb(97,169,248);
      }
    }
  }
}
</style>
