<template>
  <el-dialog
    :visible.sync="visible"
    :close-on-click-modal="false"
    :before-close="()=> {$emit('close')}"
    :title="title"
    width="40%"
    append-to-body>
    <el-form
      ref="form"
      :model="form"
      :rules="rules"
      label-width="100px">
      <template v-if="type==='y'">
        <template v-if="form.type==='custom'">
          <el-form-item
            label="度量名称"
            prop="label">
            <el-input
              v-model="form.label"
              placeholder="请输入度量名称"/>
          </el-form-item>
          <el-form-item
            label="自定义脚本"
            prop="expression">
            <el-input
              v-model="form.expression"
              placeholder="请输入自定义脚本"
              type="textarea"/>
          </el-form-item>
        </template>
        <template v-else>
          <el-form-item
            label="字段名称"
            prop="name">
            {{ setLabel }}
          </el-form-item>
          <el-form-item
            label="计算方式"
            prop="aggregate">
            <el-select v-model="form.aggregate">
              <el-option
                :key="idx"
                v-for="(objs,idx) in ySetTypeList"
                :value="objs.value"
                :label="objs.label"/>
            </el-select>
          </el-form-item>
          <el-form-item
            prop="formatNum"
            label="格式设置">
            <el-select v-model="form.formatType">
              <el-option
                value="number"
                label="数值"/>
              <el-option
                value="percent"
                label="百分比"/>
            </el-select>
            <span :style="{'margin-left':'10px'}">小数位数</span>
            <el-input
              :style="{'width':'100px','margin-left':'10px'}"
              :min="0"
              :max="10"
              v-model="form.formatNum"
              type="number"/>
          </el-form-item>
        </template>
        <el-form-item label="">
          <el-checkbox v-model="form.formatThousand">显示千分符</el-checkbox>
        </el-form-item>
      </template>
      <template v-if="type==='w'">
        <el-form-item
          label="字段中文名称"
          prop="name">
          {{ setLabel }}
        </el-form-item>
        <el-form-item
          v-if="form.dmType==='metric'"
          label="计算方式"
          prop="aggregate">
          <el-select v-model="form.aggregate">
            <el-option
              :key="idx"
              v-for="(objs,idx) in ySetTypeList"
              :value="objs.value"
              :label="objs.label"/>
          </el-select>
        </el-form-item>
        <el-form-item
          label="字段英文标识"
          prop="column">
          {{ form.column }}
        </el-form-item>
        <el-form-item label="过滤类型">
          <el-radio-group v-model="form.type">
            <template v-if="form.dataType==='time'">
              <el-radio-button
                label="absolute">绝对时间</el-radio-button>
              <el-radio-button
                label="relative">相对时间</el-radio-button>
            </template>
            <template v-else>
              <el-radio-button
                label="condition">条件</el-radio-button>
              <el-radio-button
                label="enum">枚举</el-radio-button>
            </template>
            <el-radio-button
              label="custom">自定义</el-radio-button>
          </el-radio-group>
        </el-form-item>
        <template v-if="form.type==='condition' || form.type==='absolute'|| form.type==='relative'">
          <el-form-item
            label="">
            <el-radio
              v-model="form.tabs[form.type].logical"
              label="and">且</el-radio>
            <el-radio
              v-model="form.tabs[form.type].logical"
              label="or">或</el-radio>
          </el-form-item>
          <el-form-item
            label=""
            prop="name">
            <template v-if="form.tabs[form.type].conditions.length===0">
              <i
                :style="{'color':'#409EFF','font-size':'20px',
                         'vertical-align':'bottom',
                         'cursor':'pointer'}"
                @click="addFilter"
                class="iconfont icon-plus"/>
              <span> 添加</span>
            </template>
            <propertyChart
              :style="{'margin-left':'-60px'}"
              :dataList="form.tabs[form.type].conditions"
              :tag="form.tabs[form.type].logical==='and'?'且':'或'">
              <template slot-scope="props">
                <el-select
                  v-model="props.item.operator"
                  :style="{'width':'100px'}">
                  <el-option
                    v-for="(item,idx) in getOpeList"
                    :key="idx"
                    :label="item.name"
                    :value="item.value"/>
                </el-select>
                <template v-if="form.type==='absolute'">
                  <el-date-picker
                    :style="{'width':'170px','margin':'0 10px'}"
                    v-model="props.item.value"
                    type="datetime"
                    format="yyyy-MM-dd HH:mm:ss"
                    value-format="yyyy-MM-dd HH:mm:ss"
                    placeholder="请选择日期时间"/>
                </template>
                <template v-else-if="form.type==='relative'">
                  <el-select
                    v-model="props.item.direction"
                    :style="{'width':'85px','margin':'0 10px'}">
                    <el-option
                      value="prev"
                      label="当日前"/>
                    <el-option
                      value="next"
                      label="当日后"/>
                  </el-select>
                  <el-input
                    type="number"
                    :min="0"
                    :style="{'width':'70px'}"
                    v-model="props.item.value"/>
                  <el-select
                    v-model="props.item.unit"
                    :style="{'width':'60px','margin':'0 10px'}">
                    <el-option
                      v-for="(time,ind) in timeList"
                      :key="ind"
                      :value="time.value"
                      :label="time.name"/>
                  </el-select>
                </template>
                <template v-else>
                  <el-input
                    :type="form.dataType === 'string'?'default':'number'"
                    v-model="props.item.value"
                    :style="{'width':'100px','margin':'0 10px'}"/>
                </template>
                <i
                  @click="()=> {form.tabs[form.type].conditions.splice(props.index,1)}"
                  class="iconfont icon-shanchu-copy-copy"
                  :style="{'color':'#409EFF','margin':'0 5px',
                           'cursor':'pointer','vertical-align':'bottom'}"/>
                <i
                  v-if="props.length===props.index+1"
                  :style="{'color':'#409EFF','margin':'0 5px',
                           'cursor':'pointer','vertical-align':'middle'}"
                  @click="addFilter"
                  class="iconfont icon-plus"/>
              </template>
            </propertyChart>
          </el-form-item>
        </template>
        <template v-if="form.type==='enum'">
          <el-form-item
            label="枚举值"
            required>
            <el-select
              :style="{width: '100%'}"
              v-model="form.tabs[form.type].items"
              multiple
              filterable
              allow-create
              default-first-option
              no-data-text="请输入选择添加"
              placeholder="请输入枚举值">
              <el-option
                v-for="item in []"
                :key="item.value"
                :label="item.label"
                :value="item.value"/>
            </el-select>
          </el-form-item>
        </template>
        <template v-if="form.type==='custom'">
          <el-form-item
            label="自定义sql"
            required>
            <el-input
              type="textarea"
              v-model="form.tabs[form.type].expression"/>
          </el-form-item>
        </template>
      </template>
    </el-form>
    <span
      slot="footer"
      class="dialog-footer">
      <el-button @click="$emit('close')">取消</el-button>
      <el-button
        type="primary"
        @click="type==='w'?wsave():save()">保存</el-button>
    </span>
  </el-dialog>
</template>
<script>
import {
  ySetTypeList, ySetTypeMap, filterNumList, filterStringList, timeList
} from '../options';
import deepCopy from '../../../../utils/deepCopy';
import propertyChart from './propertyChart';

export default {
  components: {
    propertyChart
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
    type: {
      type: String,
      default: 'y'
    },
    obj: {
      type: Object,
      default() {
        return {};
      }
    }
  },
  data() {
    return {
      form: {},
    };
  },
  computed: {
    getOpeList() {
      if (this.form.dataType === 'string') {
        return filterStringList;
      }
      return filterNumList;
    },
    title() {
      if (this.type === 'y') {
        return this.form.type === 'simple' ? '度量' : '度量自定义';
      }
      return '过滤';
    },
    setLabel() {
      const [a, b] = this.form.label.split(' ');
      return ySetTypeMap[this.form.aggregate] + (b || a);
    }
  },
  created() {
    this.rules = {
      label: [
        { required: true, message: '请输入度量名称', trigger: 'change' }
      ],
      expression: [
        { required: true, message: '请输入自定义sql表达式', trigger: 'change' }
      ],
      formatNum: [
        { required: true, message: '请输入小数位数', trigger: 'change' }
      ]
    };
    this.timeList = timeList;
    this.ySetTypeList = ySetTypeList;
    this.form = deepCopy(this.obj);
    if (this.type === 'w') { // 过滤
      this.wDataSet(true);
    }
  },
  methods: {
    wDataSet(mask) {
      const {
        label, column, dataType, dmType, type, expression, items,
        conditions, logical, tabs, aggregate, index
      } = this.form;
      const realForm = {
        label, column, dataType, dmType, type, aggregate, index
      };
      if (mask) {
        realForm.tabs = {
          custom: {
            expression: null, // 自定义的表达式
          },
          enum: {
            items: [], // 枚举类型的数组值
          },
          condition: {
            logical: 'or', // and 且 or 或
            conditions: [], // {operator,value}
          },
          absolute: {
            logical: 'or', // and 且 or 或
            conditions: [], // {operator,value}
          },
          relative: {
            logical: 'or', // and 且 or 或
            conditions: [], // {operator,direction,unit,value}
          }
        };
        //
        if (type === 'custom') {
          realForm.tabs[type] = { expression };
        } else if (type === 'enum') {
          realForm.tabs[type] = { items: items || [] };
        } else {
          realForm.tabs[type].logical = logical || 'or';
          realForm.tabs[type].conditions = conditions || [];
        }
      } else {
        Object.assign(realForm, tabs[type]);
      }
      //
      this.form = realForm;
    },
    addFilter() {
      const obj = {
        operator: '=',
        value: null
      };
      if (this.form.type === 'absolute') {
        obj.value = '';
      } else if (this.form.type === 'relative') {
        obj.direction = 'prev';
        obj.unit = 'day';// minute hour day week month year
      }
      const list = this.form.tabs[this.form.type].conditions;
      // if (list.length > 1) {
      //   this.$message({ type: 'warning', message: '最多添加两个' });
      //   return;
      // }
      list.push(obj);
    },
    save() {
      this.$refs.form.validate((valid) => {
        if (valid) {
          if (this.type === 'y' && this.form.type === 'simple') {
            this.form.label = this.setLabel;
          }
          this.$emit('save', this.form);
          this.$emit('close');
          return true;
        }
        return false;
      });
    },
    wsave() {
      const val = this.form.tabs[this.form.type];
      if (this.form.type === 'custom' && !val.expression) {
        this.$message({ type: 'warning', message: '请输入自定义表达式' });
        return;
      }
      if (this.form.type === 'enum' && val.items.length === 0) {
        this.$message({ type: 'warning', message: '请输入枚举值' });
        return;
      }
      if (this.form.type !== 'custom' && this.form.type !== 'enum') {
        // if (val.conditions.length === 0) {
        //   this.$message({ type: 'warning', message: '请添加条件值' });
        //   return;
        // }
        //
        for (let i = 0, j = val.conditions.length; i < j; i += 1) {
          if (!val.conditions[i].value) {
            this.$message({ type: 'warning', message: '条件有未填项' });
            return;
          }
        }
      }
      //
      this.wDataSet();
      this.$emit('save', this.form);
      this.$emit('close');
    }
  }
};
</script>
