<template>
  <div class="select">
    <span class="name">{{ data.styles.label.text }}</span>
    <!-- <el-popover
      v-if="isMetric"
      placement="bottom"
      trigger="click">
      <div class="content">
        <template v-if="form.valList.length===0">
          <i
            :style="{'color':'#409EFF','font-size':'20px','vertical-align':'middle','cursor':'pointer'}"
            @click="addFilter"
            class="iconfont icon-plus"/>
            <span> 添加</span>
        </template>
        <template v-else>
          <el-radio
            v-model="form.logical"
            label="and">且</el-radio>
          <el-radio
            v-model="form.logical"
            label="or">或</el-radio>
        </template>
        <propertyChart
          :style="{'margin-top':'10px'}"
          :dataList="form.valList"
          :tag="form.logical==='and'?'且':'或'">
          <template slot-scope="props">
            <el-select
              v-model="props.item.operate"
              placeholder="操作符"
              :style="{'width':'60px','margin-right':'10px'}">
              <el-option
                v-for="(item,idx) in getOpeList"
                :key="idx"
                :label="item"
                :value="item"/>
            </el-select>
            <el-select
              v-loading="loading"
              filterable
              allow-create
              v-model="props.item.value"
              placeholder="选择值">
              <el-option
                v-for="(item,idx) in options"
                :key="item.value+idx"
                :label="item.label"
                :value="item.value"/>
            </el-select>
            <i
              @click="()=> {form.valList.splice(props.index,1)}"
              class="iconfont icon-shanchu-copy-copy"
              :style="{'color':'#409EFF','margin':'0 10px',
                        'cursor':'pointer','vertical-align':'middle'}"/>
            <i
              v-if="props.length===props.index+1"
              :style="{'color':'#409EFF',
                        'cursor':'pointer','vertical-align':'middle'}"
              @click="addFilter"
              class="iconfont icon-plus"/>
          </template>
        </propertyChart>
      </div>
      <el-input
        placeholder="请点击选择"
        readonly
        slot="reference"
        v-model="selectVal" />
    </el-popover> -->
    <el-select
      clearable
      v-loading="loading"
      :key="data.styles.multiple"
      v-model="data.styles.value"
      :multiple="data.styles.multiple"
      placeholder="请选择">
      <el-option
        v-for="(item,idx) in options"
        :key="item.value+idx"
        :label="item.label"
        :value="item.value"/>
    </el-select>
    <slot />
  </div>
</template>
<script>
import { queryChartData } from '../../../../api/panel';
import propertyChart from '../../shareComps/compDialog/propertyChart';

const getOpeList = ['>', '<', '>=', '<=', '!=', '='];

export default {
  name: 'SelectComp',
  components: {
    propertyChart
  },
  props: {
    data: {
      type: Object,
      default() {
        return {};
      }
    }
  },
  data() {
    return {
      loading: false,
      selectList: [],
      selectVal: '> 20 且 < 10',
      form: {
        valList: [],
        logical: 'and'
      }
    };
  },
  computed: {
    isMetric() {
      const { columnName } = this.data.styles;
      return columnName && columnName.dmType === 'metric';
    },
    options() {
      const { columnName, columnVal } = this.data.styles;
      const optionList = [];
      this.selectList.forEach((obj) => {
        optionList.push({
          label: obj[columnName.column],
          value: obj[columnVal.column]
        });
      });
      //
      return optionList;
    }
  },
  watch: {// 这里的watch顺序很重要，先定义的先执行
    'data.styles.map': {
      handler() {
        this.noMapWatch = true;
      },
      deep: true
    },
    '$store.state.panel.compList': {// 全局监听各个组件的变化 重新设置styles.map
      handler(list) {
        if (this.noMapWatch || !this.data.styles.columnVal) {
          delete this.noMapWatch;
          return;
        }
        this.setMap(list);
      },
      deep: true
    },
  },
  created() {
    this.getOpeList = getOpeList;
    // 更新按钮点击后触发这里的方法
    this.preView = this.$store.state.panel.preView;
    this.$store._vm.$on(`${this.data.i}update${this.preView}`, () => { // 请求数据 更新
      this.queryChartData();
    });
    // 初始化
    this.init();
    this.noMapWatch = true;
  },
  destroyed() { // 销毁监听方法
    this.$store._vm.$off(`${this.data.i}update${this.preView}`);
  },
  methods: {
    init() {
      if (Object.keys(this.data.params).length > 0) { // 初始化编辑请求数据
        this.queryChartData();
      }
    },
    queryChartData() {
      this.loading = true;
      const { params, type, i } = this.data;
      const { id, state } = this.$route.params;
      queryChartData({
        params,
        extra: this.extra,
        compQuery: {
          compId: i,
          dashBoardId: id === 'create' ? null : id,
          dashBoardStage: state === 'online' ? 3 : null
        }
      }, type).then((res) => {
        this.selectList = res.result || [];
      }).finally(() => {
        this.loading = false;
      });
    },
    // 设置map方法
    setMap(list) {
      //
      const sameList = [];// 同源列表
      const diffList = [];// 非同源列表
      this.getSameDiffList(list, sameList, diffList);
      const map = {};
      sameList.forEach((item) => { // 把所有同源并且有相同字段的默认选中
        const active = this.getActiveObj(item, this.data.styles.columnVal);
        if (this.data.styles.map[item.i]) {
          map[item.i] = this.data.styles.map[item.i];
        } else if (active) {
          map[item.i] = active;
        }
      });
      //
      diffList.forEach((item) => { // 把所有非同源保留原来的选中
        const id = item.i;
        if (this.data.styles.map[id]) { // 有
          map[id] = this.data.styles.map[id];
        }
      });
      this.data.styles.map = map;
    },
    getSameDiffList(list, sameList, diffList) { // 获取同源非同源列表
      list.forEach((item) => {
        if (item.type !== 'Search' && item.type !== 'Tab') {
          const { dataSetId, dataSetType } = item.params;
          if (dataSetId && dataSetType && this.data.params.dataSetId
           && this.data.params.dataSetType) {
            if (dataSetId === this.data.params.dataSetId
            && dataSetType === this.data.params.dataSetType) { // 同源
              sameList.push(item);
            } else {
              diffList.push(item);
            }
          }
        } else if (item.type === 'Tab') {
          item.styles.tabList.forEach((tab) => {
            this.getSameDiffList(tab.compList || [], sameList, diffList);
          });
        }
      });
    },
    //
    getActiveObj(item, columnVal) {
      const { column } = columnVal;
      const list = this.getList(item);
      for (let i = 0, j = list.length; i < j; i += 1) {
        if (list[i].column === column) {
          return list[i];
        }
      }
      return null;
    },
    // 每个组件的映射列表的获取
    getList(item) {
      if (item.params.rows) {
        return item.params.rows.concat(item.params.columns);
      }
      if (item.params.dimensions) {
        return item.params.dimensions.concat(item.params.metrics);
      }
      return [];
    },
    addFilter() {
      this.form.valList.push({
        operate: '=',
        value: this.options[0] ? this.options[0].label : 1
      });
    },
  }
};
</script>
<style scoped lang="less">
.select {
  border: none !important;
  display: flex;
  align-items: center;
  .name {
    margin: 0 10px;
  }
  .el-input {
    flex: 1;
    margin-right: 10px;
  }
}
</style>
