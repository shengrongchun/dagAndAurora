<template>
  <Chart
    :data="data"
    @apply="applyChart">
    <slot />
  </Chart>
</template>
<script>
import Chart from '../../shareComps/chartComIndex';
import { thousandsFmt } from '../../../../utils/index';

export default {
  name: 'PieComp',
  components: {
    Chart
  },
  props: {
    data: {
      type: Object,
      default() {
        return {};
      }
    }
  },
  methods: {
    applyChart({ res, chartData, myChart }) {
      this.exportData = res;
      const list = res.result;
      this.myChart = myChart;
      const { styles, params } = chartData;
      const { dimensions, metrics } = params;
      const legendData = [];
      const data = [];
      list.forEach((obj) => {
        const name = obj[dimensions[0].column];
        const value = obj[metrics[0].aggregate ? `${metrics[0].aggregate.toUpperCase()}(${metrics[0].column})` : (metrics[0].column || metrics[0].expression)];
        legendData.push(name);
        data.push({
          name, value
        });
      });
      styles.tooltip.formatter = (param) => {
        const {
          seriesName, name, value, marker, percent
        } = param;
        const { formatThousand, formatType, formatNum } = chartData.params.metrics[0];
        let formatVal = (formatType === 'percent' ? value * 100 : value).toFixed(formatNum);
        formatVal = formatThousand ? thousandsFmt(formatVal) : formatVal;
        formatVal = formatType === 'percent' ? (`${formatVal}%`) : formatVal;
        //
        return `${seriesName}<br/>${marker + name}: ${formatVal} ${percent}%`;
      };
      styles.legend.data = legendData;
      styles.series[0].name = styles.label.text;
      styles.series[0].data = data;
      styles.series[0].label = Object.assign(styles.labelNormal, {
        formatter: (param) => {
          const { value, percent, name } = param;
          const { formatThousand, formatType, formatNum } = chartData.params.metrics[0];
          let formatVal = (formatType === 'percent' ? value * 100 : value).toFixed(formatNum);
          formatVal = formatThousand ? thousandsFmt(formatVal) : formatVal;
          formatVal = formatType === 'percent' ? (`${formatVal}%`) : formatVal;
          return `${name} ${formatVal} ${percent}%`;
        }
      });
      this.myChart.resize();
      this.myChart.setOption(styles, true);// false为合并之前的数据
    },
    resize() {
      if (this.myChart) {
        this.myChart.resize();
      }
    }
  }
};
</script>
