<template>
  <div class="config">
    <tabContainer
      :data="data">
      <el-tab-pane label="数据">
        <dataContainer :data="data">
          <chartContainer
            :data="data"/>
        </dataContainer>
      </el-tab-pane>
      <el-tab-pane label="显示">
        <el-form
          label-position="right"
          label-width="130px">
          <div class="title">基础信息</div>
          <el-form
            label-width="50px">
            <template>
              <el-form-item label="标题">
                <el-input
                  v-model="styles.label.text"
                  placeholder="请输入标题"/>
              </el-form-item>
              <el-form-item label="备注">
                <el-input
                  v-model="styles.label.subText"
                  placeholder="请输入备注"/>
              </el-form-item>
            </template>
          </el-form>
          <div class="title">图表样式</div>
          <el-form-item label="显示图表图例">
            <el-switch
              v-model="styles.legend.show"
              active-color="#409EFF"
              inactive-color="#eee"/>
            <template v-if="styles.legend.show">
              <label class="position">位置</label>
              <el-select
                v-model="styles.legend.top"
                :style="{width:'68px'}"
                :popper-append-to-body="false">
                <el-option
                  label="上"
                  value="top"/>
                <el-option
                  label="中"
                  value="middle"/>
                <el-option
                  label="下"
                  value="bottom"/>
              </el-select>
            </template>
          </el-form-item>
          <!-- <el-form-item label="图例布局方向">
            <el-radio
              v-model="styles.legend.orient"
              label="horizontal">水平</el-radio>
            <el-radio
              v-model="styles.legend.orient"
              label="vertical">垂直</el-radio>
          </el-form-item> -->
          <!-- <el-form-item label="显示图表数据标签">
            <el-switch
              v-model="styles.labelNormal.show"
              active-color="#409EFF"
              inactive-color="#eee"/>
            <template v-if="styles.labelNormal.show">
              <label class="position">位置</label>
              <el-select
                v-model="styles.labelNormal.position"
                :style="{width:'68px'}"
                :popper-append-to-body="false">
                <el-option
                  label="外部"
                  value="outside"/>
                <el-option
                  label="内部"
                  value="inside"/>
                <el-option
                  label="中间"
                  value="center"/>
              </el-select>
            </template>
          </el-form-item> -->
        </el-form>
      </el-tab-pane>
    </tabContainer>
  </div>
</template>
<script>
import tabContainer from '../../shareComps/tabContainer';
import dataContainer from '../../shareComps/dataContainer';
import chartContainer from '../../shareComps/compDialog/chartContainer';

export default {
  name: 'PieConfig',
  components: {
    tabContainer,
    dataContainer,
    chartContainer,
  },
  props: {
    data: {
      type: Object,
      default() {
        return {};
      }
    }
  },
  data() {
    return {
      styles: this.data.styles
    };
  }
};
</script>
<style scoped lang="less">
.config {
  height: 100%;
  .el-form {
    /deep/ .title {
      font-size: 15px;
      font-weight: bolder;
      padding: 10px 0;
      margin-bottom: 10px;
      border-bottom: 1px solid #3a4158;
    }
  }
  /deep/ .position {
    font-size: 13px;
    font-weight: bolder;
    margin: 0 10px;
    vertical-align: bottom;
  }
}
</style>
