<template>
  <div
    class="label"
    v-loading="loading">
    <div
      v-if="label.length===1||label.length===3"
      class="center">
      <div class="title">{{ label[0].title }}</div>
      <span class="val">{{ label[0].value }}</span>
    </div>
    <div
      v-if="label.length===2||label.length===3"
      class="container">
      <div class="left">
        <div class="title">{{ label[label.length-2].title }}</div>
        <span
          class="val"
          :style="colors(label[label.length-2].value)">{{ label[label.length-2].value }}</span>
      </div>
      <div class="right">
        <div class="title">{{ label[label.length-1].title }}</div>
        <span
          class="val"
          :style="colors(label[label.length-1].value)">{{ label[label.length-1].value }}</span>
      </div>
    </div>
    <slot />
  </div>
</template>
<script>
import { queryChartData } from '../../../../api/panel';
import { thousandsFmt } from '../../../../utils/index';

export default {
  name: 'LabelComp',
  components: {
  },
  props: {
    data: {
      type: Object,
      default() {
        return {};
      }
    }
  },
  data() {
    return {
      loading: false,
      label: [],
      extra: []
    };
  },
  created() {
    this.preView = this.$store.state.panel.preView;
    this.$store._vm.$on(`${this.data.i}update${this.preView}`, (data) => { // 请求数据 更新
      this.queryChartData(data);
    });
    this.$store._vm.$on(`${this.data.i}search${this.preView}`, (data) => { // 请求数据 查询
      this.searchInit = true;// 有搜索组件请求，默认的初始化不执行请求操作
      this.extra = data;
      this.queryChartData(this.data);
    });
  },
  destroyed() {
    this.$store._vm.$off(`${this.data.i}update${this.preView}`);
    this.$store._vm.$off(`${this.data.i}search${this.preView}`);
  },
  mounted() {
    if (!this.searchInit) {
      this.init();
    }
  },
  methods: {
    init() {
      if (Object.keys(this.data.params).length > 0) { // 初始化编辑请求数据
        this.queryChartData(this.data);
      }
    },
    applyChart(list, data) {
      this.label = [];
      const { metrics } = data.params;
      const [item] = list;
      if (item) {
        metrics.forEach((obj) => {
          const value = item[obj.aggregate ? `${obj.aggregate.toUpperCase()}(${obj.column})` : (obj.column || obj.expression)];
          this.label.push({
            title: obj.label,
            value: obj.formatThousand ? thousandsFmt(value) : value,
          });
        });
      }
    },
    queryChartData(data) {
      this.loading = true;
      const { params, type, i } = data;
      const { id, state } = this.$route.params;
      queryChartData({
        params,
        extra: this.extra,
        compQuery: {
          compId: i,
          dashBoardId: id === 'create' ? null : id,
          dashBoardStage: state === 'online' ? 3 : null
        }
      }, type).then((res) => {
        this.exportData = res;
        this.applyChart(res.result, data);
      }).finally(() => {
        this.loading = false;
      });
    },
    colors(value) {
      const val = `${value}`;
      if (val.indexOf('-') > -1) {
        return {
          color: 'red'
        };
      }
      return {
        color: '#2cda3b'
      };
    }
  }
};
</script>
<style scoped lang="less">
.label {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  .title {
    font-size: 13px;
    margin-bottom: 5px;
  }
  .center {
    text-align: center;
    margin-bottom: 15px;
    .val {
      font-size: 25px;
      font-weight: bolder;
    }
  }
  .container {
    display: flex;
    width: 100%;
    > div {
      text-align: center;
      .val {
        font-weight: bolder;
        font-size: 16px;
      }
    }
    .left {
      flex: 1;
    }
    .right {
      flex: 1;
    }
  }
}
</style>
