<template>
  <Chart
    :data="data"
    @apply="applyChart">
    <slot />
  </Chart>
</template>
<script>
import Chart from '../../shareComps/chartComIndex';
import { thousandsFmt } from '../../../../utils/index';

export default {
  name: 'BarComp',
  components: {
    Chart
  },
  props: {
    data: {
      type: Object,
      default() {
        return {};
      }
    }
  },
  methods: {
    applyChart({ res, chartData, myChart }) {
      this.exportData = res;
      const list = res.result;
      this.myChart = myChart;
      const { styles } = chartData;
      const {
        xAxis, yAxis, legend,
        labelNormal,
        barParams,
      } = styles;
      styles.tooltip.formatter = (paramList) => {
        const valList = [];
        paramList.forEach((params) => {
          const {
            seriesName, value, name, marker
          } = params;
          const { formatThousand, formatType, formatNum } = chartData.params.metrics.find(
            item => item.label === seriesName
          );
          //
          valList.push({
            seriesName, value, name, marker, formatThousand, formatType, formatNum
          });
        });
        //
        if (valList.length === 0) {
          return null;
        }
        let valString = `${valList[0].name}<br/>`;
        valList.forEach((obj) => {
          const {
            seriesName, value, marker, formatThousand, formatType, formatNum
          } = obj;
          let formatVal = (formatType === 'percent' ? value * 100 : value).toFixed(formatNum);
          formatVal = formatThousand ? thousandsFmt(formatVal) : formatVal;
          formatVal = formatType === 'percent' ? (`${formatVal}%`) : formatVal;
          valString += `${marker + seriesName}: ${formatVal}<br/>`;
        });
        return valString;
      };
      const { vertical, stack } = barParams;
      let xAxisName = null;
      let xAxisName2 = null;
      const seriesMap = {};
      const ylist = [];
      xAxis[0].select.forEach((item, idx) => {
        if (idx === 0) { // 设置X轴data
          xAxisName = item.column;
        } else {
          xAxisName2 = item.column;
        }
      });
      [0, 1].forEach((idx) => {
        yAxis[idx].select.forEach((item) => { // 左侧y
          ylist.push({
            yAxisIndex: idx,
            label: item.label,
            column: item.aggregate ? `${item.aggregate.toUpperCase()}(${item.column})` : (item.column || item.expression),
          });
        });
      });
      //
      xAxis[0].data = [];
      legend.data = [];
      const legendMap = {};
      styles.series = [];
      list.forEach((obj) => {
        // xAxis data
        if (obj[xAxisName] && !xAxis[0].data.includes(obj[xAxisName])) {
          xAxis[0].data.push(obj[xAxisName]);
        }
        seriesMap[obj[xAxisName]] = seriesMap[obj[xAxisName]] || {};
        const map = seriesMap[obj[xAxisName]];
        ylist.forEach((item) => {
          const label = (xAxisName2 ? (`${obj[xAxisName2]}-`) : '') + item.label;
          map[label] = obj[item.column];
          const legendData = {
            name: label,
            yAxisIndex: item.yAxisIndex
          };
          if (!legendMap[label]) {
            legendMap[label] = true;
            legend.data.push(legendData);
          }
        });
      });
      //
      legend.data.forEach((obj) => {
        const { name, yAxisIndex } = obj;
        const dataList = [];
        xAxis[0].data.forEach((label) => {
          dataList.push(seriesMap[label][name]);
        });
        const stylesObj = {
          name,
          type: 'bar',
          stack,
          label: {
            normal: Object.assign(labelNormal, {
              formatter: (params) => {
                const { seriesName, value } = params;
                const { formatThousand, formatType, formatNum } = chartData.params.metrics.find(
                  item => item.label === seriesName
                );
                let formatVal = (formatType === 'percent' ? value * 100 : value).toFixed(formatNum);
                formatVal = formatThousand ? thousandsFmt(formatVal) : formatVal;
                formatVal = formatType === 'percent' ? (`${formatVal}%`) : formatVal;
                return formatVal;
              }
            }),
          },
          data: dataList
        };
        if (vertical) { // 垂直
          stylesObj.yAxisIndex = yAxisIndex;
        } else { // 水平
          stylesObj.xAxisIndex = yAxisIndex;
        }
        styles.series.push(stylesObj);
      });
      //
      if (!vertical) { // 水平
        const xAxisTemp = styles.xAxis;
        styles.xAxis = yAxis;
        styles.yAxis = xAxisTemp;
      }
      this.myChart.resize();
      this.myChart.setOption(styles, true);// false为合并之前的数
    },
    resize() { // 供 dragContainer.vue调用
      if (this.myChart) {
        this.myChart.resize();
      }
    }
  }
};
</script>
