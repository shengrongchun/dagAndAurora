<template>
  <div class="config">
    <tabContainer :data="data">
      <el-tab-pane label="显示">
        <el-form
          label-width="80px">
          <el-form-item label="标题">
            <el-input
              v-model="styles.label.text"
              placeholder="请输入日期标题"/>
          </el-form-item>
          <!-- <el-form-item label="日期类型">
            <el-select
              v-model="styles.type"
              :popper-append-to-body="false">
              <el-option
                value="date"
                label="日期" />
              <el-option
                value="daterange"
                label="区间日期" />
              <el-option
                value="datetime"
                label="日期时间" />
              <el-option
                value="datetimerange"
                label="区间日期时间" />
            </el-select>
          </el-form-item> -->
          <el-form-item label="绝对时间">
            <!-- <span style="color:#409EFF">当前 </span> -->
            <el-select
              style="width:60px"
              v-model="styles.time.position"
              :popper-append-to-body="false">
              <el-option
                value="pre"
                label="前"/>
              <el-option
                value="next"
                label="后"/>
            </el-select>
            <el-input
              style="width:60px;margin:0 10px;"
              v-model="styles.time.value"
              type="number"
              :min="0" />
            <el-select
              style="width:60px"
              v-model="styles.time.unit"
              :popper-append-to-body="false">
              <el-option
                :value="60*60*24"
                label="天"/>
              <el-option
                :value="60*60*24*7"
                label="周"/>
              <el-option
                :value="60*60*24*30"
                label="月"/>
              <el-option
                :value="60*60*24*30*12"
                label="年"/>
            </el-select>
          </el-form-item>
        </el-form>
        <template>
          <ul class="axis">
            <li class="active">非同源关联</li>
          </ul>
          <div class="axis-container">
            <div
              class="compDate"
              :key="idx+item.i"
              v-for="(item,idx) in filterCompList">
              <el-checkbox
                @change="checkedChange(item.i)"
                :checked="styles.map[item.i]?true:false"
              >{{ item.styles.label.text }}</el-checkbox>
              <div
                v-if="styles.map[item.i]!==undefined"
                class="dataset-container">
                <div class="dataset">
                  <i class="iconfont icon-shujuji"/>
                  <span>{{ item.params.dataSetName }}</span>
                </div>
                <div class="dataset sub">
                  <i
                    v-if="styles.map[item.i]"
                    :class="'iconfont icon-'+styles.map[item.i].dataType"/>
                  <el-select
                    v-model="styles.map[item.i]"
                    :popper-append-to-body="false"
                    placeholder="请选择映射属性"
                    value-key="label">
                    <el-option
                      :key="index"
                      :value="ob"
                      :label="ob.label"
                      v-for="(ob,index) in getList(item)"/>
                  </el-select>
                </div>
              </div>
            </div>
          </div>
        </template>
      </el-tab-pane>
    </tabContainer>
  </div>
</template>
<script>
import tabContainer from '../../shareComps/tabContainer';

export default {
  name: 'DateConfig',
  components: {
    tabContainer,
  },
  props: {
    data: {
      type: Object,
      default() {
        return {};
      }
    }
  },
  data() {
    return {
      styles: this.data.styles
    };
  },
  computed: {
    filterCompList() {
      const list = this.$store.state.panel.compList;
      const diffList = [];
      this.getDiffList(list, diffList);
      return diffList;
    }
  },
  methods: {
    checkedChange(i) {
      if (this.styles.map[i] === undefined) {
        this.$set(this.styles.map, i, null);
      } else {
        this.$set(this.styles.map, i, undefined);
        delete this.styles.map[i];
      }
    },
    getList(item) {
      if (item.params.rows) {
        return item.params.rows.concat(item.params.columns);
      }
      if (item.params.dimensions) {
        return item.params.dimensions.concat(item.params.metrics);
      }
      return [];
    },
    // 获取非同源列表
    getDiffList(list, diffList) { // 获取非同源列表
      list.forEach((item) => {
        if (item.type !== 'Search' && item.type !== 'Tab') {
          const { dataSetId, dataSetType } = item.params;
          if (dataSetId && dataSetType) {
            diffList.push(item);
          }
        } else if (item.type === 'Tab') {
          item.styles.tabList.forEach((tab) => {
            this.getDiffList(tab.compList || [], diffList);
          });
        }
      });
    },
  }
};
</script>
<style scoped lang="less">
.config {
  height: 100%;
  .axis {
    margin: 7px 0 0 0;
    padding: 0;
    list-style: none;
    width: 100%;
    border: 1px solid #3a4158;
    display: flex;
    > li {
      &.active {
        color: #409EFF;
      }
      cursor: pointer;
      font-size: 13px;
      padding: 2px 0;
      text-align: center;
      flex: 1;
      display: inline-block;
      &:not(:last-child) {
        border-right: 1px solid #3a4158;
      }
    }
  }
  .axis-container {
    padding: 12px 0;
    .compDate {
      margin-bottom: 15px;
      .el-checkbox {
        color: #eee;
      }
      .dataset-container {
        padding: 10px 0 0 30px;
      }
      .dataset {
        font-size: 14px;
        font-weight: bolder;
        margin-bottom: 10px;
        &.sub {
          margin-left: 20px;
        }
        .el-select {
          width: 150px;
        }
        i {
          color: #61a9f8;
          margin-right: 5px;
        }
      }
    }
  }
}
</style>
