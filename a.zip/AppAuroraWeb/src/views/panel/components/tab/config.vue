<template>
  <div class="config">
    <tabContainer :data="data">
      <el-tab-pane label="显示">
        <el-form
          label-width="80px">
          <div class="title">基础信息</div>
          <template>
            <el-form-item label="标题">
              <el-input
                v-model="styles.label.text"
                placeholder="请输入标题"/>
            </el-form-item>
            <el-form-item label="备注">
              <el-input
                v-model="styles.label.subText"
                placeholder="请输入备注"/>
            </el-form-item>
          </template>
          <el-form-item label="Tab 位置">
            <el-select
              v-model="styles.tabPosition"
              :popper-append-to-body="false">
              <el-option value="left"/>
              <el-option value="right"/>
              <el-option value="top"/>
              <el-option value="bottom"/>
            </el-select>
          </el-form-item>
          <el-form-item label="Tab 标签">
            <div class="plus">
              <i
                class="iconfont icon-plus"
                @click="add"/>
              <span>添加</span>
            </div>
            <draggable :list="styles.tabList">
              <div
                class="list-item"
                v-for="(obj,idx) in styles.tabList"
                :key="obj.id">
                <el-input
                  v-model="obj.title"
                  placeholder="请输入tab标签"/>
                <i
                  class="iconfont icon-shanchu-copy-copy"
                  @click="styles.tabList.splice(idx,1)"/>
              </div>
            </draggable>
          </el-form-item>
        </el-form>
      </el-tab-pane>
    </tabContainer>
  </div>
</template>
<script>
import draggable from 'vuedraggable';
import tabContainer from '../../shareComps/tabContainer';

export default {
  name: 'TabConfig',
  components: {
    tabContainer,
    draggable
  },
  props: {
    data: {
      type: Object,
      default() {
        return {};
      }
    }
  },
  data() {
    return {
      styles: this.data.styles
    };
  },
  methods: {
    add() {
      this.styles.tabList.push({
        id: new Date().getTime(),
        title: null,
        compList: []
      });
    },
  }
};
</script>
<style scoped lang="less">
.config {
  height: 100%;
  .el-form {
    /deep/ .title {
      font-size: 15px;
      font-weight: bolder;
      padding: 10px 0;
      margin-bottom: 10px;
      border-bottom: 1px solid #3a4158;
    }
  }
  .apply {
    z-index: 100;
    position: fixed;
    right: 10px;
    bottom: 10px;
    .btn {
      font-size: 13px;
      font-weight: bolder;
      display: inline-block;
      color: #61a9f8;
      cursor: pointer;
      margin-left: 5px;
    }
  }
  .plus {
    > i {
      color: #61a9f8;
      margin-right: 5px;
      cursor: pointer;
    }
    > span {
      vertical-align: top;
      font-weight: bolder;
      font-size: 13px;
    }
  }
  .list-item {
    display: flex;
    margin-bottom: 10px;
    > i {
      margin-left: 5px;
      cursor: pointer;
      color: #61a9f8;
    }
  }
}
</style>
