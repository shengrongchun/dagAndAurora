<template>
  <div
    v-loading="loading"
    class="tableC">
    <div class="table">
      <el-table
        :data="tableData">
        <el-table-column
          type="index"
          v-if="list.length>0&&styles.indexNo"
          key="indexNo"/>
        <Column
          v-for="(item,idx) in list"
          :key="idx+key"
          :obj="styles"
          :thousands="columnsPropsList"
          :item="item"/>
      </el-table>
    </div>
    <slot />
  </div>
</template>
<script>
import { queryChartData } from '../../../../api/panel';
import Column from './column';
import deepCopy from '../../../../utils/deepCopy';

export default {
  name: 'TableComp', // 组件名称icon+Comp
  components: {
    Column
  },
  props: {
    data: {
      type: Object,
      default() {
        return {};
      }
    }
  },
  data() {
    return {
      loading: false,
      list: [],
      tableData: [],
      key: 1,
      styles: this.data.styles,
      extra: []
    };
  },
  created() {
    this.preView = this.$store.state.panel.preView;
    this.$store._vm.$on(`${this.data.i}update${this.preView}`, (data) => { // 请求数据 更新
      this.queryChartData(data);
    });
    this.$store._vm.$on(`${this.data.i}search${this.preView}`, (data) => { // 请求数据 查询
      this.searchInit = true;
      this.extra = data;
      this.queryChartData(this.data);
    });
  },
  destroyed() {
    this.$store._vm.$off(`${this.data.i}update${this.preView}`);
    this.$store._vm.$off(`${this.data.i}search${this.preView}`);
  },
  mounted() {
    if (!this.searchInit) {
      this.init();
    }
  },
  methods: {
    init() {
      if (Object.keys(this.data.params).length > 0) { // 初始化编辑请求数据
        this.queryChartData(this.data);
      }
    },
    hasType(list, type) { // 是否有维度
      for (let i = 0, j = list.length; i < j; i += 1) {
        if (list[i].dmType === type) {
          return true;
        }
      }
      return false;
    },
    deepTitle(array, obj, list, index, props) {
      const {
        aggregate, column, expression, label
      } = list[index];
      const prop = aggregate ? `${aggregate.toUpperCase()}(${column})` : (column || expression);
      if (index === list.length - 1) { // 最后一个
        array.push({
          label: obj ? obj[prop] : label,
          prop: `${props}`
        });
      } else {
        array.push({
          label: obj ? obj[prop] : label,
          children: []
        });
        //
        this.deepTitle(array[0].children, obj, list, index + 1, props);
      }
    },
    rowsAllDim(list, rows, columns) {
      let arrayVal = [];
      this.deepTitle(arrayVal, null, columns, 0, -1);
      this.list.push(arrayVal[0]);
      list.forEach((obj, props) => {
        arrayVal = [];
        this.deepTitle(arrayVal, obj, columns, 0, props);
        this.list.push(arrayVal[0]);
      });
      rows.forEach((obj) => {
        const {
          aggregate, column, expression, label
        } = obj;
        const prop = aggregate ? `${aggregate.toUpperCase()}(${column})` : (column || expression);
        const objVal = {
          '-1': label
        };
        list.forEach((item, idx) => {
          objVal[idx] = item[prop];
        });
        this.tableData.push(objVal);
      });
      //
    },
    //
    rowsHasDM(list, rows, columns) { // 行是度量和维度 列是维度 行是两个 列是一个或者两个
      // 列的两个维度name
      const prop0 = (columns[0].column || columns[0].expression);
      const prop1 = columns[1] ? (columns[1].column || columns[1].expression) : null;
      // 行的一个维度name 一个度量name
      const rowProp0 = rows[0].aggregate ? `${rows[0].aggregate.toUpperCase()}(${rows[0].column})` : (rows[0].column || rows[0].expression);
      const rowProp1 = rows[1].aggregate ? `${rows[1].aggregate.toUpperCase()}(${rows[1].column})` : (rows[1].column || rows[1].expression);
      //
      const val = {};// 有prop1 -> key:[] 无 -> key:key
      const { dmType, label } = rows[0];
      list.forEach((obj) => {
        if (prop1) {
          const objs = val[obj[prop0]];
          if (objs && !objs.includes(obj[prop1])) {
            val[obj[prop0]].push(obj[prop1]);
          } else if (!objs) {
            val[obj[prop0]] = [obj[prop1]];
          }
        } else {
          val[obj[prop0]] = obj[prop0];
        }
        //
        const temp = {};
        const name = prop1 ? `${obj[columns[0].column]}-${obj[columns[1].column]}` : obj[columns[0].column];
        const idx = dmType === 'dimension' ? 1 : 0;
        temp[rows[idx].label] = rows[idx].label;
        temp[name] = obj[dmType === 'dimension' ? rowProp1 : rowProp0];
        Object.assign(temp, obj);
        this.tableData.push(temp);
      });
      if (dmType === 'dimension') { // 行第一个是维度
        this.list.push({
          label,
          prop: rowProp0
        });
        //
        this.list.push({
          label: columns[0].label,
          children: [{
            label: '度量',
            prop: rows[1].label
          }]
        });
      } else { // 行第一个是度量
        this.list.push({
          label: '度量',
          prop: rows[0].label
        });
        this.list.push({
          label: columns[0].label,
          children: [{
            label: rows[1].label,
            prop: rowProp1
          }]
        });
      }
      Object.keys(val).forEach((labels) => {
        if (prop1) {
          const children = [];
          val[labels].forEach((name) => {
            children.push({
              label: name,
              prop: `${labels}-${name}`
            });
          });
          this.list.push({
            label: labels,
            children
          });
        } else {
          this.list.push({
            label: labels,
            prop: labels
          });
        }
      });
    },
    columnsHasDM(list, rows, columns) {
      const { dmType } = columns[0];
      const prop0 = columns[0].aggregate ? `${columns[0].aggregate.toUpperCase()}(${columns[0].column})` : (columns[0].column || columns[0].expression);
      const prop1 = columns[1].aggregate ? `${columns[1].aggregate.toUpperCase()}(${columns[1].column})` : (columns[1].column || columns[1].expression);
      const val = [];
      const children = [];
      list.forEach((obj) => {
        const prop = dmType === 'metric' ? prop1 : prop0;
        val.push(obj[prop]);
        const temp = {};
        temp[obj[prop]] = obj[prop === prop0 ? prop1 : prop0];
        this.tableData.push(Object.assign(temp, obj));
      });
      //
      rows.forEach((item, index) => {
        if (index === rows.length - 1) {
          this.list.push({
            label: dmType === 'metric' ? '度量' : columns[0].label,
            children: [{
              label: item.label,
              prop: item.column
            }]
          });
        } else {
          this.list.push({
            label: item.label,
            prop: item.column
          });
        }
      });
      if (dmType === 'metric') { // 列的第一个是度量
        val.forEach((name) => {
          children.push({
            label: name,
            prop: name
          });
        });
        this.list.push({
          label: columns[0].label,
          children
        });
      } else {
        val.forEach((name) => {
          this.list.push({
            label: name,
            children: [{
              label: columns[1].label,
              prop: name
            }]
          });
        });
      }
    },
    applyChart(list, data) {
      this.key += 1;
      this.list = [];
      this.tableData = [];
      const { params } = data;
      const {
        hasMetric, rows, columns
      } = params;
      //
      if (hasMetric === 'columns' && !this.hasType(columns, 'dimension')) { // 行全是维度，列全是度量
        rows.concat(columns).forEach((obj) => {
          const {
            aggregate, column, expression, label
          } = obj;
          const prop = aggregate ? `${aggregate.toUpperCase()}(${column})` : (column || expression);
          this.list.push({
            label,
            prop
          });
        });
        this.tableData = list;// metric
      } else if (hasMetric === 'rows' && !this.hasType(rows, 'dimension')) { // 行全是度量，列全是维度
        this.rowsAllDim(list, rows, columns);
      } else if (hasMetric === 'rows' && this.hasType(rows, 'dimension')) { // 行是度量和维度 列是维度
        this.rowsHasDM(list, rows, columns);
      } else if (hasMetric === 'columns' && this.hasType(rows, 'dimension')) { // 行是维度 列是度量和维度
        this.columnsHasDM(list, rows, columns);
      }
      // 设置千分位符号
      this.setThousand(data);
      // 设置头部合并单元格
      this.setHeaderUnit(this.list);
    },
    // 设置千分位符号
    setThousand(data) {
      const { columns } = data.params;
      this.columnsPropsList = [];
      columns.forEach((obj) => {
        const {
          aggregate, column, expression, formatThousand
        } = obj;
        const prop = aggregate ? `${aggregate.toUpperCase()}(${column})` : (column || expression);
        if (formatThousand) {
          this.columnsPropsList.push(prop);
        }
      });
    },
    // 设置头部合并单元格
    setHeaderUnit(list) {
      if (!list.length || !list[0].children) { // 头部最后一行不设置合并
        return;
      }
      const listMap = {};
      list.forEach((item) => {
        const { label, children } = item;
        if (listMap[label]) {
          listMap[label] = listMap[label].concat(children);
        } else {
          listMap[label] = children;
        }
      });
      list.length = 0;// 保持引用
      Object.keys(listMap).forEach((key) => {
        list.push({
          label: key,
          children: listMap[key]
        });
        //
        this.setHeaderUnit(listMap[key]);
      });
    },
    // 像后端请求数据方法
    queryChartData(data) {
      this.loading = true;
      const { params, type, i } = data;
      const { id, state } = this.$route.params;
      queryChartData({
        params,
        extra: this.extra,
        compQuery: {
          compId: i,
          dashBoardId: id === 'create' ? null : id,
          dashBoardStage: state === 'online' ? 3 : null
        }
      }, type).then((res) => {
        this.exportData = res;
        this.applyChart(res.result, deepCopy(data));
      }).finally(() => {
        this.loading = false;
      });
    },
  }
};
</script>
<style scoped lang="less">
.tableC {
  .table {
    padding: 30px 5px 5px 5px;
    height: 100%;
    box-sizing: border-box;
    .el-table {
      width: 100%;
      height: 100%;
      // overflow: auto;
      /deep/ .el-table__body-wrapper {
        overflow: auto;
        &.is-scrolling-none {
          height: calc(100% - 50px);
        }
      }
      &::before {
        display: none;
      }
    }
  }
}
</style>
