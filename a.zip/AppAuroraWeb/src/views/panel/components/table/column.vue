<template>
  <el-table-column
    :sortable="!item.children"
    :prop="item.prop+''"
    :align="obj.position"
    :label="item.label+''">
    <template v-if="item.children">
      <Column
        v-for="(subItem,idx) in item.children"
        :key="idx+key"
        :obj="obj"
        :item="subItem"/>
    </template>
    <template
      v-show="!item.children"
      slot-scope="scope">
      {{ scope.row[item.prop] | thousandsFilter(item.prop,thousands) }}
    </template>
  </el-table-column>
</template>
<script>
import { thousandsFmt } from '../../../../utils/index';

export default {
  name: 'Column',
  filters: {
    thousandsFilter: function filter(value, props, thousands) {
      if (value && thousands.includes(props)) {
        return thousandsFmt(value);
      }
      return value || '-';
    }
  },
  props: {
    obj: {
      type: Object,
      default() {
        return {};
      }
    },
    item: {
      type: Object,
      default() {
        return {};
      }
    },
    thousands: {
      type: Array,
      default() {
        return [];
      }
    }
  },
  computed: {
    key() {
      return new Date().getTime();
    }
  },
};
</script>
