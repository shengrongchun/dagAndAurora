<template>
  <el-dialog
    :title="title"
    :visible.sync="dialogVisible"
    :close-on-click-modal="false"
    :append-to-body="true"
    @close="$emit('update:dVisible',false)"
    :width="type==='move'?'35%':'50%'">
    <template v-if="type==='move'">
      <el-form
        ref="form"
        :model="form"
        label-width="100px">
        <el-form-item
          prop="val"
          label="移动区域"
          :rules="[{required: true, message: '移动区域不能为空'}]">
          <el-cascader
            filterable
            ref="cascader"
            :props="{ expandTrigger: 'hover' }"
            v-model="form.val"
            :options="tabList"/>
        </el-form-item>
      </el-form>
      <span
        slot="footer"
        class="dialog-footer">
        <el-button @click="dialogVisible=false">取 消</el-button>
        <el-button
          type="primary"
          @click="submitForm">确 定</el-button>
      </span>
    </template>
    <div
      v-if="type==='sql'"
      style="position:relative">
      <textarea ref="textarea"/>
      <i
        :style="{position: 'absolute',top:'5px',right:'5px',
                 color: '#fff',cursor: 'pointer','z-index':1000}"
        class="iconfont icon-fuzhi"
        @click="copySql"
        title="复制"/>
    </div>
  </el-dialog>
</template>
<script>
// 引入全局实例
import CodeMirror from 'codemirror';
import sqlFormatter from 'sql-formatter';
// 核心样式
import 'codemirror/lib/codemirror.css';
// 引入主题后还需要在 options 中指定主题才会生效
import 'codemirror/theme/yonce.css';// base16-dark
// 引入sql模式
import 'codemirror/mode/sql/sql.js';

export default {
  props: {
    dVisible: {
      type: Boolean,
      default: false
    },
    dialogData: {
      type: Object,
      default() {
        return {};
      }
    }
  },
  data() {
    return {
      dialogVisible: this.dVisible,
      form: { val: null },
    };
  },
  created() {
    this.type = this.dialogData.mask;
    if (this.type === 'move') {
      this.title = '移动至';
      this.moveInit();
    } else if (this.type === 'sql') {
      this.title = '查看SQL';
      // 初始化sql
      this.initCodeMirror();
    }
  },
  methods: {
    copySql() {
      if (!this.copyInputInstance) {
        this.copyInputInstance = document.createElement('input');
        document.body.appendChild(this.copyInputInstance);
      }
      this.copyInputInstance.style.display = 'block';
      this.copyInputInstance.value = this.dialogData.SQL;
      this.copyInputInstance.select();
      // 调用浏览器的复制命令
      document.execCommand('Copy');
      this.copyInputInstance.style.display = 'none';
      //
      this.$message({
        type: 'success',
        message: '复制成功'
      });
    },
    initCodeMirror() {
      this.$nextTick(() => {
        this.coder = CodeMirror.fromTextArea(this.$refs.textarea, {
          // 缩进格式
          tabSize: 2,
          // 主题，对应主题库 JS 需要提前引入
          theme: 'yonce',
          // 显示行号
          lineNumbers: true,
          line: true,
          mode: 'text/x-sql',
          readOnly: true
        });
        // 编辑器赋值
        const SQL = sqlFormatter.format(this.dialogData.SQL || '');
        this.coder.setValue(SQL);
        // 支持双向绑定
        // this.coder.on('change', (coder) => {
        //   this.form.hql = coder.getValue();
        //   this.$refs.form.validate();
        // });
      });
    },
    moveInit() {
      const mask = this.getIsOuter();
      if (mask) {
        this.tabList = [];
      } else {
        this.tabList = [{ label: '最外层容器', value: '最外层容器', list: this.$store.state.panel.compList }];
      }
      this.setTabList(this.tabList, this.$store.state.panel.compList);
    },
    getIsOuter() {
      const list = this.$store.state.panel.compList;
      for (let i = 0; i < list.length; i += 1) {
        if (list[i].i === this.dialogData.comp.i) {
          return true;
        }
      }
      return false;
    },
    setTabList(Tab, list) {
      list.forEach((ele) => {
        if (ele.type === 'Tab') {
          const { tabList, label } = ele.styles;
          const children = [];
          this.setTabList(children, tabList);
          Tab.unshift({
            label: label.text,
            value: label.text,
            children
          });
        } else {
          const { title, compList } = ele;
          if (title && compList) { // tab里面的container
            Tab.unshift({
              label: title,
              value: title,
              list: compList
            });
          }
        }
      });
    },
    submitForm() {
      this.$refs.form.validate((valid) => {
        if (valid) {
          this.dialogVisible = false;
          const { data } = this.$refs.cascader.getCheckedNodes()[0];
          this.$emit('ok', this.dialogData, data.list);
        }
      });
    },
  }
};
</script>
