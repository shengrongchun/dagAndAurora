<template>
  <div class="noneC">
    {{ title }}
  </div>
</template>
<script>
export default {
  props: {
    title: {
      type: String,
      default: '添加组件，快开始吧'
    }
  }
};
</script>
<style scoped lang="less">
.noneC {
  padding-top: 25px;
  color: #409EFF;
  height: 100%;
  display: flex;
  /*垂直排列*/
  //flex-direction: column;
  align-items:center;/*由于flex-direction: column，因此align-items代表的是水平方向*/
  justify-content: center;/*由于flex-direction: column，因此justify-content代表的是垂直方向*/
}
</style>
