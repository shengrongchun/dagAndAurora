<template>
  <div class="left-header">
    <!-- 工具类型组件 如搜索组件 tab组件-->
    <ul class="utils">
      <li
        v-for="(item,idx) in utilsCList"
        :key="idx"
        :title="item.name"
        :type="item.icon"
        draggable="true"
        @dblclick="dbclick(item)"
        @dragstart.stop="dragstart"><i :class="'iconfont icon-'+item.icon"/></li>
    </ul>
    <div class="silder"/>
    <!-- 折线图 柱状图等组件 -->
    <ul>
      <li
        v-for="(obj,index) in compCList"
        :key="index"
        :title="obj.name"
        :type="obj.icon"
        draggable="true"
        @dblclick="dbclick(obj)"
        @dragstart.stop="dragstart"><i :class="'iconfont icon-'+obj.icon"/></li>
    </ul>
  </div>
</template>
<script>
import { utilsCList, compCList } from '../../../store/modules/options';

export default {
  created() {
    this.utilsCList = utilsCList;
    this.compCList = compCList;
  },
  methods: {
    dbclick(item) {
      if (!['Select', 'Date'].includes(item.icon)) {
        this.$store.commit('addComp', {
          type: item.icon,
          x: 0,
          y: 0,
          list: this.$store.state.panel.compList,
          compType: null,
          vm: this
        });
      }
    },
    dragstart(ev) { // 开始拖放 传组件类型
      ev.dataTransfer.setData('type', ev.target.type);
    }
  }
};
</script>
<style scoped lang="less">
.left-header {
  height: 30px;
  background: rgb(40,47,70);
  .silder {
    margin: -1px 12px;
    vertical-align: text-top;
    display: inline-block;
    width: 1px;
    height: 18px;
    background: rgb(80,87,106);
  }
  ul {
    display: inline-block;
    line-height: 29px;
    list-style: none;
    margin: 0;
    padding: 0;
    color: rgb(97,169,248);
    &.utils {
      color: rgb(97,104,121);
    }
    li {
      display: inline-block;
      cursor: pointer;
      padding: 0 12px;
      i {
        font-size: 20px;
      }
    }
  }
}
</style>
