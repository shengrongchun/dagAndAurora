<template>
  <div
    class="drag-container"
    @dragover.prevent
    @drop.prevent.stop="drop">
    <grid-layout
      v-if="list.length>0"
      :layout.sync="list"
      :col-num="$store.state.panel.colNum"
      :row-height="$store.state.panel.rowHeight"
      :isResizable="!preView"
      :isDraggable="!preView"
      :responsive="false"
      :margin="[10, 10]">
      <grid-item
        v-for="(comp,index) in list"
        :x="comp.x"
        :y="comp.y"
        :w="comp.w"
        :h="comp.h"
        :i="comp.i"
        :key="comp.i">
        <component
          :is="comp.type+'Comp'"
          :ref="'ref'+comp.i"
          :class="{'active':(comp.i===$store.state.panel.activeComp.i&&!preView)}"
          :data="comp"
          @click.native.stop="$store.commit('changeActiveComp',comp)"
          v-resize:debounce="(h)=>{resized('ref'+comp.i)}"
          class="comp">
          <div
            class="utils-title"
            v-if="!$store.state.panel.searchComps[comp.type]&&comp.type!=='Search'">
            <span>{{ comp.styles.label.text }}</span>
            <i
              class="iconfont icon-tooltip"
              :title="comp.styles.label.subText"/>
          </div>
          <el-popover
            class="utils-more"
            placement="right"
            popper-class="space"
            trigger="hover">
            <template
              v-if="!$store.state.panel.searchComps[comp.type] &&
                comp.type!=='Search' && comp.type!=='Tab'">
              <ul class="utils-ui">
                <template v-if="!preView">
                  <li
                    @click="utilsClick('move',comp,index)"><i
                    slot="reference"
                    class="iconfont icon-move"
                  /> 移动至</li>
                  <li @click="utilsClick('copy',comp,index)"><i
                    slot="reference"
                    class="iconfont icon-fuzhi"
                  /> 复制</li>
                  <li @click="utilsClick('del',comp,index)"><i
                    slot="reference"
                    class="iconfont icon-shanchu-copy-copy"
                  /> 删除</li>
                </template>
                <template>
                  <li @click="utilsClick('export',comp,index)"><i
                    slot="reference"
                    class="iconfont icon-daochu"
                  /> 导出</li>
                  <li @click="utilsClick('sql',comp,index)"><i
                    slot="reference"
                    class="iconfont icon-sql"
                  /> 查看SQL</li>
                </template>
              </ul>
              <i
                slot="reference"
                class="iconfont icon-msnui-more"/>
            </template>
            <template v-else-if="!preView">
              <ul class="utils-ui">
                <li
                  @click="utilsClick('del',comp,index)"><i
                  slot="reference"
                  class="iconfont icon-shanchu-copy-copy"
                /> 删除</li>
              </ul>
              <i
                slot="reference"
                class="iconfont icon-msnui-more"/>
            </template>
          </el-popover>
        </component>
      </grid-item>
    </grid-layout>
    <NoData v-else />
    <DragDialog
      v-if="dialogVisible"
      :dVisible.sync="dialogVisible"
      :dialogData="dialogData"
      @ok="dialogOk"/>
  </div>
</template>
<script>
import VueGridLayout from 'vue-grid-layout';
import NoData from './dragNone';
import DragDialog from './dragDialog';
import deepCopy from '../../../utils/deepCopy';
import { setText, delCompsText } from '../../../store/modules/options';
import setExcel from '../../../utils/setDataExcel';

export default {
  components: {
    DragDialog,
    NoData,
    GridLayout: VueGridLayout.GridLayout,
    GridItem: VueGridLayout.GridItem
  },
  props: {
    obj: {
      type: Object,
      default() {
        return {};
      }
    },
    list: {
      type: Array,
      default() {
        return [];
      }
    }
  },
  data() {
    return {
      preView: this.$store.state.panel.preView,
      dialogVisible: false,
      dialogData: {}
    };
  },
  methods: {
    resized(i) { // 组件大小变化后的事件
      const com = this.$refs[i];
      if (com && com[0] && com[0].resize) {
        com[0].resize();// echarts组件需要在resize的时候重新resize
      }
    },
    drop(ev) { // 从header部拖组件
      const type = ev.dataTransfer.getData('type');
      if (type && !this.preView) {
        this.$store.commit('addComp', {
          type,
          x: 0,
          y: 0,
          list: this.list,
          compType: this.obj.type,
          vm: this
        });
      }
    },
    dialogOk(obj, list) {
      const { index, comp } = obj;
      this.list.splice(index, 1); // 删除
      list.unshift(comp);// 添加
    },
    formatDateTime(date) {
      const y = date.getFullYear();
      let m = date.getMonth() + 1;
      m = m < 10 ? (`0${m}`) : m;
      let d = date.getDate();
      d = d < 10 ? (`0${d}`) : d;
      return `${y}-${m}-${d}`;
    },
    utilsClick(mask, comp, idx) {
      if (mask === 'copy') { // 复制
        const i = new Date().getTime();
        const copyComp = deepCopy(comp);
        copyComp.i = i;// 设置唯一id
        const { styles } = copyComp;
        // 设置标题并且是非重复的
        setText(this.$store.state.panel, styles, `${styles.label.text}_副本`);
        this.list.unshift(copyComp);
      } else if (mask === 'move') { // 移动
        this.dialogVisible = true;
        this.dialogData = {
          index: idx,
          comp,
          mask
        };
      } else if (mask === 'sql') { // 查看SQL
        this.dialogVisible = true;
        const { exportData } = this.$refs[`ref${comp.i}`][0];
        this.dialogData = {
          index: idx,
          comp,
          mask,
          SQL: exportData ? exportData.query : null
        };
      } else if (mask === 'export') { // 导出
        // const data = [
        //   ['姓名', '性别', '年龄', '注册时间'],
        // ];
        const data = [];
        //
        const { exportData } = this.$refs[`ref${comp.i}`][0];
        if (exportData) {
          const { columns, result } = exportData;
          const header = [];
          columns.forEach((obj) => {
            header.push(obj.label);
          });
          data.push(header);
          //
          result.forEach((item) => {
            data.push(Object.values(item));
          });
          //
          setExcel(data, 'sheet1', `${comp.styles.label.text}_${this.formatDateTime(new Date())}.xlsx`);// 数据 sheet名称 导出文件名
        } else {
          this.$message.warning('无数据');
        }
      } else if (mask === 'del') { // 删除
        delCompsText(this.$store.state.panel, [comp]);// 删除占用的标题
        this.list.splice(idx, 1);
      }
    }
  },
};
</script>
<style scoped lang="less">
  .drag-container {
    height: 100%;
    width: 100%;
    overflow: auto;
    padding-bottom: 30px;
    .vue-grid-layout {
      .vue-grid-item {
        cursor: default !important;
      }
    }
    .comp { //组件样式
      height: 100%;
      width: 100%;
      &.active {
        border: 1px solid #61a9f8 !important;
      }
      .utils-title {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        padding: 4px 10px 5px;
        > span {
          font-weight: bolder;
          font-size: 12px;
        }
        > i {
          margin-left: 5px;
          cursor: pointer;
          vertical-align: middle;
        }
      }
      .utils-more {
        position: absolute;
        cursor: pointer;
        top: 5px;
        right: 5px;
      }
    }
  }
</style>
