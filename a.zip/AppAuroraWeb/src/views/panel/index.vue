<template>
  <div
    class="panel"
    v-loading="loading">
    <!-- 编辑 预览 保存等功能头部部分 -->
    <div class="header">
      <div class="left">
        <el-page-header
          @back="goBack">
          <div
            slot="content"
            class="content">
            <i class="iconfont icon-yibiaopan" />
            <el-input
              v-model="form.compName"
              placeholder="未命名"/>
          </div>
        </el-page-header>
      </div>
      <div class="right">
        <template v-if="!$store.state.panel.preView">
          <span class="theme">主题</span>
          <el-select
            class="dark"
            v-model="$store.state.panel.theme"
            :popper-append-to-body="false"
          >
            <el-option
              value="default"
              label="默认" />
            <el-option
              value="dark"
              label="黑暗" />
          </el-select>
        </template>
        <el-radio-group
          v-model="$store.state.panel.preView"
          size="mini">
          <el-radio-button
            :label="false"
          >编辑</el-radio-button>
          <el-radio-button
            :label="true"
          >预览</el-radio-button>
        </el-radio-group>
        <span
          class="span-btn"
          @click="openDialog">保存&权限设置</span>
      </div>
    </div>
    <!-- 数据权限弹框 -->
    <AuthorityDialog
      v-if="authorityVisible"
      :visible="authorityVisible"
      :list="compAuList"
      @close="authorityVisible=false"/>
    <!-- 极光配置主体部分 -->
    <Main :style="{'height': 'calc(100% - 40px)'}"/>
  </div>
</template>
<script>
import Main from './main.vue';
import { saveDashboard, dashboard } from '../../api/panel';
import AuthorityDialog from './authority/indexDialog';

export default {
  components: {
    Main,
    AuthorityDialog,
  },
  props: {
    projectId: {
      type: [String, Number],
      default: null
    },
    parentId: {
      type: [String, Number],
      default: null
    },
    id: {
      type: [String, Number],
      default: null
    },
    breadList: {
      type: Array,
      default() {
        return [];
      }
    }
  },
  data() {
    return {
      loading: false,
      authorityVisible: false,
      form: {
        compName: null, // 仪表盘名称
      },
      compAuList: [], // 权限组件列表
    };
  },
  created() {
    this.Id = this.id;
    const { compList } = this.$store.state.panel;
    if (this.Id !== 'create') { // 编辑
      this.getData();
    } else if (compList.length === 0) { // 新建默认增加折线图表
      this.$store.commit('addComp', {
        type: 'Line',
        x: 0,
        y: 0,
        list: compList,
        compType: null,
        vm: this
      });
    }
  },
  methods: {
    getData() {
      this.loading = true;
      dashboard(this.Id).then((res) => {
        this.form.compName = res.name;
        const config = JSON.parse(res.config);
        this.$store.commit('setCompList', config);
      }).finally(() => {
        this.loading = false;
      });
    },
    setCompAuList(list) {
      for (let j = 0; j < list.length; j += 1) {
        if (list[j].type !== 'Tab' && list[j].type !== 'Search') {
          if (Object.keys(list[j].params).length > 0) {
            const { i, params, styles } = list[j];
            const { dataSetId, dataSetName, dataSetType } = params;
            this.compAuList.push({
              compId: i,
              compName: styles.label.text,
              dataSetId,
              dataSetName,
              dataSetType,
            });
          } else {
            this.noParams = true;
            return;
          }
        } else if (list[j].type === 'Tab') {
          list[j].styles.tabList.forEach((tab) => {
            this.setCompAuList(tab.compList || []);
          });
        }
      }
    },
    openDialog() {
      if (!this.form.compName) {
        this.$message({ type: 'warning', message: '请输入仪表板名称' });
        return;
      }
      if (!this.$store.state.panel.compList.length) {
        this.$message({ type: 'warning', message: '请拖组件' });
        return;
      }
      // 判断所有组件是否都配置了
      this.compAuList = [];
      this.noParams = false;
      this.setCompAuList(this.$store.state.panel.compList);
      if (this.noParams) {
        this.$message({ type: 'warning', message: '有组件未配置' });
        return;
      }
      this.authorityVisible = true;
    },
    save() { // indexDialog中用到
      // 保存
      return new Promise((resolve, reject) => {
        saveDashboard({
          id: this.Id === 'create' ? null : this.Id,
          projectId: this.projectId,
          directoryId: this.parentId,
          name: this.form.compName,
          config: JSON.stringify({
            compList: this.$store.state.panel.compList,
            labelMap: this.$store.state.panel.labelMap,
            theme: this.$store.state.panel.theme,
          })
        }).then((Id) => {
          this.Id = Id;
          this.$message({ type: 'success', message: '面板保存成功' });
          resolve(Id);
        }).finally(() => {
          reject();
        });
      });
    },
    goBack() {
      this.$router.push({
        name: 'createSpaceIndex',
        params: {
          parentId: this.parentId,
          projectId: this.projectId,
          breadList: JSON.stringify(this.breadList),
        }
      });
    }
  },
};
</script>
<style scoped lang="less">
.panel {
  height: 100vh;
  .header {
    color: #eee;
    display: inline-flex;
    justify-content: space-between;
    width: 100%;
    background: rgb(5,21,37);
    padding: 0 10px;
    .left {
      .el-page-header {
        font-weight: bolder;
        height: 40px;
        line-height: 40px;
        .content {
          margin-top: -2px;
          .icon-yibiaopan {
            font-size: 15px;
            color: #eee;
            margin-right: 10px;
          }
          .el-input {
            width: 100px;
            /deep/ .el-input__inner {
              font-size: 15px;
              font-weight: bolder;
              color: #fff;
              background: rgb(5,21,37);
              border: none;
              padding-left: 3px;
            }
          }
        }
      }
    }
    .right {
      margin-right: 15px;
      height: 40px;
      line-height: 40px;
      > .span-btn {
        background: #333b54;
        padding: 4px 7px;
        line-height: 1;
        border-radius: 4px;
        cursor: pointer;
        display: inline-block;
        color: #fff;
        font-size: 12px;
        font-weight: bolder;
        margin-left: 20px;
      }
      > .el-select /deep/  .el-input {
        .el-input__inner {
          border: none;
          border-radius: 4px;
          font-weight: bolder;
          color: #fff;
          background: #282f46;
          line-height: 22px;
          height: 22px;
        }
      }
      > .el-radio-group {
        /deep/ .el-radio-button.is-active {
          .el-radio-button__inner {
            background: #555863;
            color: #fff;
          }
        }
        /deep/ .el-radio-button__inner {
          padding: 4px 7px;
          border: none;
          background: #333b54;
          color: #aaa;
          font-weight: bolder;
          box-shadow: none;
        }
      }
    }
    .theme {
      font-size: 13px;
      font-weight: bolder;
      color: #aaa;
    }
    /deep/ .el-select {
      width: 80px;
      margin: 0 20px 0 10px;
      .el-select__tags {
        max-width: 100%;
      }
      .el-select-dropdown {
        background: #282f46;
        border-color: #282f46;
        box-shadow: 0 2px 12px 0 #141721;
        .el-select-dropdown__item {
          color: #bbb;
          font-weight: bolder;
          &.hover {
            color: #bbb;
            background: #282f46;
          }
          &:hover,&.selected {
            color: #61a9f8;
            background: #282f46;
          }
        }
      }
      .popper__arrow {
        border-bottom-color: #282f46;
        &::after {
          border-bottom-color: #282f46;
        }
      }
    }
  }
}
</style>
