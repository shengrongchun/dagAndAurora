import echarts from 'echarts';
import defaults from './chartTheme/default.json';
import dark from './chartTheme/dark.json';
import './theme.less';
//
echarts.registerTheme('default', defaults);
echarts.registerTheme('dark', dark);
