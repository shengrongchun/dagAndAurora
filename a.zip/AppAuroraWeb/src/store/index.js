import Vuex from 'vuex';
import Vue from 'vue';
import panelStore from './modules/panelStore';

Vue.use(Vuex);
const store = new Vuex.Store({
  modules: {
    panel: panelStore
  }
});

export default store;
