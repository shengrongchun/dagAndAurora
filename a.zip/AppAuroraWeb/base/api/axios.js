import axios from 'axios';
import ssoAuth from '@hb/sso-auth';
import { filterParams } from 'base/utils/index';
import Catcher from './errCatcher';

window.cancelTokenList = [];

const service = axios.create({
  timeout: 150000
});

service.interceptors.request.use((config) => {
  config.headers.token = ssoAuth.token;
  filterParams(config.data || config.params || {});
  // 全局CancelToken
  const source = axios.CancelToken.source();
  window.cancelTokenList.push(source);
  config.cancelToken = source.token;
  return config;
}, (error) => {
  Promise.reject(error);
});

service.interceptors.response.use(
  (response) => {
    // 处理全局CancelToken List
    window.cancelTokenList = window.cancelTokenList
      .filter(x => x.token !== response.config.cancelToken);
    // 各种返回状况处理
    const res = response && response.data;
    if (res.code === 0) { res.status = 1; }
    if (res.status !== 1) Catcher(response);
    return res;
  },
  (error) => {
    Catcher(error.response, true);
  }
);

export default service;
