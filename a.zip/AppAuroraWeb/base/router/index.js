import Vue from 'vue';
import Router from 'vue-router';
import constantRouterMap from '@/router.config';

Vue.use(Router);

const router = new Router({
  scrollBehavior: () => ({ y: 0 }),
  routes: constantRouterMap
});

router.beforeEach(async (to, from, next) => {
  if (window.cancelTokenList) {
    window.cancelTokenList.forEach(x => x.cancel());
  }
  window.cancelTokenList = [];
  next();
});

export default router;
