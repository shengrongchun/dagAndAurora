import Vue from 'vue';
import ElementUI from 'element-ui';
import ssoAuth from '@hb/sso-auth';
import locale from 'element-ui/lib/locale/lang/zh-CN';
import 'element-ui/lib/theme-chalk/index.css';
import './styles/font/iconfont.css';
import action from 'base/directives/action';
import resize from 'vue-resize-directive';
import App from './App';
import router from './router';
import store from '@/store';
import '@/views/panel/components/index.js';// 全局注册panel组件
import '@/views/panel/theme/index.js';// 引入主题设置

Vue.use(ElementUI, { locale, size: 'mini' });
Vue.directive('resize', resize);
Vue.directive('action', action);
Vue.config.productionTip = false;

/* eslint-disable no-new */
const init = async () => {
  await ssoAuth.signIn();
  window._actions = ['ALL'];
  new Vue({
    el: '#app',
    router,
    store,
    render: h => h(App)
  });
};

init();
