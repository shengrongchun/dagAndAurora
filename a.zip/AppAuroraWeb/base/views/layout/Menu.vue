<template>
  <ul class="navMenu">
    <li
      v-for="(menu,idx) in menuList"
      :key="idx"><router-link :to="{name: menu.name}">{{ menu.name }}</router-link></li>
  </ul>
</template>
<script>
import menus from 'src/router.config.js';

export default {
  computed: {
    menuList() {
      return menus[0].children.filter(item => item.name);
    }
  },
};
</script>
<style lang="less" scoped>
.navMenu {
  margin: 0;
  padding: 0;
  list-style: none;
  li {
    display: inline-block;
    cursor: pointer;
    color: #ccc;
    margin-right: 55px;
    font-size: 17px;
    user-select: none;
    a.router-link-active {
      color: #fff;
      font-size: 18px;
      pointer-events: none;
    }
  }
}
</style>
