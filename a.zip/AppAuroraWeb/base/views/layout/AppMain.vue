<template>
  <section class="app-main">
    <transition
      name="fade"
      mode="out-in"
    >
      <router-view />
    </transition>
  </section>
</template>

<script>

export default {
  name: 'AppMain',
  // computed: {
  //   key() {
  //     return this.$route.name ? this.$route.name + +new Date() : this.$route + +new Date();
  //   }
  // }
};
</script>
<style scoped>
.app-main {
  margin-top: 60px;
  height: calc(100% - 60px);
}
</style>
